from typing import Dict, Any, Optional
from datetime import datetime, date
from enum import Enum

class TaskStatus(Enum):
    """Task status enumeration."""
    PENDING = "در انتظار"
    IN_PROGRESS = "در حال انجام"
    COMPLETED = "تکمیل شده"
    CANCELLED = "لغو شده"

class TaskPriority(Enum):
    """Task priority enumeration."""
    LOW = "کم"
    MEDIUM = "متوسط"
    HIGH = "زیاد"
    URGENT = "فوری"

class Task:
    """Task/Order model for work management."""
    
    def __init__(self, task_id: str, title: str, description: str = "", 
                 priority: TaskPriority = TaskPriority.MEDIUM,
                 estimated_hours: float = 1.0, target_date: str = None):
        self.task_id = task_id
        self.title = title
        self.description = description
        self.priority = priority
        self.estimated_hours = estimated_hours
        self.target_date = target_date or datetime.now().strftime("%Y-%m-%d")
        self.status = TaskStatus.PENDING
        self.assigned_employees = []
        self.start_date = None
        self.completion_date = None
        self.actual_hours = 0.0
        self.notes = ""
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()
    
    def start_task(self):
        """Mark task as started."""
        if self.status == TaskStatus.PENDING:
            self.status = TaskStatus.IN_PROGRESS
            self.start_date = datetime.now().isoformat()
            self.updated_at = datetime.now().isoformat()
            return True
        return False
    
    def complete_task(self, actual_hours: float = None, notes: str = ""):
        """Mark task as completed."""
        if self.status == TaskStatus.IN_PROGRESS:
            self.status = TaskStatus.COMPLETED
            self.completion_date = datetime.now().isoformat()
            if actual_hours is not None:
                self.actual_hours = actual_hours
            if notes:
                self.notes = notes
            self.updated_at = datetime.now().isoformat()
            return True
        return False
    
    def assign_employee(self, employee_id: str):
        """Assign an employee to the task."""
        if employee_id not in self.assigned_employees:
            self.assigned_employees.append(employee_id)
            self.updated_at = datetime.now().isoformat()
            return True
        return False
    
    def remove_employee(self, employee_id: str):
        """Remove an employee from the task."""
        if employee_id in self.assigned_employees:
            self.assigned_employees.remove(employee_id)
            self.updated_at = datetime.now().isoformat()
            return True
        return False
    
    def get_week_number(self) -> int:
        """Get the week number for the target date."""
        try:
            target_date = datetime.strptime(self.target_date, "%Y-%m-%d").date()
            return target_date.isocalendar()[1]
        except:
            return datetime.now().isocalendar()[1]
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert task to dictionary for JSON serialization."""
        return {
            "task_id": self.task_id,
            "title": self.title,
            "description": self.description,
            "priority": self.priority.value,
            "estimated_hours": self.estimated_hours,
            "target_date": self.target_date,
            "status": self.status.value,
            "assigned_employees": self.assigned_employees,
            "start_date": self.start_date,
            "completion_date": self.completion_date,
            "actual_hours": self.actual_hours,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Task':
        """Create task from dictionary."""
        task = cls(
            task_id=data.get("task_id", ""),
            title=data.get("title", ""),
            description=data.get("description", ""),
            priority=TaskPriority(data.get("priority", "متوسط")),
            estimated_hours=data.get("estimated_hours", 1.0),
            target_date=data.get("target_date", datetime.now().strftime("%Y-%m-%d"))
        )
        
        task.status = TaskStatus(data.get("status", "در انتظار"))
        task.assigned_employees = data.get("assigned_employees", [])
        task.start_date = data.get("start_date")
        task.completion_date = data.get("completion_date")
        task.actual_hours = data.get("actual_hours", 0.0)
        task.notes = data.get("notes", "")
        task.created_at = data.get("created_at", datetime.now().isoformat())
        task.updated_at = data.get("updated_at", datetime.now().isoformat())
        
        return task
    
    def __str__(self):
        return f"Task({self.task_id}: {self.title})"
    
    def __repr__(self):
        return self.__str__()

class TaskManager:
    """Manager class for handling multiple tasks."""
    
    def __init__(self):
        self.tasks = {}
        self.next_task_id = 1
    
    def add_task(self, title: str, description: str = "", 
                 priority: TaskPriority = TaskPriority.MEDIUM,
                 estimated_hours: float = 1.0, target_date: str = None) -> str:
        """Add a new task."""
        task_id = f"TASK_{self.next_task_id:04d}"
        self.next_task_id += 1
        
        task = Task(task_id, title, description, priority, estimated_hours, target_date)
        self.tasks[task_id] = task
        return task_id
    
    def add_existing_task(self, task: Task) -> str:
        """Add an existing task object and assign it an ID."""
        if not task.task_id:  # Task doesn't have an ID yet
            task_id = f"TASK_{self.next_task_id:04d}"
            self.next_task_id += 1
            task.task_id = task_id  # Assign the ID to the task object
            self.tasks[task_id] = task
            return task_id
        else:  # Task already has an ID
            self.tasks[task.task_id] = task
            return task.task_id
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID."""
        return self.tasks.get(task_id)
    
    def update_task(self, task_id: str, **kwargs) -> bool:
        """Update task properties."""
        if task_id not in self.tasks:
            return False
        
        task = self.tasks[task_id]
        for key, value in kwargs.items():
            if hasattr(task, key):
                setattr(task, key, value)
        
        task.updated_at = datetime.now().isoformat()
        return True
    
    def delete_task(self, task_id: str) -> bool:
        """Delete a task."""
        if task_id in self.tasks:
            del self.tasks[task_id]
            return True
        return False
    
    def get_tasks_by_status(self, status) -> list:
        """Get all tasks with a specific status."""
        # Handle both enum and string status values
        if isinstance(status, str):
            # Convert string to enum
            try:
                status_enum = TaskStatus(status)
            except ValueError:
                # If string doesn't match any enum value, return empty list
                return []
            status = status_enum
        
        return [task for task in self.tasks.values() if task.status == status]
    
    def get_tasks_by_week(self, week_number: int) -> list:
        """Get all tasks for a specific week."""
        return [task for task in self.tasks.values() if task.get_week_number() == week_number]
    
    def get_tasks_by_date(self, target_date: str) -> list:
        """Get all tasks for a specific date."""
        return [task for task in self.tasks.values() if task.target_date == target_date]
    
    def get_in_progress_tasks(self) -> list:
        """Get all tasks currently in progress."""
        return self.get_tasks_by_status(TaskStatus.IN_PROGRESS)
    
    def get_completed_tasks(self, date: str = None) -> list:
        """Get all completed tasks, optionally for a specific date."""
        completed = self.get_tasks_by_status(TaskStatus.COMPLETED)
        if date:
            completed = [task for task in completed if task.completion_date and task.completion_date.startswith(date)]
        return completed
    
    def get_pending_tasks(self) -> list:
        """Get all pending tasks."""
        return self.get_tasks_by_status(TaskStatus.PENDING)
    
    def get_total_estimated_hours(self, status: TaskStatus = None) -> float:
        """Get total estimated hours for tasks."""
        tasks = self.tasks.values()
        if status:
            tasks = [task for task in tasks if task.status == status]
        return sum(task.estimated_hours for task in tasks)
    
    def get_total_actual_hours(self, status: TaskStatus = None) -> float:
        """Get total actual hours for tasks."""
        tasks = self.tasks.values()
        if status:
            tasks = [task for task in tasks if task.status == status]
        return sum(task.actual_hours for task in tasks)
    
    def get_task_progress(self) -> Dict[str, Any]:
        """Get overall task progress statistics."""
        total_tasks = len(self.tasks)
        completed_tasks = len(self.get_completed_tasks())
        in_progress_tasks = len(self.get_in_progress_tasks())
        pending_tasks = len(self.get_pending_tasks())
        
        progress_percentage = (completed_tasks / total_tasks * 100) if total_tasks > 0 else 0
        
        return {
            "total_tasks": total_tasks,
            "completed_tasks": completed_tasks,
            "in_progress_tasks": in_progress_tasks,
            "pending_tasks": pending_tasks,
            "progress_percentage": round(progress_percentage, 1),
            "total_estimated_hours": self.get_total_estimated_hours(),
            "total_actual_hours": self.get_total_actual_hours(),
            "completed_estimated_hours": self.get_total_estimated_hours(TaskStatus.COMPLETED),
            "completed_actual_hours": self.get_total_actual_hours(TaskStatus.COMPLETED)
        }
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert task manager to dictionary for JSON serialization."""
        return {
            "tasks": {task_id: task.to_dict() for task_id, task in self.tasks.items()},
            "next_task_id": self.next_task_id
        }
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'TaskManager':
        """Create task manager from dictionary."""
        manager = cls()
        manager.next_task_id = data.get("next_task_id", 1)
        
        tasks_data = data.get("tasks", {})
        for task_id, task_data in tasks_data.items():
            try:
                task = Task.from_dict(task_data)
                manager.tasks[task_id] = task
            except Exception as e:
                print(f"Error loading task {task_id}: {e}")
        
        return manager
