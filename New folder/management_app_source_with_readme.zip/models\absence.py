from typing import Dict, Any, List, Optional
from datetime import datetime
from .employee import Employee

class Absence:
    """Absence model class for managing employee absences."""
    
    # Persian absence categories
    CATEGORIES = {
        "مرخصی": "Leave",
        "بیمار": "Sick",
        "غایب": "Absent"
    }
    
    def __init__(self, employee: Employee, category: str, date: str = None, notes: str = ""):
        print(f"DEBUG: Absence.__init__ called - employee: '{employee.employee_id}', category: '{category}', date: '{date}', notes: '{notes}'")
        self.employee = employee
        self.category = category
        self.date = date or datetime.now().strftime("%Y-%m-%d")
        self.notes = notes
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()
        print(f"DEBUG: Absence.__init__ completed - absence: {self}")
    
    @property
    def category_display(self) -> str:
        """Get display name for the category."""
        return self.category
    
    @property
    def employee_name(self) -> str:
        """Get employee name."""
        return self.employee.full_name
    
    @property
    def employee_id(self) -> str:
        """Get employee ID."""
        return self.employee.employee_id
    
    def is_valid_category(self) -> bool:
        """Check if the absence category is valid."""
        return self.category in self.CATEGORIES
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert absence to dictionary for JSON serialization."""
        result = {
            "employee_id": self.employee.employee_id,
            "first_name": self.employee.first_name,
            "last_name": self.employee.last_name,
            "employee_name": self.employee.full_name,
            "photo_path": self.employee.photo_path,
            "category": self.category,
            "date": self.date,
            "notes": self.notes,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
        print(f"DEBUG: Absence.to_dict called - absence: {self}, result: {result}")
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], employees_dict: Dict[str, Employee]) -> Optional['Absence']:
        """Create absence from dictionary."""
        print(f"DEBUG: Absence.from_dict called - data: {data}, employees_dict keys: {list(employees_dict.keys())}")
        employee_id = data.get("employee_id", "")
        if employee_id not in employees_dict:
            print(f"DEBUG: Absence.from_dict - employee '{employee_id}' not found in employees_dict")
            # Create a temporary employee object from the stored data to preserve the absence
            print(f"DEBUG: Creating temporary employee from absence data to preserve absence record")
            from .employee import Employee
            temp_employee = Employee(
                employee_id=employee_id,
                first_name=data.get("first_name", ""),
                last_name=data.get("last_name", ""),
                role="Employee",  # Default role
                photo_path=data.get("photo_path", "")
            )
            employee = temp_employee
            print(f"DEBUG: Created temporary employee: {employee}")
        else:
            employee = employees_dict[employee_id]
            print(f"DEBUG: Absence.from_dict - found employee: {employee}")
        
        absence = cls(
            employee=employee,
            category=data.get("category", "غایب"),
            date=data.get("date", datetime.now().strftime("%Y-%m-%d")),
            notes=data.get("notes", "")
        )
        absence.created_at = data.get("created_at", datetime.now().isoformat())
        absence.updated_at = data.get("updated_at", datetime.now().isoformat())
        print(f"DEBUG: Absence.from_dict completed - absence: {absence}")
        return absence
    
    def __str__(self) -> str:
        return f"Absence({self.employee_name}: {self.category_display})"
    
    def __repr__(self) -> str:
        return self.__str__()

class AbsenceManager:
    """Manager class for handling multiple absences."""
    
    def __init__(self):
        print("DEBUG: AbsenceManager.__init__ called")
        self.absences: Dict[str, List[Absence]] = {
            "مرخصی": [],
            "بیمار": [],
            "غایب": []
        }
        print(f"DEBUG: AbsenceManager.__init__ completed - categories: {list(self.absences.keys())}")
    
    def add_absence(self, absence: Absence) -> bool:
        """Add absence to the appropriate category."""
        if not absence.is_valid_category():
            return False
        
        # Check if employee already has an absence for this date
        if self.has_absence_for_employee(absence.employee, absence.date):
            return False
        
        self.absences[absence.category].append(absence)
        return True
    
    def remove_absence(self, absence: Absence) -> bool:
        """Remove absence from its category."""
        if absence.category in self.absences:
            if absence in self.absences[absence.category]:
                self.absences[absence.category].remove(absence)
                return True
        return False
    
    def get_absences_by_category(self, category: str) -> List[Absence]:
        """Get all absences for a specific category."""
        return self.absences.get(category, [])
    
    def get_absences_by_employee(self, employee: Employee) -> List[Absence]:
        """Get all absences for a specific employee."""
        all_absences = []
        for category_absences in self.absences.values():
            for absence in category_absences:
                if absence.employee == employee:
                    all_absences.append(absence)
        return all_absences
    
    def has_absence_for_employee(self, employee: Employee, date: str) -> bool:
        """Check if employee has an absence for a specific date."""
        for category_absences in self.absences.values():
            for absence in category_absences:
                if absence.employee == employee and absence.date == date:
                    return True
        return False
    
    def get_absence_for_employee(self, employee: Employee, date: str) -> Optional[Absence]:
        """Get absence for a specific employee and date."""
        for category_absences in self.absences.values():
            for absence in category_absences:
                if absence.employee == employee and absence.date == date:
                    return absence
        return None
    
    def remove_employee_absences(self, employee: Employee):
        """Remove all absences for a specific employee."""
        for category in self.absences:
            self.absences[category] = [
                absence for absence in self.absences[category] 
                if absence.employee != employee
            ]
    
    def get_category_count(self, category: str) -> int:
        """Get count of absences for a specific category."""
        return len(self.absences.get(category, []))
    
    def get_total_absences(self) -> int:
        """Get total count of all absences."""
        return sum(len(absences) for absences in self.absences.values())
    
    def clear_category(self, category: str):
        """Clear all absences for a specific category."""
        if category in self.absences:
            self.absences[category].clear()
    
    def clear_all(self):
        """Clear all absences."""
        for category in self.absences:
            self.absences[category].clear()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert absence manager to dictionary."""
        result = {
            category: [absence.to_dict() for absence in absences]
            for category, absences in self.absences.items()
        }
        print(f"DEBUG: AbsenceManager.to_dict called - result: {result}")
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], employees_dict: Dict[str, Employee]) -> 'AbsenceManager':
        """Create absence manager from dictionary."""
        print(f"DEBUG: AbsenceManager.from_dict called - data: {data}, employees_dict keys: {list(employees_dict.keys())}")
        manager = cls()
        
        for category, absences_data in data.items():
            print(f"DEBUG: AbsenceManager.from_dict - processing category: '{category}' with {len(absences_data)} absences")
            if category in manager.absences:
                for absence_data in absences_data:
                    absence = Absence.from_dict(absence_data, employees_dict)
                    if absence:
                        manager.absences[category].append(absence)
                        print(f"DEBUG: AbsenceManager.from_dict - added absence for employee '{absence.employee_id}' in category '{category}'")
                    else:
                        print(f"DEBUG: AbsenceManager.from_dict - failed to create absence from data: {absence_data}")
            else:
                print(f"DEBUG: AbsenceManager.from_dict - unknown category: '{category}'")
        
        print(f"DEBUG: AbsenceManager.from_dict completed - manager: {manager}")
        return manager
    
    def __str__(self) -> str:
        counts = [f"{cat}: {len(absences)}" for cat, absences in self.absences.items()]
        return f"AbsenceManager({', '.join(counts)})"
    
    def __repr__(self) -> str:
        return self.__str__()
