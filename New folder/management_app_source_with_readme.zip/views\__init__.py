"""
Views Package

This package contains the UI views for the management application.
"""

# Empty __init__.py to avoid import issues with PyInstaller
# Classes will be imported directly where needed
