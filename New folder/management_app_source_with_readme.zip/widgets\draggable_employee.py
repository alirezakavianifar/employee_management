from PyQt5.QtWidgets import QLabel, QWidget, QVBoxLayout, QHBoxLayout
from PyQt5.QtCore import Qt, QMimeData, QSize, pyqtSignal
from PyQt5.QtGui import QPixmap, QFont, QDrag, QPainter, QColor
import os

class DraggableEmployee(QWidget):
    """Draggable employee widget for shift management."""
    
    def __init__(self, employee, parent=None):
        super().__init__(parent)
        print(f"Debug: DraggableEmployee.__init__ called for employee: {employee.employee_id if employee else 'None'}")
        self.employee = employee
        self.setup_ui()
        self.setAcceptDrops(False)  # Employees are sources, not targets
    
    def setup_ui(self):
        """Setup the employee widget appearance."""
        print(f"Debug: DraggableEmployee.setup_ui called for employee: {self.employee.employee_id if self.employee else 'None'}")
        
        self.setFixedSize(100, 150)  # Increased height to accommodate full name text
        
        # Main layout
        layout = QVBoxLayout()
        layout.setContentsMargins(8, 8, 8, 8)
        layout.setSpacing(4)
        
        # Image label
        self.image_label = QLabel()
        self.image_label.setFixedSize(60, 60)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("""
            QLabel {
                border: 2px solid #e5e7eb;
                border-radius: 30px;
                background: white;
            }
        """)
        
        # Name label
        self.name_label = QLabel()
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet("""
            QLabel {
                color: #374151;
                font-weight: 600;
                font-size: 9px;
                background: transparent;
            }
        """)
        self.name_label.setWordWrap(True)
        self.name_label.setMaximumWidth(84)  # Slightly less than widget width
        self.name_label.setMinimumHeight(20)  # Ensure enough height for full names
        self.name_label.setSizePolicy(self.name_label.sizePolicy().horizontalPolicy(), 
                                     self.name_label.sizePolicy().Expanding)  # Allow vertical expansion
        
        # Add widgets to layout
        layout.addWidget(self.image_label, 0, Qt.AlignCenter)
        layout.addWidget(self.name_label, 0, Qt.AlignCenter)
        layout.addStretch()  # Push content to top
        
        self.setLayout(layout)
        
        # Widget styling
        self.setStyleSheet("""
            QWidget {
                border: 2px solid #e5e7eb;
                border-radius: 10px;
                background: white;
            }
            QWidget:hover {
                border-color: #4f46e5;
                background: #f8fafc;
            }
        """)
        
        print(f"Debug: About to call update_display for employee: {self.employee.employee_id if self.employee else 'None'}")
        self.update_display()
    
    def update_display(self):
        """Update the display with employee information."""
        print(f"Debug: DraggableEmployee.update_display called for employee: {self.employee.employee_id if self.employee else 'None'}")
        
        if not self.employee:
            self.image_label.setText("خالی")
            self.image_label.setPixmap(QPixmap())
            self.name_label.setText("")
            return
        
        # Set employee name
        full_name = f"{self.employee.first_name} {self.employee.last_name}".strip()
        self.name_label.setText(full_name)
        print(f"Debug: Set name label to: '{full_name}' (length: {len(full_name)})")
        print(f"Debug: Employee first_name: '{self.employee.first_name}', last_name: '{self.employee.last_name}'")
        print(f"Debug: Name label size: {self.name_label.size()}, max width: {self.name_label.maximumWidth()}")
        
        # Set employee photo or placeholder
        if self.employee.has_photo():
            print(f"Debug: Employee {self.employee.employee_id} has photo, getting pixmap")
            pixmap = self.employee.get_photo_pixmap(QSize(60, 60))
            self.image_label.setPixmap(pixmap)
            self.image_label.setText("")
            print(f"Debug: Photo pixmap set for employee {self.employee.employee_id}")
        else:
            print(f"Debug: Employee {self.employee.employee_id} has no photo, using initials")
            # Create initials for the image label
            initials = ""
            if self.employee.first_name:
                initials += self.employee.first_name[0].upper()
            if self.employee.last_name:
                initials += self.employee.last_name[0].upper()
            if not initials:
                initials = "EM"
            
            self.image_label.setText(initials)
            self.image_label.setPixmap(QPixmap())
            self.image_label.setStyleSheet("""
                QLabel {
                    border: 2px solid #e5e7eb;
                    border-radius: 30px;
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #4f46e5, stop:1 #7c3aed);
                    color: white;
                    font-weight: bold;
                    font-size: 16px;
                }
            """)
            print(f"Debug: Set initials for employee {self.employee.employee_id}: {initials}")
    
    def mousePressEvent(self, event):
        """Handle mouse press to start drag operation."""
        print(f"Debug: DraggableEmployee.mousePressEvent called for employee: {self.employee.employee_id if self.employee else 'None'}")
        if event.button() == Qt.LeftButton and self.employee:
            # Store the press position for drag detection
            self.press_pos = event.pos()
            print(f"Debug: Left button pressed at position: {self.press_pos}")
        super().mousePressEvent(event)
    
    def mouseMoveEvent(self, event):
        """Handle mouse move to start drag operation."""
        if (event.buttons() == Qt.LeftButton and 
            hasattr(self, 'press_pos') and 
            self.employee and
            (event.pos() - self.press_pos).manhattanLength() > 10):  # Minimum drag distance
            print(f"Debug: Mouse moved enough to start drag for employee: {self.employee.employee_id}")
            self.start_drag()
        super().mouseMoveEvent(event)
    
    def start_drag(self):
        """Start drag operation with employee data."""
        print(f"Debug: DraggableEmployee.start_drag called for employee: {self.employee.employee_id if self.employee else 'None'}")
        
        if not self.employee:
            print(f"Debug: No employee data available for drag")
            return
        
        drag = QDrag(self)
        mime_data = QMimeData()
        
        # Create employee data for drag
        employee_data = {
            "employee_id": self.employee.employee_id,
            "first_name": self.employee.first_name,
            "last_name": self.employee.last_name,
            "role": self.employee.role
        }
        
        print(f"Debug: Employee data for drag: {employee_data}")
        
        # Use JSON encoding for more reliable data transfer
        import json
        try:
            employee_data_str = json.dumps(employee_data, ensure_ascii=False)
            mime_data.setData("application/x-employee", employee_data_str.encode('utf-8'))
            print(f"Debug: Employee data encoded as JSON: {employee_data_str}")
        except Exception as e:
            print(f"Debug: JSON encoding failed, falling back to string: {e}")
            mime_data.setData("application/x-employee", str(employee_data).encode())
        
        drag.setMimeData(mime_data)
        
        # Create drag pixmap
        drag_pixmap = self.create_drag_pixmap()
        drag.setPixmap(drag_pixmap)
        drag.setHotSpot(drag_pixmap.rect().center())
        
        print(f"Debug: Starting drag operation for employee: {self.employee.employee_id}")
        # Execute drag
        result = drag.exec_(Qt.MoveAction)
        print(f"Debug: Drag operation completed with result: {result}")
    
    def create_drag_pixmap(self):
        """Create a pixmap for the drag operation."""
        print(f"Debug: DraggableEmployee.create_drag_pixmap called for employee: {self.employee.employee_id if self.employee else 'None'}")
        
        pixmap = QPixmap(80, 100)
        pixmap.fill(Qt.transparent)
        
        painter = QPainter(pixmap)
        painter.setRenderHint(QPainter.Antialiasing)
        
        # Draw background
        painter.setBrush(QColor(255, 255, 255, 200))
        painter.setPen(QColor(79, 70, 229))
        painter.drawRoundedRect(0, 0, 80, 100, 8, 8)
        
        # Draw employee info
        painter.setPen(QColor(17, 24, 39))
        font = QFont("Tahoma", 10)
        painter.setFont(font)
        
        if self.employee.has_photo():
            photo_pixmap = self.employee.get_photo_pixmap(QSize(50, 50))
            painter.drawPixmap(15, 10, photo_pixmap)
        else:
            painter.drawText(0, 30, 80, 20, Qt.AlignCenter, self.employee.display_name)
        
        painter.drawText(0, 70, 80, 20, Qt.AlignCenter, "در حال انتقال...")
        painter.end()
        
        print(f"Debug: Drag pixmap created for employee: {self.employee.employee_id if self.employee else 'None'}")
        return pixmap

class DroppableShiftSlot(QWidget):
    """Droppable shift slot that accepts employee drops."""
    
    # Define the signal
    employee_dropped = pyqtSignal(int, str, str)  # slot_index, shift_type, employee_data_str
    
    def __init__(self, slot_index, shift_type, parent=None):
        super().__init__(parent)
        print(f"Debug: DroppableShiftSlot.__init__ called for slot {slot_index}, shift_type: {shift_type}")
        self.slot_index = slot_index
        self.shift_type = shift_type  # 'morning' or 'evening'
        self.employee = None
        self.setup_ui()
        self.setAcceptDrops(True)
        print(f"Debug: DroppableShiftSlot {slot_index} initialized successfully")
    
    def setup_ui(self):
        """Setup the slot appearance."""
        print(f"Debug: DroppableShiftSlot.setup_ui called for slot {self.slot_index}")
        
        self.setFixedSize(90, 130)  # Increased height to accommodate full name text
        
        # Main layout
        layout = QVBoxLayout()
        layout.setContentsMargins(4, 4, 4, 4)
        layout.setSpacing(2)
        
        # Image label
        self.image_label = QLabel()
        self.image_label.setFixedSize(70, 70)
        self.image_label.setAlignment(Qt.AlignCenter)
        self.image_label.setStyleSheet("""
            QLabel {
                border: 2px dashed #d1d5db;
                border-radius: 35px;
                background: #f9fafb;
                color: #6b7280;
                font-size: 12px;
            }
        """)
        
        # Name label
        self.name_label = QLabel()
        self.name_label.setAlignment(Qt.AlignCenter)
        self.name_label.setStyleSheet("""
            QLabel {
                color: #374151;
                font-weight: 600;
                font-size: 8px;
                background: transparent;
            }
        """)
        self.name_label.setWordWrap(True)
        self.name_label.setMaximumWidth(82)  # Slightly less than widget width
        self.name_label.setMinimumHeight(25)  # Increased height for better text display
        self.name_label.setSizePolicy(self.name_label.sizePolicy().horizontalPolicy(), 
                                     self.name_label.sizePolicy().Expanding)  # Allow vertical expansion
        
        # Add widgets to layout
        layout.addWidget(self.image_label, 0, Qt.AlignCenter)
        layout.addWidget(self.name_label, 0, Qt.AlignCenter)
        layout.addStretch()  # Push content to top
        
        self.setLayout(layout)
        
        # Widget styling
        self.setStyleSheet("""
            QWidget {
                border: 2px dashed #d1d5db;
                background: #f9fafb;
                border-radius: 8px;
            }
        """)
        
        # Set initial empty state
        self.image_label.setText("خالی")
        self.name_label.setText("")
        
        print(f"Debug: DroppableShiftSlot UI setup completed for slot {self.slot_index}")
    
    def dragEnterEvent(self, event):
        """Handle drag enter event."""
        print(f"Debug: DroppableShiftSlot.dragEnterEvent called for slot {self.slot_index}")
        if event.mimeData().hasFormat("application/x-employee"):
            print(f"Debug: Accepting drag enter for slot {self.slot_index}")
            event.acceptProposedAction()
            self.setStyleSheet("""
                QWidget {
                    border: 3px dashed #4f46e5;
                    background: #eef2ff;
                    border-radius: 8px;
                }
            """)
            self.image_label.setStyleSheet("""
                QLabel {
                    border: 3px dashed #4f46e5;
                    background: #eef2ff;
                    border-radius: 35px;
                    color: #4f46e5;
                    font-size: 12px;
                }
            """)
        else:
            print(f"Debug: Rejecting drag enter for slot {self.slot_index}, no employee data format")
    
    def dragLeaveEvent(self, event):
        """Handle drag leave event."""
        print(f"Debug: DroppableShiftSlot.dragLeaveEvent called for slot {self.slot_index}")
        self.setStyleSheet("""
            QWidget {
                border: 2px dashed #d1d5db;
                background: #f9fafb;
                border-radius: 8px;
            }
        """)
        self.image_label.setStyleSheet("""
            QLabel {
                border: 2px dashed #d1d5db;
                background: #f9fafb;
                border-radius: 35px;
                color: #6b7280;
                font-size: 12px;
            }
        """)
    
    def dropEvent(self, event):
        """Handle drop event."""
        print(f"Debug: DroppableShiftSlot.dropEvent called for slot {self.slot_index}")
        if event.mimeData().hasFormat("application/x-employee"):
            # Extract employee data
            try:
                employee_data_bytes = event.mimeData().data("application/x-employee").data()
                employee_data_str = employee_data_bytes.decode('utf-8')
                print(f"Debug: Employee data dropped: {employee_data_str}")
                
                # Try to parse as JSON first, fall back to string representation
                import json
                try:
                    # Validate it's valid JSON
                    json.loads(employee_data_str)
                    print(f"Debug: Employee data is valid JSON")
                except json.JSONDecodeError:
                    print(f"Debug: Employee data is not JSON, treating as string representation")
                
                event.acceptProposedAction()
                
                # Emit the signal with the drop data
                print(f"Debug: Emitting employee_dropped signal for slot {self.slot_index}")
                self.employee_dropped.emit(self.slot_index, self.shift_type, employee_data_str)
            except Exception as e:
                print(f"Debug: Error processing drop data: {e}")
                event.ignore()
        else:
            print(f"Debug: Drop event ignored, no employee data format")
    
    def set_employee(self, employee):
        """Set the employee for this slot."""
        print(f"Debug: DroppableShiftSlot.set_employee called for slot {self.slot_index}, employee: {employee.employee_id if employee else 'None'}")
        
        self.employee = employee
        if employee:
            # Set employee name
            full_name = f"{employee.first_name} {employee.last_name}".strip()
            self.name_label.setText(full_name)
            print(f"Debug: Set name label to: '{full_name}' (length: {len(full_name)})")
            print(f"Debug: Employee first_name: '{employee.first_name}', last_name: '{employee.last_name}'")
            print(f"Debug: Name label size: {self.name_label.size()}, max width: {self.name_label.maximumWidth()}")
            
            # Update widget styling
            self.setStyleSheet("""
                QWidget {
                    border: 3px solid #10b981;
                    background: #ecfdf5;
                    border-radius: 8px;
                }
            """)
            
            # Set employee photo if available
            if employee.has_photo():
                print(f"Debug: Setting photo for employee {employee.employee_id} in slot {self.slot_index}")
                pixmap = employee.get_photo_pixmap(QSize(70, 70))
                if not pixmap.isNull():
                    self.image_label.setPixmap(pixmap)
                    self.image_label.setText("")
                    self.image_label.setStyleSheet("""
                        QLabel {
                            border: 3px solid #10b981;
                            background: #ecfdf5;
                            border-radius: 35px;
                        }
                    """)
                    print(f"Debug: Photo set successfully for employee {employee.employee_id} in slot {self.slot_index}")
                else:
                    print(f"Debug: Photo pixmap is null for employee {employee.employee_id} in slot {self.slot_index}")
            else:
                print(f"Debug: Employee {employee.employee_id} has no photo for slot {self.slot_index}")
                # Create initials for the image label
                initials = ""
                if employee.first_name:
                    initials += employee.first_name[0].upper()
                if employee.last_name:
                    initials += employee.last_name[0].upper()
                if not initials:
                    initials = "EM"
                
                self.image_label.setText(initials)
                self.image_label.setPixmap(QPixmap())
                self.image_label.setStyleSheet("""
                    QLabel {
                        border: 3px solid #10b981;
                        background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                            stop:0 #4f46e5, stop:1 #7c3aed);
                        border-radius: 35px;
                        color: white;
                        font-weight: bold;
                        font-size: 14px;
                    }
                """)
                print(f"Debug: Set initials for employee {employee.employee_id} in slot {self.slot_index}: {initials}")
        else:
            print(f"Debug: Clearing slot {self.slot_index}")
            self.image_label.setText("خالی")
            self.image_label.setPixmap(QPixmap())
            self.name_label.setText("")
            self.setStyleSheet("""
                QWidget {
                    border: 2px dashed #d1d5db;
                    background: #f9fafb;
                    border-radius: 8px;
                }
            """)
            self.image_label.setStyleSheet("""
                QLabel {
                    border: 2px dashed #d1d5db;
                    background: #f9fafb;
                    border-radius: 35px;
                    color: #6b7280;
                    font-size: 12px;
                }
            """)
