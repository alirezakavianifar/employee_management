
import sys
import os
from datetime import datetime
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QHBoxLayout, 
                             QTabWidget, QPushButton, QLabel, QLineEdit, 
                             QTableWidget, QTableWidgetItem, QComboBox,
                             QMessageBox, QFileDialog, QSpinBox, QGroupBox,
                             QGridLayout, QScrollArea, QFrame, QSplitter,
                             QTextEdit, QDialog, QDialogButtonBox, QFormLayout,
                             QStackedWidget, QSizePolicy, QSpacerItem, QApplication,
                             QCheckBox)
from PyQt5.QtCore import Qt, QTimer, QSize, QPropertyAnimation, QEasingCurve, QRect
from PyQt5.QtGui import QPixmap, QIcon, QFont, QDrag, QDropEvent, QPalette, QColor, QLinearGradient
from PyQt5.QtWidgets import QHeaderView # Added missing import for QHeaderView

from management_app.controllers.main_controller import MainController
from management_app.models.employee import Employee
from management_app.models.shift import ShiftManager
from management_app.models.absence import AbsenceManager
from management_app.widgets.draggable_employee import DraggableEmployee, DroppableShiftSlot
from management_app.services.export_service import ExportService
from management_app.ui.export_dialog import ExportDialog
from management_app.ui.task_dialog import TaskManagementDialog


class AdaptiveUI:
    """Helper class for adaptive UI scaling based on screen size."""
    
    @staticmethod
    def get_screen_size_category():
        """Determine screen size category for adaptive scaling."""
        print(f"Debug: AdaptiveUI.get_screen_size_category called")
        app = QApplication.instance()
        if app:
            screen = app.primaryScreen()
            size = screen.size()
            width, height = size.width(), size.height()
            
            print(f"Debug: Screen size: {width}x{height}")
            
            # Calculate diagonal size in inches (assuming 96 DPI)
            diagonal_pixels = (width ** 2 + height ** 2) ** 0.5
            diagonal_inches = diagonal_pixels / 96
            
            print(f"Debug: Diagonal size: {diagonal_inches:.2f} inches")
            
            if diagonal_inches < 15:
                category = "small"  # Small laptop screens
            elif diagonal_inches < 20:
                category = "medium"  # Standard laptop screens
            elif diagonal_inches < 27:
                category = "large"   # Large desktop screens
            else:
                category = "xlarge"  # Very large screens
            
            print(f"Debug: Screen size category: {category}")
            return category
        
        print(f"Debug: No QApplication instance, returning default category: medium")
        return "medium"  # Default fallback
    
    @staticmethod
    def get_scale_factor():
        """Get UI scale factor based on screen size."""
        print(f"Debug: AdaptiveUI.get_scale_factor called")
        category = AdaptiveUI.get_screen_size_category()
        scale_factors = {
            "small": 0.8,    # 80% scaling for small screens
            "medium": 1.0,   # 100% scaling for medium screens
            "large": 1.2,    # 120% scaling for large screens
            "xlarge": 1.4    # 140% scaling for very large screens
        }
        scale_factor = scale_factors.get(category, 1.0)
        print(f"Debug: Scale factor for category '{category}': {scale_factor}")
        return scale_factor
    
    @staticmethod
    def scale_value(base_value):
        """Scale a base value according to screen size."""
        print(f"Debug: AdaptiveUI.scale_value called with base_value: {base_value}")
        scale_factor = AdaptiveUI.get_scale_factor()
        scaled_value = int(base_value * scale_factor)
        print(f"Debug: Scaled value: {base_value} * {scale_factor} = {scaled_value}")
        return scaled_value
    
    @staticmethod
    def get_adaptive_font_size(base_size):
        """Get adaptive font size based on screen size."""
        print(f"Debug: AdaptiveUI.get_adaptive_font_size called with base_size: {base_size}")
        adaptive_size = AdaptiveUI.scale_value(base_size)
        print(f"Debug: Adaptive font size: {base_size} -> {adaptive_size}")
        return adaptive_size
    
    @staticmethod
    def get_adaptive_spacing(base_spacing):
        """Get adaptive spacing based on screen size."""
        print(f"Debug: AdaptiveUI.get_adaptive_spacing called with base_spacing: {base_spacing}")
        adaptive_spacing = AdaptiveUI.scale_value(base_spacing)
        print(f"Debug: Adaptive spacing: {base_spacing} -> {adaptive_spacing}")
        return adaptive_spacing
    
    @staticmethod
    def get_adaptive_padding(base_padding):
        """Get adaptive padding based on screen size."""
        print(f"Debug: AdaptiveUI.get_adaptive_padding called with base_padding: {base_padding}")
        adaptive_padding = AdaptiveUI.scale_value(base_padding)
        print(f"Debug: Adaptive padding: {base_padding} -> {adaptive_padding}")
        return adaptive_padding

class ElegantButton(QPushButton):
    """Custom elegant button with modern styling and adaptive sizing."""
    
    def __init__(self, text="", primary=False, icon=None):
        print(f"Debug: ElegantButton.__init__ called with text: {text}, primary: {primary}")
        super().__init__(text)
        self.primary = primary
        
        # Set proper font for Arabic text
        font = QFont("Tahoma", 9)
        self.setFont(font)
        
        print(f"Debug: Setting up styling for elegant button")
        self.setup_styling()
        if icon:
            print(f"Debug: Setting icon for elegant button")
            self.setIcon(icon)
        print(f"Debug: ElegantButton initialization completed")
    
    def setup_styling(self):
        print(f"Debug: ElegantButton.setup_styling called for primary: {self.primary}")
        # Get adaptive values
        padding_h = AdaptiveUI.scale_value(24)
        padding_v = AdaptiveUI.scale_value(12)
        font_size = AdaptiveUI.get_adaptive_font_size(14)
        border_radius = AdaptiveUI.scale_value(8)
        
        print(f"Debug: Adaptive values - padding_h: {padding_h}, padding_v: {padding_v}, font_size: {font_size}, border_radius: {border_radius}")
        
        if self.primary:
            print(f"Debug: Setting primary button styling")
            self.setStyleSheet(f"""
                QPushButton {{
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #4f46e5, stop:1 #3730a3);
                    color: white;
                    border: none;
                    border-radius: {border_radius}px;
                    padding: {padding_v}px {padding_h}px;
                    font-weight: bold;
                    font-size: {font_size}px;
                    font-family: 'Tahoma', Arial, sans-serif;
                }}
                QPushButton:hover {{
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #6366f1, stop:1 #4f46e5);
                }}
                QPushButton:pressed {{
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #3730a3, stop:1 #312e81);
                }}
            """)
        else:
            print(f"Debug: Setting secondary button styling")
            self.setStyleSheet(f"""
                QPushButton {{
                    background: white;
                    color: #374151;
                    border: 2px solid #e5e7eb;
                    border-radius: {border_radius}px;
                    padding: {AdaptiveUI.scale_value(10)}px {AdaptiveUI.scale_value(20)}px;
                    font-weight: 600;
                    font-size: {AdaptiveUI.get_adaptive_font_size(13)}px;
                    font-family: 'Tahoma', Arial, sans-serif;
                }}
                QPushButton:hover {{
                    border-color: #d1d5db;
                    background: #f9fafb;
                }}
                QPushButton:pressed {{
                    background: #f3f4f6;
                }}
            """)
        
        print(f"Debug: ElegantButton styling completed")

class ElegantGroupBox(QGroupBox):
    """Custom elegant group box with modern styling and adaptive sizing."""
    
    def __init__(self, title=""):
        print(f"Debug: ElegantGroupBox.__init__ called with title: {title}")
        super().__init__(title)
        print(f"Debug: Setting up styling for elegant group box")
        self.setup_styling()
        print(f"Debug: ElegantGroupBox initialization completed")
    
    def setup_styling(self):
        print(f"Debug: ElegantGroupBox.setup_styling called")
        # Get adaptive values
        font_size = AdaptiveUI.get_adaptive_font_size(16)
        border_radius = AdaptiveUI.scale_value(12)
        margin_top = AdaptiveUI.scale_value(16)
        padding_top = AdaptiveUI.scale_value(16)
        title_padding = AdaptiveUI.scale_value(8)
        title_left = AdaptiveUI.scale_value(16)
        
        print(f"Debug: Adaptive values - font_size: {font_size}, border_radius: {border_radius}, margin_top: {margin_top}, padding_top: {padding_top}, title_padding: {title_padding}, title_left: {title_left}")
        
        self.setStyleSheet(f"""
            QGroupBox {{
                font-weight: bold;
                font-size: {font_size}px;
                color: #111827;
                border: 2px solid #e5e7eb;
                border-radius: {border_radius}px;
                margin-top: {margin_top}px;
                padding-top: {padding_top}px;
                background: white;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
            QGroupBox::title {{
                subcontrol-origin: margin;
                left: {title_left}px;
                padding: 0 {title_padding}px 0 {title_padding}px;
                background: white;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
        """)
        
        print(f"Debug: ElegantGroupBox styling completed")

class ElegantTableWidget(QTableWidget):
    """Custom elegant table with modern styling and adaptive sizing."""
    
    def __init__(self):
        print(f"Debug: ElegantTableWidget.__init__ called")
        super().__init__()
        print(f"Debug: Setting up styling for elegant table widget")
        self.setup_styling()
        print(f"Debug: ElegantTableWidget initialization completed")
    
    def setup_styling(self):
        print(f"Debug: ElegantTableWidget.setup_styling called")
        # Get adaptive values
        border_radius = AdaptiveUI.scale_value(8)
        item_padding = AdaptiveUI.scale_value(12)
        header_padding_h = AdaptiveUI.scale_value(12)
        header_padding_v = AdaptiveUI.scale_value(16)
        header_font_size = AdaptiveUI.get_adaptive_font_size(14)
        
        print(f"Debug: Adaptive values - border_radius: {border_radius}, item_padding: {item_padding}, header_padding_h: {header_padding_h}, header_padding_v: {header_padding_v}, header_font_size: {header_font_size}")
        
        self.setStyleSheet(f"""
            QTableWidget {{
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: {border_radius}px;
                gridline-color: #f3f4f6;
                selection-background-color: #dbeafe;
                selection-color: #1e40af;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
            QTableWidget::item {{
                padding: {item_padding}px;
                border-bottom: 1px solid #f3f4f6;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
            QTableWidget::item:selected {{
                background: #dbeafe;
                color: #1e40af;
            }}
            QHeaderView::section {{
                background: #f9fafb;
                color: #374151;
                padding: {header_padding_v}px {header_padding_h}px;
                border: none;
                border-bottom: 2px solid #e5e7eb;
                font-weight: bold;
                font-size: {header_font_size}px;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
        """)
        self.setAlternatingRowColors(True)
        self.setShowGrid(False)
        self.verticalHeader().setVisible(False)
        
        print(f"Debug: ElegantTableWidget styling completed")

class EmployeeDialog(QDialog):
    """Elegant dialog for adding/editing employees with adaptive sizing."""
    
    def __init__(self, parent=None, employee=None):
        print(f"Debug: EmployeeDialog.__init__ called for employee: {employee.employee_id if employee else 'None'}")
        super().__init__(parent)
        self.employee = employee
        self.photo_path = ""
        print(f"Debug: Setting up UI for employee dialog")
        self.setup_ui()
        
        if employee:
            print(f"Debug: Loading existing employee data")
            self.load_employee_data()
        else:
            print(f"Debug: Creating new employee")
        
        print(f"Debug: EmployeeDialog initialization completed")
    
    def setup_ui(self):
        print(f"Debug: EmployeeDialog.setup_ui called")
        self.setWindowTitle("کارمند جدید" if not self.employee else "ویرایش کارمند")
        self.setModal(True)
        
        # Adaptive sizing
        base_width = 500
        base_height = 400
        scale_factor = AdaptiveUI.get_scale_factor()
        self.resize(int(base_width * scale_factor), int(base_height * scale_factor))
        
        self.setStyleSheet("""
            QDialog {
                background: #f8fafc;
            }
        """)
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(20)
        layout_margins = AdaptiveUI.scale_value(30)
        form_spacing = AdaptiveUI.get_adaptive_spacing(15)
        title_font_size = AdaptiveUI.get_adaptive_font_size(18)
        label_font_size = AdaptiveUI.get_adaptive_font_size(14)
        input_padding = AdaptiveUI.scale_value(12)
        input_border_radius = AdaptiveUI.scale_value(8)
        photo_size = AdaptiveUI.scale_value(120)
        button_padding_h = AdaptiveUI.scale_value(24)
        button_padding_v = AdaptiveUI.scale_value(12)
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Title
        title = QLabel("اطلاعات کارمند")
        title.setFont(QFont("Tahoma", title_font_size, QFont.Bold))
        title.setStyleSheet("color: #111827; margin-bottom: 10px; font-family: 'Tahoma', Arial, sans-serif;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Form layout
        print(f"Debug: Creating form layout")
        form_layout = QFormLayout()
        form_layout.setSpacing(form_spacing)
        
        # Style the form fields
        self.first_name_edit = QLineEdit()
        self.last_name_edit = QLineEdit()
        
        # Role field with predefined options and custom input capability
        self.role_combo = QComboBox()
        self.role_combo.setEditable(True)
        self.role_combo.setInsertPolicy(QComboBox.InsertAtBottom)
        
        # Add common Persian business roles
        common_roles = [
            "مدیر ارشد",
            "مدیر",
            "معاون مدیر",
            "کارشناس ارشد",
            "کارشناس",
            "کارشناس فنی",
            "مهندس ارشد",
            "مهندس",
            "کارمند ارشد",
            "کارمند",
            "کارمند اداری",
            "کارمند فنی",
            "کارآموز",
            "کارشناس کنترل کیفیت",
            "کارشناس منابع انسانی",
            "کارشناس مالی",
            "کارشناس فروش",
            "کارشناس بازاریابی",
            "کارشناس IT",
            "کارشناس امنیت",
            "کارشناس شبکه",
            "کارشناس پایگاه داده",
            "کارشناس پشتیبانی",
            "کارشناس آموزش",
            "کارشناس تحقیق و توسعه"
        ]
        
        self.role_combo.addItems(common_roles)
        self.role_combo.setCurrentText("")
        
        # Add helpful tooltip and placeholder
        self.role_combo.setToolTip("انتخاب از نقش‌های پیش‌فرض یا تایپ نقش سفارشی")
        self.role_combo.lineEdit().setPlaceholderText("انتخاب یا تایپ نقش...")
        
        # Style the combo box to match other form fields
        min_width = AdaptiveUI.scale_value(200)
        self.role_combo.setStyleSheet(f"""
            QComboBox {{
                padding: {input_padding}px;
                border: 2px solid #e5e7eb;
                border-radius: {input_border_radius}px;
                font-size: {label_font_size}px;
                background: white;
                min-width: {min_width}px;
            }}
            QComboBox:focus {{
                border-color: #4f46e5;
                outline: none;
            }}
            QComboBox::drop-down {{
                border: none;
                width: {AdaptiveUI.scale_value(30)}px;
            }}
            QComboBox::down-arrow {{
                image: none;
                border-left: {AdaptiveUI.scale_value(5)}px solid transparent;
                border-right: {AdaptiveUI.scale_value(5)}px solid transparent;
                border-top: {AdaptiveUI.scale_value(5)}px solid #6b7280;
                margin: 0 {AdaptiveUI.scale_value(10)}px;  /* RTL compatible margin */
            }}
            QComboBox QAbstractItemView {{
                border: 2px solid #e2e8f0;
                border-radius: {input_border_radius}px;
                background: white;
                selection-background-color: #4f46e5;
                selection-color: white;
            }}
        """)
        
        for edit in [self.first_name_edit, self.last_name_edit]:
            edit.setStyleSheet(f"""
                QLineEdit {{
                    padding: {input_padding}px;
                    border: 2px solid #e5e7eb;
                    border-radius: {input_border_radius}px;
                    font-size: {label_font_size}px;
                    background: white;
                }}
                QLineEdit:focus {{
                    border-color: #4f46e5;
                    outline: none;
                }}
            """)
        
        # Create styled labels
        first_name_label = QLabel("نام:")
        first_name_label.setStyleSheet(f"color: #374151; font-weight: 600; font-size: {label_font_size}px;")
        
        last_name_label = QLabel("نام خانوادگی:")
        last_name_label.setStyleSheet(f"color: #374151; font-weight: 600; font-size: {label_font_size}px;")
        
        role_label = QLabel("سمت:")
        role_label.setStyleSheet(f"color: #374151; font-weight: 600; font-size: {label_font_size}px;")
        
        form_layout.addRow(first_name_label, self.first_name_edit)
        form_layout.addRow(last_name_label, self.last_name_edit)
        form_layout.addRow(role_label, self.role_combo)
        
        # Photo section
        print(f"Debug: Creating photo section")
        photo_layout = QHBoxLayout()
        photo_layout.setSpacing(AdaptiveUI.get_adaptive_spacing(20))
        
        self.photo_label = QLabel("بدون عکس")
        self.photo_label.setFixedSize(photo_size, photo_size)
        self.photo_label.setScaledContents(True)
        self.photo_label.setStyleSheet(f"""
            border: 3px dashed #d1d5db;
            border-radius: {photo_size//2}px;
            background: #f9fafb;
            color: #6b7280;
            font-size: {AdaptiveUI.get_adaptive_font_size(12)}px;
        """)
        self.photo_label.setAlignment(Qt.AlignCenter)
        
        photo_controls = QVBoxLayout()
        self.photo_btn = ElegantButton("انتخاب عکس")
        self.photo_btn.clicked.connect(self.select_photo)
        
        self.remove_photo_btn = ElegantButton("حذف عکس")
        self.remove_photo_btn.clicked.connect(self.remove_photo)
        self.remove_photo_btn.setVisible(False)
        
        photo_controls.addWidget(self.photo_btn)
        photo_controls.addWidget(self.remove_photo_btn)
        photo_controls.addStretch()
        
        photo_layout.addWidget(self.photo_label)
        photo_layout.addLayout(photo_controls)
        photo_layout.addStretch()
        
        # Buttons
        print(f"Debug: Creating buttons")
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        
        cancel_btn = ElegantButton("انصراف")
        cancel_btn.clicked.connect(self.reject)
        
        save_btn = ElegantButton("ذخیره", primary=True)
        save_btn.clicked.connect(self.accept)
        
        button_layout.addWidget(cancel_btn)
        button_layout.addWidget(save_btn)
        
        layout.addLayout(form_layout)
        layout.addLayout(photo_layout)
        layout.addLayout(button_layout)
        
        self.setLayout(layout)
        print(f"Debug: EmployeeDialog UI setup completed")
    
    def select_photo(self):
        print(f"Debug: EmployeeDialog.select_photo called")
        file_path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب عکس", "", "Images (*.png *.jpg *.jpeg)"
        )
        if file_path:
            print(f"Debug: Photo selected: {file_path}")
            # Copy photo to data directory
            copied_path = self._copy_photo_to_data_dir(file_path)
            if copied_path:
                self.photo_path = copied_path
                # Load pixmap from the copied file (absolute path)
                copied_absolute_path = os.path.join(os.getcwd(), "data", copied_path)
                pixmap = QPixmap(copied_absolute_path)
                if not pixmap.isNull():
                    print(f"Debug: Photo loaded successfully from: {copied_absolute_path}")
                    scaled_pixmap = pixmap.scaled(120, 120, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    print(f"Debug: Scaled pixmap size: {scaled_pixmap.size()}")
                    self.photo_label.clear()  # Clear any existing text
                    self.photo_label.setPixmap(scaled_pixmap)
                    self.photo_label.setStyleSheet("border: 3px solid #10b981; border-radius: 60px;")
                    self.remove_photo_btn.setVisible(True)
                    print(f"Debug: Photo pixmap set on label")
                else:
                    print(f"Debug: Failed to load photo from: {copied_absolute_path}")
            else:
                print(f"Debug: Failed to copy photo to data directory")
        else:
            print(f"Debug: No photo selected")
    
    def _copy_photo_to_data_dir(self, source_path):
        """Copy photo to data directory and return the relative path."""
        try:
            import shutil
            
            # Get data directory
            data_dir = os.path.join(os.getcwd(), "data", "images", "staff")
            os.makedirs(data_dir, exist_ok=True)
            
            # Generate unique filename
            file_ext = os.path.splitext(source_path)[1]
            timestamp = int(datetime.now().timestamp())
            filename = f"EMP_{timestamp}{file_ext}"
            dest_path = os.path.join(data_dir, filename)
            
            # Copy file
            shutil.copy2(source_path, dest_path)
            
            # Return relative path from data directory
            relative_path = os.path.join("images", "staff", filename)
            print(f"Debug: Photo copied to: {relative_path}")
            return relative_path
            
        except Exception as e:
            print(f"Debug: Error copying photo: {e}")
            return None
    
    def remove_photo(self):
        print(f"Debug: EmployeeDialog.remove_photo called")
        self.photo_path = ""
        self.photo_label.clear()
        self.photo_label.setText("بدون عکس")
        self.photo_label.setStyleSheet("""
            border: 3px dashed #d1d5db;
            border-radius: 60px;
            background: #f9fafb;
            color: #6b7280;
            font-size: 12px;
        """)
        self.remove_photo_btn.setVisible(False)
        print(f"Debug: Photo removed successfully")
    
    def load_employee_data(self):
        print(f"Debug: EmployeeDialog.load_employee_data called for employee: {self.employee.employee_id if self.employee else 'None'}")
        if self.employee:
            print(f"Debug: Loading data for employee: {self.employee.first_name} {self.employee.last_name}")
            self.first_name_edit.setText(self.employee.first_name)
            self.last_name_edit.setText(self.employee.last_name)
            self.role_combo.setCurrentText(self.employee.role)
            
            if self.employee.photo_path:
                print(f"Debug: Employee has photo path: {self.employee.photo_path}")
                self.photo_path = self.employee.photo_path
                # Use the employee's photo pixmap method which handles path resolution
                pixmap = self.employee.get_photo_pixmap(QSize(120, 120))
                if not pixmap.isNull():
                    print(f"Debug: Photo loaded successfully, size: {pixmap.size()}")
                    self.photo_label.clear()  # Clear any existing text
                    self.photo_label.setPixmap(pixmap)
                    self.photo_label.setStyleSheet("border: 3px solid #10b981; border-radius: 60px;")
                    self.remove_photo_btn.setVisible(True)
                    print(f"Debug: Photo pixmap set on label for existing employee")
                else:
                    print(f"Debug: Failed to load photo")
            else:
                print(f"Debug: Employee has no photo path")
        else:
            print(f"Debug: No employee to load data from")
    
    def get_employee_data(self):
        print(f"Debug: EmployeeDialog.get_employee_data called")
        data = {
            'first_name': self.first_name_edit.text().strip(),
            'last_name': self.last_name_edit.text().strip(),
            'role': self.role_combo.currentText().strip(),
            'photo_path': self.photo_path
        }
        print(f"Debug: Employee data retrieved: {data}")
        return data

class ShiftWidget(QWidget):
    """Elegant widget for displaying and managing a shift with adaptive sizing."""
    
    def __init__(self, shift_type: str, controller: MainController):
        super().__init__()
        print(f"Debug: ShiftWidget.__init__ called for shift_type: {shift_type}")
        self.shift_type = shift_type
        self.controller = controller
        print(f"Debug: Setting up UI for {shift_type} shift")
        self.setup_ui()
        print(f"Debug: Updating display for {shift_type} shift")
        self.update_display()
        print(f"Debug: ShiftWidget initialization completed for {shift_type} shift")
    
    def setup_ui(self):
        print(f"Debug: ShiftWidget.setup_ui called for {self.shift_type} shift")
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(20)
        layout_margins = AdaptiveUI.scale_value(20)
        grid_spacing = AdaptiveUI.get_adaptive_spacing(15)
        title_font_size = AdaptiveUI.get_adaptive_font_size(16)
        icon_font_size = AdaptiveUI.get_adaptive_font_size(24)
        slot_size = AdaptiveUI.scale_value(110)  # Increased to accommodate name text
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Header
        header_layout = QHBoxLayout()
        
        # Title with icon
        title_container = QWidget()
        title_layout = QHBoxLayout()
        title_layout.setContentsMargins(0, 0, 0, 0)
        
        # Shift icon (using text as icon for now)
        icon_label = QLabel("🌅" if self.shift_type == "morning" else "🌆")
        icon_label.setFont(QFont("Tahoma", icon_font_size))
        
        title_label = QLabel("شیفت صبح" if self.shift_type == "morning" else "شیفت عصر")
        title_label.setFont(QFont("Tahoma", title_font_size, QFont.Bold))
        title_label.setStyleSheet("color: #111827; font-family: 'Tahoma', Arial, sans-serif;")
        
        title_layout.addWidget(icon_label)
        title_layout.addWidget(title_label)
        title_container.setLayout(title_layout)
        
        # Clear button
        self.clear_btn = ElegantButton("پاک کردن")
        self.clear_btn.clicked.connect(self.clear_shift)
        
        header_layout.addWidget(title_container)
        header_layout.addStretch()
        header_layout.addWidget(self.clear_btn)
        
        # Employee grid - Dynamic layout based on current capacity setting
        self.employee_grid = QGridLayout()
        self.employee_grid.setSpacing(grid_spacing)
        self.employee_slots = []
        
        # Get current capacity from controller settings
        current_capacity = self.controller.settings.get("shift_capacity", 10)
        print(f"Debug: Creating {current_capacity} employee slots for {self.shift_type} shift (capacity: {current_capacity})")
        
        # Calculate optimal grid layout based on capacity
        # For capacity <= 5: 1 row
        # For capacity 6-10: 2 rows
        # For capacity > 10: 3+ rows
        if current_capacity <= 5:
            cols = current_capacity
            rows = 1
        elif current_capacity <= 10:
            cols = 5
            rows = 2
        else:
            cols = 5
            rows = (current_capacity + 4) // 5  # Ceiling division
        
        print(f"Debug: Grid layout: {rows} rows × {cols} columns for capacity {current_capacity}")
        
        # Create droppable employee slots based on current capacity
        for i in range(current_capacity):
            from management_app.widgets.draggable_employee import DroppableShiftSlot
            
            slot = DroppableShiftSlot(i, self.shift_type)
            slot.setFixedSize(slot_size, slot_size)
            
            # Connect the drop signal
            if hasattr(slot, 'employee_dropped'):
                slot.employee_dropped.connect(self.handle_employee_drop)
                print(f"Debug: Connected employee_dropped signal for slot {i}")
            else:
                print(f"Debug: Warning: slot {i} has no employee_dropped signal")
            
            self.employee_slots.append(slot)
            # Calculate grid position: row = i // cols, column = i % cols
            grid_row = i // cols
            grid_col = i % cols
            self.employee_grid.addWidget(slot, grid_row, grid_col)
            print(f"Debug: Added slot {i} to grid at position ({grid_row}, {grid_col})")
        
        layout.addLayout(header_layout)
        layout.addLayout(self.employee_grid)
        layout.addStretch()
        
        self.setLayout(layout)
        print(f"Debug: ShiftWidget UI setup completed for {self.shift_type} shift with {current_capacity} slots")
    

    
    def handle_employee_drop(self, slot_index, shift_type, employee_data_str):
        """Handle employee drop into shift slot."""
        print(f"Debug: ShiftWidget.handle_employee_drop called for slot {slot_index}, shift_type: {shift_type}, employee_data_str: {employee_data_str}")
        
        try:
            # Parse employee data from drag operation
            import json
            import ast
            
            # Try JSON first, then fall back to ast.literal_eval
            try:
                employee_data = json.loads(employee_data_str)
                print(f"Debug: Parsed employee data as JSON: {employee_data}")
            except json.JSONDecodeError:
                print(f"Debug: JSON parsing failed, trying ast.literal_eval")
                employee_data = ast.literal_eval(employee_data_str)
                print(f"Debug: Parsed employee data as string: {employee_data}")
            
            employee_id = employee_data.get("employee_id")
            print(f"Debug: Employee ID from drop: {employee_id}")
            
            # Validate employee data
            if not employee_id:
                print(f"Debug: No employee_id in drop data")
                QMessageBox.warning(self, "خطا", "اطلاعات کارمند نامعتبر است")
                return
            
            # Get employee from controller
            employee = self.controller.get_employee_by_id(employee_id)
            if not employee:
                print(f"Debug: Employee not found for ID: {employee_id}")
                QMessageBox.warning(self, "خطا", f"کارمند با شناسه {employee_id} یافت نشد")
                return
            
            print(f"Debug: Found employee: {employee.employee_id} - {employee.first_name} {employee.last_name}")
            
            # Validate slot index
            if slot_index < 0 or slot_index >= self.controller.shift_manager.capacity:
                print(f"Debug: Invalid slot index: {slot_index}")
                QMessageBox.warning(self, "خطا", f"شماره شیفت {slot_index} نامعتبر است")
                return
            
            # Add employee to shift
            success = self.controller.assign_employee_to_shift(employee, shift_type, slot_index)
            print(f"Debug: assign_employee_to_shift result: {success}")
            
            if success:
                # Signal will be emitted by the controller, no need to emit here
                print(f"Debug: Employee assignment successful, controller will emit signal")
            else:
                print(f"Debug: Failed to assign employee to shift")
                # Don't show error dialog here as the controller already handles it
                
        except ValueError as e:
            print(f"Debug: ValueError in handle_employee_drop: {e}")
            QMessageBox.warning(self, "خطا", "اطلاعات کارمند نامعتبر است")
        except Exception as e:
            print(f"Debug: Exception in handle_employee_drop: {e}")
            QMessageBox.warning(self, "خطا", f"خطا در اضافه کردن کارمند: {e}")
    
    def update_display(self):
        print(f"Debug: ShiftWidget.update_display called for {self.shift_type} shift")
        shift = self.controller.shift_manager.get_shift(self.shift_type)
        if not shift:
            print(f"Debug: No shift found for {self.shift_type}")
            return
        
        print(f"Debug: Found shift for {self.shift_type}, assigned employees: {len(shift.assigned_employees) if hasattr(shift, 'assigned_employees') else 'No assigned_employees attribute'}")
        
        # Ensure we have the right number of slots for current capacity
        current_capacity = self.controller.shift_manager.capacity
        print(f"Debug: Checking slot count: slots={len(self.employee_slots)}, capacity={current_capacity}")
        if len(self.employee_slots) != current_capacity:
            print(f"Debug: Slot count mismatch: slots={len(self.employee_slots)}, capacity={current_capacity}")
            print(f"Debug: Refreshing layout to fix slot count")
            self.refresh_layout()
            # refresh_layout() now handles display update internally, so we can return here
            return
        
        # Also check if the shift's assigned_employees list matches our capacity
        if hasattr(shift, 'assigned_employees'):
            assigned_count = len(shift.assigned_employees)
            print(f"Debug: Checking assigned employees count: {assigned_count} vs capacity {current_capacity}")
            if assigned_count != current_capacity:
                print(f"Debug: Shift assigned_employees length mismatch: {assigned_count} vs capacity {current_capacity}")
                print(f"Debug: Refreshing layout to fix capacity mismatch")
                self.refresh_layout()
                # refresh_layout() now handles display update internally, so we can return here
                return
        
        # Clear all slots first
        for slot in self.employee_slots:
            slot.set_employee(None)
        
        # Fill slots with assigned employees
        if hasattr(shift, 'assigned_employees'):
            for i, employee in enumerate(shift.assigned_employees):
                if i < len(self.employee_slots) and employee is not None:
                    print(f"Debug: Setting employee {employee.employee_id} in slot {i} for {self.shift_type} shift")
                    slot = self.employee_slots[i]
                    slot.set_employee(employee)
                elif i < len(self.employee_slots):
                    print(f"Debug: Slot {i} is None for {self.shift_type} shift")
                else:
                    print(f"Debug: Slot {i} is out of range for {self.shift_type} shift")
        else:
            print(f"Debug: Shift object has no assigned_employees attribute")
    
    def clear_shift(self):
        print(f"Debug: ShiftWidget.clear_shift called for {self.shift_type} shift")
        
        print(f"Debug: Clearing shift")
        reply = QMessageBox.question(
            self, "تایید", "آیا مطمئن هستید که می‌خواهید این شیفت را پاک کنید؟",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            print(f"Debug: User confirmed shift clear")
            self.controller.clear_shift(self.shift_type)
            self.update_display()
    
    def refresh_layout(self):
        """Refresh the layout when capacity changes."""
        print(f"Debug: ShiftWidget.refresh_layout called for {self.shift_type} shift")
        
        # Get current capacity directly from shift manager
        current_capacity = self.controller.shift_manager.capacity
        print(f"Debug: Refresh layout using capacity from shift manager: {current_capacity}")
        
        # Clear existing grid layout
        if hasattr(self, 'employee_grid'):
            # Remove all widgets from the grid
            while self.employee_grid.count():
                child = self.employee_grid.itemAt(0).widget()
                if child:
                    child.deleteLater()
                self.employee_grid.removeItem(self.employee_grid.itemAt(0))
            
            # Clear slots list
            self.employee_slots.clear()
        
        # Get adaptive values
        grid_spacing = AdaptiveUI.get_adaptive_spacing(15)
        slot_size = AdaptiveUI.scale_value(110)  # Increased to accommodate name text
        
        # Calculate optimal grid layout based on capacity
        # For capacity <= 5: 1 row
        # For capacity 6-10: 2 rows
        # For capacity > 10: 3+ rows
        if current_capacity <= 5:
            cols = current_capacity
            rows = 1
        elif current_capacity <= 10:
            cols = 5
            rows = 2
        else:
            cols = 5
            rows = (current_capacity + 4) // 5  # Ceiling division
        
        print(f"Debug: Grid layout: {rows} rows × {cols} columns for capacity {current_capacity}")
        
        # Create droppable employee slots based on specified capacity
        for i in range(current_capacity):
            from management_app.widgets.draggable_employee import DroppableShiftSlot
            
            slot = DroppableShiftSlot(i, self.shift_type)
            slot.setFixedSize(slot_size, slot_size)
            
            # Connect the drop signal
            if hasattr(slot, 'employee_dropped'):
                slot.employee_dropped.connect(self.handle_employee_drop)
                print(f"Debug: Connected employee_dropped signal for slot {i}")
            else:
                print(f"Debug: Warning: slot {i} has no employee_dropped signal")
            
            self.employee_slots.append(slot)
            # Calculate grid position: row = i // cols, column = i % cols
            grid_row = i // cols
            grid_col = i % cols
            self.employee_grid.addWidget(slot, grid_row, grid_col)
            print(f"Debug: Added slot {i} to grid at position ({grid_row}, {grid_col})")
        
        print(f"Debug: Refresh layout completed for {self.shift_type} shift with {current_capacity} slots")
        
        # Update the display with current data after refreshing layout
        self._update_display_after_layout_refresh()
    
    def _update_display_after_layout_refresh(self):
        """Update display after layout refresh without causing recursion."""
        try:
            print(f"Debug: _update_display_after_layout_refresh called for {self.shift_type} shift")
            
            # Get the shift data
            shift = self.controller.shift_manager.get_shift(self.shift_type)
            if not shift:
                print(f"Debug: No shift found for {self.shift_type}")
                return
            
            print(f"Debug: Found shift for {self.shift_type}, assigned employees: {len(shift.assigned_employees) if hasattr(shift, 'assigned_employees') else 'No assigned_employees attribute'}")
            
            # Clear all slots first
            for slot in self.employee_slots:
                slot.set_employee(None)
            
            # Fill slots with assigned employees
            if hasattr(shift, 'assigned_employees'):
                for i, employee in enumerate(shift.assigned_employees):
                    if i < len(self.employee_slots) and employee is not None:
                        print(f"Debug: Setting employee {employee.employee_id} in slot {i} for {self.shift_type} shift")
                        slot = self.employee_slots[i]
                        slot.set_employee(employee)
                    elif i < len(self.employee_slots):
                        print(f"Debug: Slot {i} is None for {self.shift_type} shift")
                    else:
                        print(f"Debug: Slot {i} is out of range for {self.shift_type} shift")
            else:
                print(f"Debug: Shift object has no assigned_employees attribute")
                
        except Exception as e:
            print(f"Debug: Error in _update_display_after_layout_refresh: {e}")
            import traceback
            traceback.print_exc()
    
    def get_employees(self):
        """Get list of employees assigned to this shift."""
        shift = self.controller.shift_manager.get_shift(self.shift_type)
        if not shift or not hasattr(shift, 'assigned_employees'):
            return []
        
        # Filter out None values and return actual employees
        employees = []
        for employee in shift.assigned_employees:
            if employee is not None:
                employees.append(employee)
        
        return employees
    
    # Removed duplicate handle_employee_drop method

class MainWindow(QMainWindow):
    """Elegant main window for the management application."""
    
    def __init__(self):
        super().__init__()
        print(f"Debug: MainWindow.__init__ called")
        print(f"Debug: Current working directory: {os.getcwd()}")
        print(f"Debug: Executable path: {sys.executable if hasattr(sys, 'executable') else 'Not frozen'}")
        
        # Get the correct data directory path
        data_dir = self._get_data_directory()
        print(f"Debug: Using data directory: {data_dir}")
        
        self.controller = MainController(data_dir)
        
        # Initialize export service
        self.export_service = ExportService(data_dir)
        
        self.setup_ui()
        self.setup_connections()
        self.setup_timer()
        # Update displays after UI is fully set up
        self.update_employee_display()
        self.update_shift_displays()
        self.update_settings_display()
        # Ensure the window is properly configured
        self.setVisible(True)
        self.setWindowState(Qt.WindowMaximized)
        self.raise_()
        self.activateWindow()
    
    def _get_data_directory(self) -> str:
        """Get the correct data directory path."""
        # If running as exe, look for data directory relative to exe location
        if getattr(sys, 'frozen', False):
            # Running as compiled exe
            exe_dir = os.path.dirname(sys.executable)
            data_dir = os.path.join(exe_dir, "data")
            
            # If data directory doesn't exist in exe location, try current working directory
            if not os.path.exists(data_dir):
                data_dir = os.path.join(os.getcwd(), "data")
            
            print(f"Debug: Frozen executable detected, exe_dir: {exe_dir}")
            print(f"Debug: Data directory path: {data_dir}")
            print(f"Debug: Data directory exists: {os.path.exists(data_dir)}")
        else:
            # Running as script
            data_dir = "data"
            print(f"Debug: Running as script, using data_dir: {data_dir}")
        
        return data_dir
    

    
    def setup_ui(self):
        print(f"Debug: MainWindow.setup_ui called")
        self.setWindowTitle("سیستم مدیریت شیفت کارمندان")
        
        # Set RTL layout direction for the main window
        self.setLayoutDirection(Qt.RightToLeft)
        
        # Adaptive window sizing based on screen size
        base_width = 1400
        base_height = 900
        scale_factor = AdaptiveUI.get_scale_factor()
        window_width = int(base_width * scale_factor)
        window_height = int(base_height * scale_factor)
        
        # Ensure window fits on screen
        app = QApplication.instance()
        if app:
            screen = app.primaryScreen()
            screen_size = screen.size()
            max_width = int(screen_size.width() * 0.95)  # 95% of screen width
            max_height = int(screen_size.height() * 0.95)  # 95% of screen height
            
            window_width = min(window_width, max_width)
            window_height = min(window_height, max_height)
        
        self.setGeometry(100, 100, window_width, window_height)
        
        self.setStyleSheet("""
            QMainWindow {
                background: #f8fafc;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout - RTL compliant
        main_layout = QHBoxLayout()
        main_layout.setSpacing(0)
        main_layout.setContentsMargins(0, 0, 0, 0)
        
        # Right panel - Employee management (for RTL layout)
        print(f"Debug: Creating employee panel")
        right_panel = self.create_employee_panel()
        
        # Left panel - Shift management (for RTL layout)
        print(f"Debug: Creating shift panel")
        left_panel = self.create_shift_panel()
        
        # Splitter with adaptive sizing - RTL order
        splitter = QSplitter(Qt.Horizontal)
        splitter.addWidget(right_panel)  # Employee management on the right
        splitter.addWidget(left_panel)   # Shift management on the left
        
        # Adaptive splitter sizes based on screen width - RTL adjusted
        if window_width < 1200:
            # Small screens: more space for employee panel (right side)
            splitter.setSizes([int(600 * scale_factor), int(400 * scale_factor)])
        elif window_width < 1600:
            # Medium screens: balanced layout
            splitter.setSizes([int(700 * scale_factor), int(500 * scale_factor)])
        else:
            # Large screens: more space for shift management (left side)
            splitter.setSizes([int(800 * scale_factor), int(600 * scale_factor)])
        
        splitter.setStyleSheet(f"""
            QSplitter::handle {{
                background: #e5e7eb;
                width: {AdaptiveUI.scale_value(2)}px;
            }}
        """)
        
        main_layout.addWidget(splitter)
        central_widget.setLayout(main_layout)
        
        # Menu bar
        print(f"Debug: Creating menu bar")
        self.create_menu_bar()
        
        print(f"Debug: MainWindow UI setup completed")
    
    def create_employee_panel(self):
        print(f"Debug: MainWindow.create_employee_panel called")
        panel = QWidget()
        panel.setStyleSheet("background: white; border-left: 1px solid #e5e7eb;")  # RTL: border on left
        layout = QVBoxLayout()
        layout.setSpacing(15)  # Reduced from 20
        layout.setContentsMargins(20, 20, 20, 20)  # Reduced from 25
        
        # Header
        header = QLabel("مدیریت کارمندان")
        header.setFont(QFont("Tahoma", 18, QFont.Bold))  # Reduced from 20
        header.setStyleSheet("color: #111827; margin-bottom: 8px; font-family: 'Tahoma', Arial, sans-serif;")  # Reduced from 10px
        layout.addWidget(header)
        
        # Employee management group - only visible to users with employee management permissions
        if True:  # Permission check removed
            print(f"Debug: User has employee management permissions")
            emp_group = ElegantGroupBox("عملیات")
            emp_layout = QVBoxLayout()
            emp_layout.setSpacing(12)  # Reduced from 15
            
            # Add employee button
            self.add_emp_btn = ElegantButton("➕ افزودن کارمند", primary=True)
            self.add_emp_btn.clicked.connect(self.add_employee)
            
            # Import CSV button
            self.import_csv_btn = ElegantButton("📁 وارد کردن CSV")
            self.import_csv_btn.clicked.connect(self.import_csv)
            
            # Task management button
            self.manage_tasks_btn = ElegantButton("📋 مدیریت وظایف")
            self.manage_tasks_btn.clicked.connect(self.show_task_management)
            
            emp_layout.addWidget(self.add_emp_btn)
            emp_layout.addWidget(self.import_csv_btn)
            emp_layout.addWidget(self.manage_tasks_btn)
            emp_group.setLayout(emp_layout)
            layout.addWidget(emp_group)
        else:
            print(f"Debug: User does not have employee management permissions")
            # For non-admin users, show read-only message
            read_only_msg = QLabel("شما دسترسی به مدیریت کارمندان ندارید")
            read_only_msg.setStyleSheet("color: #6b7280; font-size: 14px; padding: 15px;")  # Reduced from 20px
            read_only_msg.setAlignment(Qt.AlignCenter)
            layout.addWidget(read_only_msg)
        
        # Employee list section - integrated draggable list for drag & drop
        print(f"Debug: Creating employee list section")
        table_group = ElegantGroupBox("لیست کارمندان (قابل کشیدن)")
        table_layout = QVBoxLayout()
        table_layout.setSpacing(15)
        table_layout.setContentsMargins(20, 20, 20, 20)
        
        # Info text
        info_label = QLabel("کارمندان را از اینجا به شیفت‌ها بکشید")
        info_label.setStyleSheet("color: #6b7280; font-size: 14px; text-align: center; margin-bottom: 15px;")
        info_label.setAlignment(Qt.AlignCenter)
        table_layout.addWidget(info_label)
        
        # Search input for employees
        search_container = QWidget()
        search_layout = QHBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 10)
        search_layout.setSpacing(10)
        
        search_label = QLabel("🔍 جستجو:")
        search_label.setStyleSheet("color: #374151; font-weight: 600; font-size: 12px;")
        
        self.employee_search_edit = QLineEdit()
        self.employee_search_edit.setPlaceholderText("جستجو بر اساس نام، نام خانوادگی یا نقش...")
        self.employee_search_edit.setStyleSheet("""
            QLineEdit {
                padding: 8px 12px;
                border: 2px solid #e5e7eb;
                border-radius: 8px;
                font-size: 12px;
                background: white;
                color: #374151;
            }
            QLineEdit:focus {
                border-color: #4f46e5;
                outline: none;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
            }
            QLineEdit::placeholder {
                color: #9ca3af;
                font-style: italic;
            }
        """)
        
        # Connect search functionality
        self.employee_search_edit.textChanged.connect(self.filter_employee_cards)
        
        search_layout.addWidget(search_label)
        search_layout.addWidget(self.employee_search_edit)
        search_layout.addStretch()
        
        search_container.setLayout(search_layout)
        table_layout.addWidget(search_container)
        
        # Draggable employee cards container
        print(f"Debug: Creating employee cards container")
        self.employee_cards_container = QWidget()
        self.employee_cards_layout = QVBoxLayout()
        self.employee_cards_layout.setSpacing(10)
        self.employee_cards_layout.setContentsMargins(0, 0, 0, 0)
        
        # Scroll area for employee cards
        self.employee_scroll_area = QScrollArea()
        self.employee_scroll_area.setWidgetResizable(True)
        self.employee_scroll_area.setStyleSheet("""
            QScrollArea {
                border: 1px solid #e2e8f0;
                border-radius: 8px;
                background: white;
            }
            QScrollBar:vertical {
                background: #f1f5f9;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 4px;
            }
        """)
        
        # Container widget for employee cards
        self.employee_cards_widget = QWidget()
        self.employee_cards_widget.setLayout(self.employee_cards_layout)
        self.employee_scroll_area.setWidget(self.employee_cards_widget)
        
        # Store all employee cards for filtering
        self.all_employee_cards = []
        
        # Set fixed height for employee list
        self.employee_scroll_area.setFixedHeight(300)
        
        table_layout.addWidget(self.employee_scroll_area)
        
        # Button to open detailed employee list modal (for editing)
        self.view_employees_btn = ElegantButton("✏️ ویرایش کارمندان", primary=False)
        self.view_employees_btn.clicked.connect(self.show_employee_list_modal)
        self.view_employees_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 10px 20px;
                font-weight: bold;
                font-size: 14px;
                min-width: 150px;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        
        # Center the button
        button_container = QWidget()
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.view_employees_btn)
        button_layout.addStretch()
        button_container.setLayout(button_layout)
        table_layout.addWidget(button_container)
        
        table_group.setLayout(table_layout)
        layout.addWidget(table_group)
        
        # Absence management group - now just a button to open the comprehensive modal
        if True:  # Permission check removed
            print(f"Debug: User has absence management permissions")
            absence_group = ElegantGroupBox("مدیریت غیبت")
            absence_layout = QVBoxLayout()
            absence_layout.setSpacing(15)
            
            # Info text explaining the modal approach
            info_label = QLabel("برای مدیریت کامل غیبت‌ها، روی دکمه زیر کلیک کنید")
            info_label.setStyleSheet("color: #6b7280; font-size: 14px; text-align: center; margin-bottom: 15px;")
            info_label.setAlignment(Qt.AlignCenter)
            absence_layout.addWidget(info_label)
            
            # Button to open comprehensive absence management modal
            self.open_absence_management_btn = ElegantButton("🔧 مدیریت غیبت‌ها", primary=True)
            self.open_absence_management_btn.clicked.connect(self.show_absence_management_modal)
            self.open_absence_management_btn.setStyleSheet("""
                QPushButton {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #8b5cf6, stop:1 #7c3aed);
                    color: white;
                    border: none;
                    border-radius: 12px;
                    padding: 18px 36px;
                    font-weight: bold;
                    font-size: 16px;
                    min-width: 220px;
                }
                QPushButton:hover {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #a78bfa, stop:1 #8b5cf6);
                }
                QPushButton:pressed {
                    background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                        stop:0 #7c3aed, stop:1 #6d28d9);
                }
            """)
            
            # Center the button
            button_container = QWidget()
            button_layout = QHBoxLayout()
            button_layout.addStretch()
            button_layout.addWidget(self.open_absence_management_btn)
            button_layout.addStretch()
            button_container.setLayout(button_layout)
            absence_layout.addWidget(button_container)
            
            absence_group.setLayout(absence_layout)
            layout.addWidget(absence_group)
        else:
            print(f"Debug: User does not have absence management permissions")
            # For users without absence management permissions, show read-only message
            read_only_absence_msg = QLabel("شما دسترسی به مدیریت غیبت ندارید")
            read_only_absence_msg.setStyleSheet("color: #6b7280; font-size: 14px; padding: 15px;")  # Reduced from 20px
            read_only_absence_msg.setAlignment(Qt.AlignCenter)
            layout.addWidget(read_only_absence_msg)
        
        layout.addStretch()
        panel.setLayout(layout)
        
        print(f"Debug: Employee panel creation completed")
        return panel
    
    def create_shift_panel(self):
        print(f"Debug: MainWindow.create_shift_panel called")
        panel = QWidget()
        panel.setStyleSheet("background: white; border-right: 1px solid #e5e7eb;")  # RTL: border on right
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(25)
        layout_margins = AdaptiveUI.scale_value(30)
        header_font_size = AdaptiveUI.get_adaptive_font_size(24)
        label_font_size = AdaptiveUI.get_adaptive_font_size(14)
        input_padding = AdaptiveUI.scale_value(10)
        input_border_radius = AdaptiveUI.scale_value(8)
        input_min_width = AdaptiveUI.scale_value(100)
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Header
        header = QLabel("مدیریت شیفت")
        header.setFont(QFont("Tahoma", header_font_size, QFont.Bold))
        header.setStyleSheet("color: #111827; margin-bottom: 10px; font-family: 'Tahoma', Arial, sans-serif;")
        layout.addWidget(header)
        
        # Settings group - visible to all users
        if True:  # Permission check removed
            print(f"Debug: User has settings management permissions")
            settings_group = ElegantGroupBox("تنظیمات")
            settings_layout = QFormLayout()
            settings_layout.setSpacing(AdaptiveUI.get_adaptive_spacing(15))
            
            # Capacity configuration with default 10, demo 5 as per specs
            capacity_label = QLabel("ظرفیت شیفت:")
            capacity_label.setStyleSheet(f"color: #374151; font-weight: 600; font-size: {label_font_size}px;")
            
            self.capacity_spin = QSpinBox()
            self.capacity_spin.setRange(1, 20)
            # Set default capacity from settings
            default_capacity = self.controller.settings.get("shift_capacity", 5)
            self.capacity_spin.setValue(default_capacity)
            self.capacity_spin.valueChanged.connect(lambda value: self.change_capacity(value))
            self.capacity_spin.setStyleSheet(f"""
                QSpinBox {{
                    padding: {input_padding}px;
                    border: 2px solid #e5e7eb;
                    border-radius: {input_border_radius}px;
                    font-size: {label_font_size}px;
                    background: white;
                    min-width: {input_min_width}px;
                }}
                QSpinBox:focus {{
                    border-color: #4f46e5;
                }}
            """)
            
            settings_layout.addRow(capacity_label, self.capacity_spin)
            settings_group.setLayout(settings_layout)
            layout.addWidget(settings_group)

        

        
        # Shift management group - visible to all users
        if True:  # Permission check removed
            print(f"Debug: User has shift management permissions")
            shift_group = ElegantGroupBox("شیفت‌ها")
            shift_layout = QHBoxLayout()
            shift_layout.setSpacing(AdaptiveUI.get_adaptive_spacing(30))
            
            # Morning shift
            print(f"Debug: Creating morning shift widget")
            self.morning_shift = ShiftWidget("morning", self.controller)
            
            # Evening shift
            print(f"Debug: Creating evening shift widget")
            self.evening_shift = ShiftWidget("evening", self.controller)
            
            shift_layout.addWidget(self.morning_shift)
            shift_layout.addWidget(self.evening_shift)
            shift_group.setLayout(shift_layout)
            layout.addWidget(shift_group)

        
        layout.addStretch()
        panel.setLayout(layout)
        
        print(f"Debug: Shift panel creation completed")
        return panel
    
    def create_menu_bar(self):
        print(f"Debug: MainWindow.create_menu_bar called")
        menubar = self.menuBar()
        
        # Get adaptive values
        menu_padding = AdaptiveUI.scale_value(8)
        menu_item_padding_h = AdaptiveUI.scale_value(16)
        menu_item_padding_v = AdaptiveUI.scale_value(8)
        menu_border_radius = AdaptiveUI.scale_value(6)
        menu_padding_v = AdaptiveUI.scale_value(8)
        menu_item_padding_h_inner = AdaptiveUI.scale_value(20)
        menu_item_padding_v_inner = AdaptiveUI.scale_value(8)
        
        menubar.setStyleSheet(f"""
            QMenuBar {{
                background: white;
                border-bottom: 1px solid #e5e7eb;
                color: #374151;
                font-weight: 600;
            }}
            QMenuBar::item {{
                padding: {menu_item_padding_v}px {menu_item_padding_h}px;
                background: transparent;
            }}
            QMenuBar::item:selected {{
                background: #f3f4f6;
                border-radius: {menu_border_radius}px;
            }}
            QMenu {{
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: {menu_border_radius}px;
                padding: {menu_padding_v}px 0;
            }}
            QMenu::item {{
                padding: {menu_item_padding_v_inner}px {menu_item_padding_h_inner}px;
                color: #374151;
            }}
            QMenu::item:selected {{
                background: #f3f4f6;
            }}
        """)
        
        # File menu
        print(f"Debug: Creating file menu")
        file_menu = menubar.addMenu("📁 فایل")
        
        # Export action - only visible to users with export permissions
        if True:  # Permission check removed
            print(f"Debug: User has export permissions, adding export action")
            export_action = file_menu.addAction("📊 خروجی")
            export_action.triggered.connect(self.export_data)

        
        # Sync action - always available for all users
        print(f"Debug: Adding sync action")
        sync_action = file_menu.addAction("🔄 همگام‌سازی")
        sync_action.triggered.connect(self.controller.force_sync)
        
        file_menu.addSeparator()
        
        print(f"Debug: Adding exit action")
        exit_action = file_menu.addAction("🚪 خروج")
        exit_action.triggered.connect(self.close)
        
        # Settings menu - only visible to users with settings management permissions
        if True:  # Permission check removed
            print(f"Debug: User has settings permissions, creating settings menu")
            settings_menu = menubar.addMenu("⚙️ تنظیمات")
            
            folder_action = settings_menu.addAction("📂 تغییر پوشه مشترک")
            folder_action.triggered.connect(self.change_shared_folder)
            
            managers_action = settings_menu.addAction("👔 مدیریت مدیران")
            managers_action.triggered.connect(self.manage_managers)
        else:
            print(f"Debug: User does not have settings permissions")
        
        print(f"Debug: Menu bar creation completed")
    
    def setup_connections(self):
        print(f"Debug: MainWindow.setup_connections called")
        # Connect controller signals
        self.controller.employees_updated.connect(self.update_employee_display)
        self.controller.shifts_updated.connect(self.update_shift_displays)
        self.controller.settings_updated.connect(self.update_settings_display)
        print(f"Debug: Controller signals connected")
    
    def setup_timer(self):
        print(f"Debug: MainWindow.setup_timer called")
        # Auto-save timer
        self.auto_save_timer = QTimer()
        self.auto_save_timer.timeout.connect(self.controller.save_data)
        self.auto_save_timer.start(30000)  # 30 seconds
        print(f"Debug: Auto-save timer started (30 seconds)")
    
    def add_employee(self):
        print(f"Debug: MainWindow.add_employee called")
        print(f"Debug: Showing employee dialog")
        dialog = EmployeeDialog(self)
        if dialog.exec_() == QDialog.Accepted:
            print(f"Debug: Employee dialog accepted")
            data = dialog.get_employee_data()
            print(f"Debug: Employee data from dialog: {data}")
            if data['first_name'] and data['last_name']:
                print(f"Debug: Adding employee: {data['first_name']} {data['last_name']}")
                success = self.controller.add_employee(
                    data['first_name'],
                    data['last_name'],
                    data['role'],
                    data['photo_path']
                )
                print(f"Debug: Employee addition result: {success}")
            else:
                print(f"Debug: Employee data incomplete, not adding")
        else:
            print(f"Debug: Employee dialog rejected")
    
    def import_csv(self):
        print(f"Debug: MainWindow.import_csv called")
        print(f"Debug: Showing file dialog")
        file_path, _ = QFileDialog.getOpenFileName(
            self, "انتخاب فایل CSV", "", "CSV Files (*.csv)"
        )
        
        if file_path:
            print(f"Debug: CSV file selected: {file_path}")
            imported, skipped = self.controller.import_employees_from_csv(file_path)
            print(f"Debug: CSV import result: {imported} imported, {skipped} skipped")
            QMessageBox.information(
                self, "نتیجه وارد کردن",
                f"{imported} کارمند وارد شد\n{skipped} کارمند رد شد (تکراری)"
            )
        else:
            print(f"Debug: No CSV file selected")
    
    def show_employee_list_modal(self):
        """Show the employee list in a modal dialog."""
        print(f"Debug: MainWindow.show_employee_list_modal called")
        dialog = EmployeeListDialog(self)
        print(f"Debug: EmployeeListDialog created, showing modal")
        dialog.exec_()
        print(f"Debug: EmployeeListDialog modal closed")
    
    def show_absence_list_modal(self):
        """Show the absence list in a modal dialog."""
        print(f"Debug: MainWindow.show_absence_list_modal called")
        dialog = AbsenceListDialog(self)
        print(f"Debug: AbsenceListDialog created, showing modal")
        dialog.exec_()
        print(f"Debug: AbsenceListDialog modal closed")
    
    def show_absence_management_modal(self):
        """Show the comprehensive absence management modal."""
        print(f"Debug: MainWindow.show_absence_management_modal called")
        dialog = AbsenceManagementDialog(self)
        print(f"Debug: AbsenceManagementDialog created, showing modal")
        dialog.exec_()
        print(f"Debug: AbsenceManagementDialog modal closed")
    
    def show_task_management(self):
        """Show the task management modal."""
        print(f"Debug: MainWindow.show_task_management called")
        try:
            from management_app.ui.task_dialog import TaskManagementDialog
            dialog = TaskManagementDialog(self, self.controller.task_manager)
            print(f"Debug: TaskManagementDialog created, showing modal")
            dialog.exec_()
            print(f"Debug: TaskManagementDialog modal closed")
        except Exception as e:
            print(f"Debug: Error showing task management: {e}")
            QMessageBox.critical(self, "خطا", f"خطا در نمایش مدیریت وظایف: {str(e)}")
    
    def search_employees(self, query):
        """Search employees - now handled in the modal."""
        print(f"Debug: MainWindow.search_employees called with query: {query}")
        # Search functionality is now handled in the EmployeeListDialog
        print(f"Debug: Search functionality handled in modal")
    
    def mark_employee_absent(self):
        """Mark an employee as absent - now handled in the modal."""
        print(f"Debug: MainWindow.mark_employee_absent called")
        print(f"Debug: Absence management is now handled in the modal")
        # This method is no longer needed as absence management is handled in the modal
        pass
    
    def change_capacity(self, new_capacity):
        """Change shift capacity."""
        print(f"Debug: change_capacity called with new_capacity: {new_capacity}")
        
        print(f"Debug: Updating capacity")
        
        try:
            # Update controller settings
            self.controller.change_shift_capacity(new_capacity)
            
            # Refresh shift layouts to reflect new capacity FIRST
            self.refresh_shift_layouts()
            
            # Force a small delay to ensure layout refresh is complete
            QApplication.processEvents()
            
            # Then update shift displays with new capacity
            self.update_shift_displays()
            
            print(f"Debug: Capacity changed to {new_capacity}")
            QMessageBox.information(self, "تایید", f"ظرفیت شیفت به {new_capacity} تغییر یافت")
            
        except Exception as e:
            print(f"Debug: Exception in change_capacity: {e}")
            QMessageBox.warning(self, "خطا", f"خطا در تغییر ظرفیت: {e}")
    

    
    def change_shared_folder(self):
        print(f"Debug: MainWindow.change_shared_folder called")
        print(f"Debug: Showing folder dialog")
        folder_path = QFileDialog.getExistingDirectory(self, "انتخاب پوشه مشترک")
        if folder_path:
            print(f"Debug: New shared folder selected: {folder_path}")
            self.controller.set_shared_folder_path(folder_path)
        else:
            print(f"Debug: No folder selected")
    
    def manage_managers(self):
        """Open manager configuration dialog."""
        print(f"Debug: MainWindow.manage_managers called")
        try:
            dialog = ManagerConfigDialog(self.controller, self)
            if dialog.exec_() == QDialog.Accepted:
                print("Debug: Manager configuration updated")
                # Refresh display if needed
                self.update_settings_display()
        except Exception as e:
            print(f"Debug: Error opening manager configuration: {e}")
            QMessageBox.warning(self, "خطا", f"خطا در باز کردن تنظیمات مدیران: {e}")
    
    def export_data(self):
        print(f"Debug: MainWindow.export_data called")
        print(f"Debug: Processing export")
        
        try:
            # Prepare report data
            report_data = self._prepare_report_data()
            
            if not report_data:
                QMessageBox.warning(self, "خطا", "داده‌ای برای خروجی موجود نیست")
                return
            
            # Show export dialog
            export_dialog = ExportDialog(self.export_service, report_data, self)
            export_dialog.exec_()
            
        except Exception as e:
            print(f"Debug: Export error: {e}")
            QMessageBox.critical(self, "خطا", f"خطا در ایجاد خروجی: {str(e)}")
    
    def _prepare_report_data(self):
        """Prepare report data for export."""
        try:
            # Get current date
            from datetime import datetime
            current_date = datetime.now().strftime("%Y-%m-%d")
            
            # Get shift data
            morning_shift = []
            evening_shift = []
            
            if hasattr(self, 'morning_shift'):
                morning_employees = self.morning_shift.get_employees()
                for employee in morning_employees:
                    morning_shift.append({
                        'first_name': employee.first_name,
                        'last_name': employee.last_name,
                        'employee_id': employee.employee_id,
                        'role': employee.role
                    })
            
            if hasattr(self, 'evening_shift'):
                evening_employees = self.evening_shift.get_employees()
                for employee in evening_employees:
                    evening_shift.append({
                        'first_name': employee.first_name,
                        'last_name': employee.last_name,
                        'employee_id': employee.employee_id,
                        'role': employee.role
                    })
            
            # Get absence data from controller
            absences = {}
            try:
                all_absences = self.controller.get_all_absences()
                absence_categories = ['مرخصی', 'بیمار', 'غایب']
                
                # Count absences by category
                for category in absence_categories:
                    count = 0
                    for absence in all_absences:
                        if hasattr(absence, 'category') and absence.category == category:
                            count += 1
                    absences[category] = count
                    
                print(f"Debug: Absence counts: {absences}")
            except Exception as e:
                print(f"Debug: Error getting absence data: {e}")
                # Fallback to empty counts
                absences = {'مرخصی': 0, 'بیمار': 0, 'غایب': 0}
            
            # Create report data
            report_data = {
                'date': current_date,
                'morning_shift': morning_shift,
                'evening_shift': evening_shift,
                'absences': absences,
                'total_employees': len(morning_shift) + len(evening_shift),
                'export_timestamp': datetime.now().isoformat()
            }
            
            print(f"Debug: Prepared report data: {report_data}")
            return report_data
            
        except Exception as e:
            print(f"Debug: Error preparing report data: {e}")
            return None
    

    
    def update_employee_display(self):
        """Update the employee display with draggable cards."""
        print(f"Debug: update_employee_display called")
        
        # Clear existing employee cards
        for i in reversed(range(self.employee_cards_layout.count())):
            child = self.employee_cards_layout.itemAt(i).widget()
            if child:
                child.deleteLater()
        
        # Clear the employee cards list for filtering
        self.all_employee_cards.clear()
        
        # Get all employees
        employees = self.controller.get_all_employees()
        print(f"Debug: Found {len(employees)} employees from controller")
        
        # Debug: Print each employee
        for i, emp in enumerate(employees):
            print(f"Debug: Employee {i+1}: {emp.employee_id} - {emp.first_name} {emp.last_name} ({emp.role})")
        
        if not employees:
            # Show "no employees" message
            no_employees_label = QLabel("هیچ کارمندی موجود نیست")
            no_employees_label.setStyleSheet("""
                color: #6b7280; 
                font-size: 16px; 
                text-align: center; 
                padding: 40px;
                font-family: 'Tahoma', Arial, sans-serif;
            """)
            no_employees_label.setAlignment(Qt.AlignCenter)
            self.employee_cards_layout.addWidget(no_employees_label)
        else:
            # Create draggable employee cards
            for employee in employees:
                print(f"Debug: Adding employee card for: {employee.first_name} {employee.last_name}")
                self.add_employee_card(employee)
        
        # Absence combos are now handled in the modal
        
        # Force UI update to ensure employee cards are visible
        self.employee_cards_widget.update()
        self.employee_scroll_area.viewport().update()
        
        # Process pending events to ensure UI updates are applied
        QApplication.processEvents()
        
        # Debug: Check the actual size of employee cards
        print(f"Debug: Employee cards layout has {self.employee_cards_layout.count()} items")
        print(f"Debug: Employee cards widget size: {self.employee_cards_widget.size()}")
        print(f"Debug: Employee scroll area size: {self.employee_scroll_area.size()}")
        print(f"Debug: Employee scroll area viewport size: {self.employee_scroll_area.viewport().size()}")
        
        # Force the scroll area and widget to update
        self.employee_cards_widget.update()
        self.employee_scroll_area.update()
        self.employee_scroll_area.repaint()
        print(f"Debug: Forced scroll area update and repaint")
        
        # Check if scroll area is visible
        print(f"Debug: Scroll area is visible: {self.employee_scroll_area.isVisible()}")
        print(f"Debug: Scroll area widget is visible: {self.employee_scroll_area.widget().isVisible() if self.employee_scroll_area.widget() else 'No widget'}")
        
        # Force scroll area to be visible
        self.employee_scroll_area.setVisible(True)
        self.employee_scroll_area.show()
        print(f"Debug: Forced scroll area visibility")
    
    def add_employee_card(self, employee):
        """Add a draggable employee card to the list."""
        print(f"Debug: add_employee_card called for employee: {employee.employee_id} - {employee.first_name} {employee.last_name}")
        
        try:
            from management_app.widgets.draggable_employee import DraggableEmployee
            
            # Create draggable employee widget
            employee_card = DraggableEmployee(employee)
            print(f"Debug: DraggableEmployee widget created for {employee.employee_id}")
            
            # Store the card for filtering
            self.all_employee_cards.append(employee_card)
            
            # Add to layout
            self.employee_cards_layout.addWidget(employee_card)
            print(f"Debug: Employee card added to layout for {employee.employee_id}")
            print(f"Debug: Layout now has {self.employee_cards_layout.count()} items")
            print(f"Debug: Employee card size: {employee_card.size()}")
            print(f"Debug: Employee card is visible: {employee_card.isVisible()}")
            
            # Force the card to be visible
            employee_card.setVisible(True)
            employee_card.show()
            print(f"Debug: Employee card visibility forced to True")
            
        except Exception as e:
            print(f"Debug: Error creating employee card: {e}")
            import traceback
            traceback.print_exc()
    
    def filter_employee_cards(self, search_text):
        """Filter employee cards based on search text."""
        print(f"Debug: filter_employee_cards called with search text: '{search_text}'")
        
        if not hasattr(self, 'all_employee_cards'):
            print(f"Debug: No employee cards to filter")
            return
        
        search_text = search_text.strip().lower()
        print(f"Debug: Filtering {len(self.all_employee_cards)} employee cards with search: '{search_text}'")
        
        visible_count = 0
        for card in self.all_employee_cards:
            if not hasattr(card, 'employee') or not card.employee:
                print(f"Debug: Card has no employee data, hiding")
                card.hide()
                continue
            
            employee = card.employee
            # Search in first name, last name, and role
            first_name = employee.first_name.lower() if employee.first_name else ""
            last_name = employee.last_name.lower() if employee.last_name else ""
            role = employee.role.lower() if employee.role else ""
            employee_id = employee.employee_id.lower() if employee.employee_id else ""
            
            # Check if search text matches any field
            matches = (
                search_text in first_name or
                search_text in last_name or
                search_text in role or
                search_text in employee_id or
                search_text in f"{first_name} {last_name}".strip()
            )
            
            if not search_text or matches:
                card.show()
                visible_count += 1
                print(f"Debug: Showing employee: {employee.first_name} {employee.last_name}")
            else:
                card.hide()
                print(f"Debug: Hiding employee: {employee.first_name} {employee.last_name}")
        
        print(f"Debug: Filter complete. {visible_count} employees visible out of {len(self.all_employee_cards)} total")
    
    def populate_absence_combos(self, employees):
        """Populate absence management combo boxes with employee names - now handled in modal."""
        print(f"Debug: populate_absence_combos called with {len(employees)} employees")
        print(f"Debug: Absence combo population is now handled in the modal")
        # This method is no longer needed as absence management is handled in the modal
        pass
    
    def update_shift_displays(self):
        """Update all shift displays."""
        print(f"Debug: update_shift_displays called")
        if hasattr(self, 'morning_shift'):
            print(f"Debug: Updating morning shift display")
            self.morning_shift.update_display()
        if hasattr(self, 'evening_shift'):
            print(f"Debug: Updating evening shift display")
            self.evening_shift.update_display()
    
    def refresh_shift_layouts(self):
        """Refresh shift layouts when capacity changes."""
        print(f"Debug: refresh_shift_layouts called")
        if hasattr(self, 'morning_shift'):
            print(f"Debug: Refreshing morning shift layout")
            self.morning_shift.refresh_layout()
        if hasattr(self, 'evening_shift'):
            print(f"Debug: Refreshing evening shift layout")
            self.evening_shift.refresh_layout()
    
    def update_absence_display(self):
        """Update absence-related displays - now handled in modal."""
        print(f"Debug: MainWindow.update_absence_display called")
        # Absence display is now handled in the AbsenceListDialog modal
        print(f"Debug: Absence display update skipped (handled in modal)")
    
    def update_settings_display(self):
        print(f"Debug: MainWindow.update_settings_display called")
        # Only update if capacity_spin exists (user has settings management permissions)
        if hasattr(self, 'capacity_spin'):
            print(f"Debug: Updating capacity spin box")
            # Update capacity spin box
            current_capacity = self.controller.settings.get("shift_capacity", 10)
            self.capacity_spin.setValue(current_capacity)
            

            
            # Check if shift layouts need refreshing due to capacity change
            if hasattr(self, 'morning_shift') and hasattr(self, 'evening_shift'):
                print(f"Debug: Checking if shift layouts need refresh")
                # Get the actual capacity from shift manager
                shift_manager_capacity = self.controller.shift_manager.capacity
                if shift_manager_capacity != current_capacity:
                    print(f"Debug: Capacity mismatch detected: settings={current_capacity}, shift_manager={shift_manager_capacity}")
                    print(f"Debug: Refreshing shift layouts to sync capacity")
                    self.refresh_shift_layouts()
        else:
            print(f"Debug: Capacity spin box not found (user may not have settings permissions)")
    
    def edit_employee(self, employee):
        print(f"Debug: MainWindow.edit_employee called for employee: {employee.employee_id if employee else 'None'}")
        print(f"Debug: Showing edit dialog")
        dialog = EmployeeDialog(self, employee)
        if dialog.exec_() == QDialog.Accepted:
            print(f"Debug: Employee edit dialog accepted")
            data = dialog.get_employee_data()
            print(f"Debug: Employee data from edit dialog: {data}")
            self.controller.update_employee(
                employee.employee_id,
                first_name=data['first_name'],
                last_name=data['last_name'],
                role=data['role'],
                photo_path=data['photo_path']
            )
            print(f"Debug: Employee updated successfully")
        else:
            print(f"Debug: Employee edit dialog rejected")
    
    def delete_employee(self, employee):
        print(f"Debug: MainWindow.delete_employee called for employee: {employee.employee_id if employee else 'None'}")
        print(f"Debug: Showing confirmation dialog")
        reply = QMessageBox.question(
            self, "تایید حذف",
            f"آیا مطمئن هستید که می‌خواهید {employee.full_name} را حذف کنید؟",
            QMessageBox.Yes | QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            print(f"Debug: User confirmed employee deletion")
            self.controller.delete_employee(employee.employee_id)
            print(f"Debug: Employee deleted successfully")
        else:
            print(f"Debug: User cancelled employee deletion")
    
    def closeEvent(self, event):
        print(f"Debug: MainWindow.closeEvent called")
        self.controller.cleanup()
        print(f"Debug: Controller cleanup completed")
        event.accept()

class ManagerConfigDialog(QDialog):
    """Dialog for configuring managers shown in display app."""
    
    def __init__(self, controller, parent=None):
        super().__init__(parent)
        self.controller = controller
        self.managers = []
        self.setup_ui()
        self.load_current_managers()
    
    def setup_ui(self):
        """Setup the manager configuration UI."""
        self.setWindowTitle("تنظیمات مدیران")
        self.setModal(True)
        self.resize(600, 500)
        
        # Set RTL layout direction
        self.setLayoutDirection(Qt.RightToLeft)
        
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(30, 30, 30, 30)
        
        # Title
        title = QLabel("تنظیمات مدیران نمایشی")
        title.setFont(QFont("Tahoma", 18, QFont.Bold))
        title.setStyleSheet("color: #111827; margin-bottom: 15px;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Description
        desc = QLabel("انتخاب ۳ مدیر برای نمایش در پنل مدیران داشبورد")
        desc.setFont(QFont("Tahoma", 12))
        desc.setStyleSheet("color: #6b7280; margin-bottom: 20px;")
        desc.setAlignment(Qt.AlignCenter)
        layout.addWidget(desc)
        
        # Manager selection area
        selection_group = QGroupBox("انتخاب مدیران")
        selection_layout = QVBoxLayout()
        selection_layout.setSpacing(15)
        
        # Available employees list
        available_label = QLabel("کارمندان موجود:")
        available_label.setFont(QFont("Tahoma", 14, QFont.Bold))
        selection_layout.addWidget(available_label)
        
        self.available_list = QTableWidget()
        self.available_list.setColumnCount(4)
        self.available_list.setHorizontalHeaderLabels(["انتخاب", "نام", "نام خانوادگی", "سمت"])
        self.available_list.horizontalHeader().setStretchLastSection(True)
        self.available_list.setSelectionBehavior(QTableWidget.SelectRows)
        self.available_list.setAlternatingRowColors(True)
        selection_layout.addWidget(self.available_list)
        
        # Selected managers display
        selected_label = QLabel("مدیران انتخاب شده (حداکثر ۳ نفر):")
        selected_label.setFont(QFont("Tahoma", 14, QFont.Bold))
        selected_label.setStyleSheet("color: #059669; margin-top: 20px;")
        selection_layout.addWidget(selected_label)
        
        self.selected_list = QTableWidget()
        self.selected_list.setColumnCount(4)
        self.selected_list.setHorizontalHeaderLabels(["ردیف", "نام", "نام خانوادگی", "سمت"])
        self.selected_list.horizontalHeader().setStretchLastSection(True)
        self.selected_list.setMaximumHeight(150)
        selection_layout.addWidget(self.selected_list)
        
        selection_group.setLayout(selection_layout)
        layout.addWidget(selection_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.save_btn = QPushButton("💾 ذخیره تغییرات")
        self.save_btn.setFont(QFont("Tahoma", 12, QFont.Bold))
        self.save_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #10b981, stop:1 #059669);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                min-width: 150px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #34d399, stop:1 #10b981);
            }
        """)
        
        self.cancel_btn = QPushButton("❌ انصراف")
        self.cancel_btn.setFont(QFont("Tahoma", 12))
        self.cancel_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #9ca3af;
            }
        """)
        
        button_layout.addStretch()
        button_layout.addWidget(self.cancel_btn)
        button_layout.addWidget(self.save_btn)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
        
        # Connect signals
        self.save_btn.clicked.connect(self.save_managers)
        self.cancel_btn.clicked.connect(self.reject)
        self.available_list.cellClicked.connect(self.on_employee_selected)
    
    def load_current_managers(self):
        """Load current managers and available employees."""
        # Get current managers from settings
        current_managers = self.controller.settings.get('managers', [])
        print(f"Debug: Current managers from settings: {current_managers}")
        print(f"Debug: Total employees available: {len(self.controller.employees)}")
        
        # Load all employees
        employees = list(self.controller.employees.values())
        
        # Populate available employees list
        self.available_list.setRowCount(len(employees))
        
        selected_manager_ids = []
        for mgr in current_managers:
            if isinstance(mgr, dict):
                selected_manager_ids.append(mgr.get('employee_id', ''))
            elif isinstance(mgr, str):
                selected_manager_ids.append(mgr)
            else:
                print(f"Debug: Unknown manager type: {type(mgr)}, value: {mgr}")
        
        for row, employee in enumerate(employees):
            # Checkbox for selection
            checkbox = QCheckBox()
            if employee.employee_id in selected_manager_ids:
                checkbox.setChecked(True)
            checkbox.stateChanged.connect(self.update_selected_managers)
            self.available_list.setCellWidget(row, 0, checkbox)
            
            # Employee details
            self.available_list.setItem(row, 1, QTableWidgetItem(employee.first_name))
            self.available_list.setItem(row, 2, QTableWidgetItem(employee.last_name))
            self.available_list.setItem(row, 3, QTableWidgetItem(employee.role))
            
            # Store employee reference
            self.available_list.item(row, 1).setData(Qt.UserRole, employee)
        
        # Update selected managers display
        self.update_selected_managers()
    
    def on_employee_selected(self, row, column):
        """Handle employee selection."""
        if column == 0:  # Checkbox column
            return
        
        # Toggle checkbox when row is clicked
        checkbox = self.available_list.cellWidget(row, 0)
        if checkbox:
            checkbox.setChecked(not checkbox.isChecked())
    
    def update_selected_managers(self):
        """Update the selected managers list."""
        selected_managers = []
        
        for row in range(self.available_list.rowCount()):
            checkbox = self.available_list.cellWidget(row, 0)
            if checkbox and checkbox.isChecked():
                employee = self.available_list.item(row, 1).data(Qt.UserRole)
                if employee:
                    selected_managers.append(employee)
        
        # Limit to 3 managers as per specs
        if len(selected_managers) > 3:
            # Uncheck the last selected
            for row in range(self.available_list.rowCount()):
                checkbox = self.available_list.cellWidget(row, 0)
                if checkbox and checkbox.isChecked():
                    employee = self.available_list.item(row, 1).data(Qt.UserRole)
                    if employee == selected_managers[-1]:
                        checkbox.setChecked(False)
                        break
            selected_managers = selected_managers[:3]
            QMessageBox.information(self, "اطلاعات", "حداکثر ۳ مدیر قابل انتخاب است")
        
        # Update selected managers table
        self.selected_list.setRowCount(len(selected_managers))
        
        for row, manager in enumerate(selected_managers):
            self.selected_list.setItem(row, 0, QTableWidgetItem(str(row + 1)))
            self.selected_list.setItem(row, 1, QTableWidgetItem(manager.first_name))
            self.selected_list.setItem(row, 2, QTableWidgetItem(manager.last_name))
            self.selected_list.setItem(row, 3, QTableWidgetItem(manager.role))
        
        self.managers = selected_managers
    
    def save_managers(self):
        """Save the selected managers to settings."""
        try:
            print(f"Debug: save_managers called with {len(self.managers)} managers")
            if len(self.managers) != 3:
                QMessageBox.warning(self, "خطا", "لطفاً دقیقاً ۳ مدیر انتخاب کنید")
                return
            
            # Convert managers to settings format
            managers_data = []
            for manager in self.managers:
                manager_dict = {
                    "employee_id": manager.employee_id,
                    "first_name": manager.first_name,
                    "last_name": manager.last_name,
                    "role": manager.role
                }
                managers_data.append(manager_dict)
                print(f"Debug: Adding manager to save: {manager.first_name} {manager.last_name} ({manager.employee_id})")
            
            # Update settings
            self.controller.settings['managers'] = managers_data
            print(f"Debug: Updated settings.managers with {len(managers_data)} managers")
            
            # Save to file
            success = self.controller.save_data()
            
            if success:
                QMessageBox.information(self, "موفقیت", "تنظیمات مدیران با موفقیت ذخیره شد\nتغییرات در داشبورد نمایش داده خواهد شد")
                self.accept()
            else:
                QMessageBox.warning(self, "خطا", "خطا در ذخیره تنظیمات")
                
        except Exception as e:
            print(f"Debug: Error saving managers: {e}")
            QMessageBox.warning(self, "خطا", f"خطا در ذخیره مدیران: {e}")

class EmployeeListDialog(QDialog):
    """Modal dialog for displaying the employee list with better space utilization."""
    
    def __init__(self, parent=None):
        print(f"Debug: EmployeeListDialog.__init__ called")
        super().__init__(parent)
        print(f"Debug: Setting up UI for employee list dialog")
        self.setup_ui()
        print(f"Debug: Loading employees")
        self.load_employees()
        print(f"Debug: EmployeeListDialog initialization completed")
    
    def setup_ui(self):
        print(f"Debug: EmployeeListDialog.setup_ui called")
        self.setWindowTitle("لیست کارمندان")
        self.setModal(True)
        
        # Adaptive sizing - larger modal for better space utilization
        base_width = 800
        base_height = 600
        scale_factor = AdaptiveUI.get_scale_factor()
        self.resize(int(base_width * scale_factor), int(base_height * scale_factor))
        
        self.setStyleSheet("""
            QDialog {
                background: #f8fafc;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(20)
        layout_margins = AdaptiveUI.scale_value(30)
        title_font_size = AdaptiveUI.get_adaptive_font_size(20)
        search_padding = AdaptiveUI.scale_value(12)
        search_border_radius = AdaptiveUI.scale_value(8)
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Enhanced title with professional styling
        title = QLabel("👥 لیست کارمندان")
        title.setFont(QFont("Tahoma", title_font_size + 2, QFont.Bold))
        title.setStyleSheet("""
            color: #1e293b; 
            margin-bottom: 20px;
            font-family: 'Tahoma', Arial, sans-serif;
        """)
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Enhanced search section with professional styling
        print(f"Debug: Creating search section")
        search_container = QWidget()
        search_container.setStyleSheet("""
            QWidget {
                background: #f8fafc;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                padding: 20px;
            }
        """)
        
        search_layout = QVBoxLayout()
        search_layout.setContentsMargins(0, 0, 0, 0)
        search_layout.setSpacing(12)
        
        # Search header
        search_header = QLabel("🔍 جستجو در کارمندان")
        search_header.setStyleSheet("""
            color: #1e293b; 
            font-weight: 700; 
            font-size: 16px;
            font-family: 'Tahoma', Arial, sans-serif;
        """)
        
        # Search input with enhanced styling
        search_input_layout = QHBoxLayout()
        search_input_layout.setContentsMargins(0, 0, 0, 0)
        search_input_layout.setSpacing(15)
        
        self.search_edit = QLineEdit()
        self.search_edit.setPlaceholderText("جستجو در نام، نام خانوادگی یا سمت...")
        self.search_edit.textChanged.connect(self.search_employees)
        self.search_edit.setStyleSheet(f"""
            QLineEdit {{
                padding: 16px;
                border: 2px solid #e2e8f0;
                border-radius: 10px;
                font-size: 14px;
                background: white;
                min-width: 400px;
                color: #374151;
                font-family: 'Tahoma', Arial, sans-serif;
            }}
            QLineEdit:focus {{
                border-color: #4f46e5;
                outline: none;
                box-shadow: 0 0 0 3px rgba(79, 70, 229, 0.1);
            }}
            QLineEdit::placeholder {{
                color: #9ca3af;
                font-style: italic;
            }}
        """)
        
        search_input_layout.addWidget(self.search_edit)
        search_input_layout.addStretch()
        
        search_layout.addWidget(search_header)
        search_layout.addLayout(search_input_layout)
        search_container.setLayout(search_layout)
        layout.addWidget(search_container)
        
        # Employee list section with enhanced professional styling
        print(f"Debug: Creating employee list section")
        list_container = QWidget()
        list_container.setStyleSheet("""
            QWidget {
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 16px;
                padding: 24px;
            }
        """)
        
        list_layout = QVBoxLayout()
        list_layout.setSpacing(20)
        list_layout.setContentsMargins(0, 0, 0, 0)
        
        # Enhanced scroll area with better styling
        print(f"Debug: Creating employee scroll area")
        self.employee_scroll_area = QScrollArea()
        self.employee_scroll_area.setWidgetResizable(True)
        self.employee_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background: transparent;
            }
            QScrollBar:vertical {
                background: #f8fafc;
                width: 10px;
                border-radius: 5px;
                margin: 2px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 5px;
                min-height: 30px;
                margin: 2px;
            }
            QScrollBar::handle:vertical:hover {
                background: #94a3b8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
            QScrollBar::add-page:vertical, QScrollBar::sub-page:vertical {
                background: none;
            }
        """)
        
        # Container for employee cards
        print(f"Debug: Creating employee cards container")
        self.employee_cards_container = QWidget()
        self.employee_cards_layout = QVBoxLayout()
        self.employee_cards_layout.setSpacing(12)
        self.employee_cards_layout.setContentsMargins(0, 0, 0, 0)
        self.employee_cards_container.setLayout(self.employee_cards_layout)
        
        # Add a "no employees" message initially
        self.no_employees_label = QLabel("در حال بارگذاری کارمندان...")
        self.no_employees_label.setStyleSheet("""
            color: #6b7280; 
            font-size: 16px; 
            text-align: center; 
            padding: 40px;
        """)
        self.no_employees_label.setAlignment(Qt.AlignCenter)
        self.employee_cards_layout.addWidget(self.no_employees_label)
        
        # Add a spacer to push cards to the top
        self.employee_cards_layout.addStretch()
        
        self.employee_scroll_area.setWidget(self.employee_cards_container)
        list_layout.addWidget(self.employee_scroll_area)
        
        list_container.setLayout(list_layout)
        layout.addWidget(list_container)
        
        # Close button
        print(f"Debug: Creating close button")
        close_btn = ElegantButton("بستن", primary=False)
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
                font-size: 14px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        
        # Center the close button
        button_container = QWidget()
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        button_layout.addStretch()
        button_container.setLayout(button_layout)
        layout.addWidget(button_container)
        
        self.setLayout(layout)
        print(f"Debug: EmployeeListDialog UI setup completed")
    
    def load_employees(self):
        """Load and display employees in the modal."""
        print(f"Debug: EmployeeListDialog.load_employees called")
        
        # Hide the loading message
        if hasattr(self, 'no_employees_label'):
            self.no_employees_label.hide()
            print(f"Debug: Loading message hidden")
        
        # Clear existing cards (but keep the stretch)
        for i in reversed(range(self.employee_cards_layout.count() - 1)):  # -1 to keep the stretch
            child = self.employee_cards_layout.itemAt(i).widget()
            if child and child != self.no_employees_label:
                child.deleteLater()
                print(f"Debug: Deleted existing employee card {i}")
        
        # Get employees from the main window's controller
        main_window = self.parent()
        print(f"Debug: Main window parent: {main_window}")
        if hasattr(main_window, 'controller'):
            print(f"Debug: Main window has controller")
            employees = main_window.controller.get_all_employees()
            print(f"Debug: Found {len(employees)} employees in modal")
            
            if not employees:
                # Show "no employees" message
                print(f"Debug: No employees found, showing message")
                no_emp_label = QLabel("هیچ کارمندی یافت نشد")
                no_emp_label.setStyleSheet("""
                    color: #6b7280; 
                    font-size: 16px; 
                    text-align: center; 
                    padding: 40px;
                """)
                no_emp_label.setAlignment(Qt.AlignCenter)
                self.employee_cards_layout.insertWidget(0, no_emp_label)
            else:
                # Add employee cards
                for employee in employees:
                    print(f"Debug: Adding employee: {employee.first_name} {employee.last_name}")
                    self.add_employee_card(employee)
        else:
            print(f"Debug: No controller found in main window")
            # Show error message
            error_label = QLabel("خطا در بارگذاری کارمندان")
            error_label.setStyleSheet("""
                color: #dc2626; 
                font-size: 16px; 
                text-align: center; 
                padding: 40px;
            """)
            error_label.setAlignment(Qt.AlignCenter)
            self.employee_cards_layout.insertWidget(0, error_label)
    
    def add_employee_card(self, employee):
        """Add an employee card to the list with professional styling."""
        print(f"Debug: EmployeeListDialog.add_employee_card called for employee: {getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')}")
        print(f"Debug: Employee object type: {type(employee)}")
        print(f"Debug: Employee has get_photo_pixmap: {hasattr(employee, 'get_photo_pixmap')}")
        if hasattr(employee, 'photo_path'):
            print(f"Debug: Employee photo_path: {employee.photo_path}")
        
        # Create main card container - more compact
        card = QWidget()
        card.setStyleSheet("""
            QWidget {
                background: white;
                border: 1px solid #e5e7eb;
                border-radius: 8px;
                margin: 4px 0px;
            }
            QWidget:hover {
                border-color: #4f46e5;
                background: #fafafa;
            }
        """)
        
        # Main card layout with compact spacing
        card_layout = QHBoxLayout()
        card_layout.setContentsMargins(12, 12, 12, 12)
        card_layout.setSpacing(12)
        
        # Compact profile picture
        profile_pic = QLabel()
        profile_pic.setFixedSize(40, 40)
        
        # Try to load employee photo first
        photo_loaded = False
        print(f"Debug: Attempting to load photo for {getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')}")
        if hasattr(employee, 'get_photo_pixmap'):
            print(f"Debug: Employee has get_photo_pixmap method")
            try:
                photo_pixmap = employee.get_photo_pixmap(QSize(40, 40))
                print(f"Debug: Photo pixmap created, isNull: {photo_pixmap.isNull()}")
                if not photo_pixmap.isNull():
                    profile_pic.setPixmap(photo_pixmap)
                    profile_pic.setStyleSheet("""
                        QLabel {
                            border: 2px solid #e0e7ff;
                            border-radius: 20px;
                        }
                    """)
                    photo_loaded = True
                    print(f"Debug: ✅ Employee photo loaded successfully for {getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')}")
                else:
                    print(f"Debug: ❌ Photo pixmap is null for {getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')}")
            except Exception as e:
                print(f"Debug: ❌ Error loading employee photo: {e}")
                import traceback
                traceback.print_exc()
        else:
            print(f"Debug: ❌ Employee does not have get_photo_pixmap method")
        
        # If photo loading failed, show initials
        if not photo_loaded:
            # Get initials from name
            initials = ""
            if hasattr(employee, 'first_name') and employee.first_name:
                initials += employee.first_name[0].upper()
            if hasattr(employee, 'last_name') and employee.last_name:
                initials += employee.last_name[0].upper()
            
            if not initials:
                initials = "EM"  # Employee
            
            print(f"Debug: Profile initials: {initials}")
            
            # Create gradient background for profile picture
            profile_pic.setStyleSheet(f"""
                QLabel {{
                    background: qlineargradient(x1:0, y1:0, x2:1, y2:1,
                        stop:0 #4f46e5, stop:1 #7c3aed);
                    border-radius: 20px;
                    color: white;
                    font-weight: bold;
                    font-size: 14px;
                    border: 2px solid #e0e7ff;
                }}
            """)
            
            profile_pic.setText(initials)
            profile_pic.setAlignment(Qt.AlignCenter)
        
        # Employee information section with compact typography
        info_container = QWidget()
        info_layout = QVBoxLayout()
        info_layout.setSpacing(4)
        info_layout.setContentsMargins(0, 0, 0, 0)
        
        # Employee name with compact styling
        name_label = QLabel(f"{getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')}")
        name_label.setStyleSheet("""
            color: #111827; 
            font-weight: 600; 
            font-size: 14px;
            font-family: 'Tahoma', Arial, sans-serif;
        """)
        
        # Role with compact styling and icon
        role_container = QWidget()
        role_layout = QHBoxLayout()
        role_layout.setContentsMargins(0, 0, 0, 0)
        role_layout.setSpacing(6)
        
        # Role icon
        role_icon = QLabel("💼")
        role_icon.setStyleSheet("font-size: 12px;")
        
        # Role text with compact styling
        role_text = getattr(employee, 'role', 'نقش تعیین نشده')
        if not role_text or role_text.strip() == "":
            role_text = "نقش تعیین نشده"
        
        print(f"Debug: Employee role: {role_text}")
        
        role_label = QLabel(role_text)
        role_label.setStyleSheet("""
            color: #6b7280; 
            font-size: 12px;
            font-weight: 400;
            font-family: 'Tahoma', Arial, sans-serif;
        """)
        
        role_layout.addWidget(role_icon)
        role_layout.addWidget(role_label)
        role_layout.addStretch()
        role_container.setLayout(role_layout)
        
        info_layout.addWidget(name_label)
        info_layout.addWidget(role_container)
        info_container.setLayout(info_layout)
        
        # Status indicator (if available) - compact
        status_container = QWidget()
        status_layout = QVBoxLayout()
        status_layout.setContentsMargins(0, 0, 0, 0)
        status_layout.setSpacing(2)
        
        # Check if employee is currently absent
        main_window = self.parent()
        is_absent = False
        if main_window and hasattr(main_window, 'controller'):
            absences = main_window.controller.get_all_absences()
            for absence in absences:
                if (hasattr(absence, 'employee') and 
                    hasattr(absence.employee, 'first_name') and 
                    hasattr(absence.employee, 'last_name') and
                    absence.employee.first_name == getattr(employee, 'first_name', '') and
                    absence.employee.last_name == getattr(employee, 'last_name', '')):
                    is_absent = True
                    print(f"Debug: Employee {getattr(employee, 'first_name', '')} {getattr(employee, 'last_name', '')} is absent")
                    break
        
        # Status indicator - compact
        if is_absent:
            status_indicator = QLabel("🔴 غایب")
            status_indicator.setStyleSheet("""
                color: #dc2626;
                font-size: 10px;
                font-weight: 600;
                background: #fef2f2;
                border: 1px solid #fecaca;
                border-radius: 8px;
                padding: 2px 6px;
            """)
        else:
            status_indicator = QLabel("🟢 حاضر")
            status_indicator.setStyleSheet("""
                color: #059669;
                font-size: 10px;
                font-weight: 600;
                background: #ecfdf5;
                border: 1px solid #a7f3d0;
                border-radius: 8px;
                padding: 2px 6px;
            """)
        
        status_indicator.setAlignment(Qt.AlignCenter)
        status_layout.addWidget(status_indicator)
        status_layout.addStretch()
        status_container.setLayout(status_layout)
        
        # Action buttons container
        actions_container = QWidget()
        actions_layout = QVBoxLayout()
        actions_layout.setContentsMargins(0, 0, 0, 0)
        actions_layout.setSpacing(4)
        
        # Edit button
        edit_btn = ElegantButton("✏️ ویرایش")
        edit_btn.setFixedSize(80, 30)
        edit_btn.setStyleSheet("""
            QPushButton {
                background: #4f46e5;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background: #4338ca;
            }
            QPushButton:pressed {
                background: #3730a3;
            }
        """)
        edit_btn.clicked.connect(lambda: self.edit_employee(employee))
        
        # Delete button
        delete_btn = ElegantButton("🗑️ حذف")
        delete_btn.setFixedSize(80, 30)
        delete_btn.setStyleSheet("""
            QPushButton {
                background: #dc2626;
                color: white;
                border: none;
                border-radius: 6px;
                font-size: 11px;
                font-weight: 600;
                padding: 4px 8px;
            }
            QPushButton:hover {
                background: #b91c1c;
            }
            QPushButton:pressed {
                background: #991b1b;
            }
        """)
        delete_btn.clicked.connect(lambda: self.delete_employee(employee))
        
        actions_layout.addWidget(edit_btn)
        actions_layout.addWidget(delete_btn)
        actions_layout.addStretch()
        actions_container.setLayout(actions_layout)
        
        # Add all components to the main layout
        card_layout.addWidget(profile_pic)
        card_layout.addWidget(info_container)
        card_layout.addStretch()
        card_layout.addWidget(status_container)
        card_layout.addWidget(actions_container)
        
        card.setLayout(card_layout)
        
        # Insert before the stretch
        insert_position = self.employee_cards_layout.count() - 1
        print(f"Debug: Inserting card at position {insert_position}")
        self.employee_cards_layout.insertWidget(insert_position, card)
        print(f"Debug: Card inserted successfully")
    
    def search_employees(self, text):
        """Filter employees based on search text."""
        print(f"Debug: EmployeeListDialog.search_employees called with text: {text}")
        
        # Hide the loading message
        if hasattr(self, 'no_employees_label'):
            self.no_employees_label.hide()
            print(f"Debug: Loading message hidden")
        
        # Clear existing cards (but keep the stretch and loading message)
        for i in reversed(range(self.employee_cards_layout.count() - 1)):  # -1 to keep the stretch
            child = self.employee_cards_layout.itemAt(i).widget()
            if child and child != self.no_employees_label:
                child.deleteLater()
                print(f"Debug: Deleted existing employee card {i}")
        
        # Get employees from the main window
        main_window = self.parent()
        print(f"Debug: Main window parent: {main_window}")
        if hasattr(main_window, 'controller'):
            print(f"Debug: Main window has controller")
            if not text:
                # Show all employees if no search text
                print(f"Debug: No search text, showing all employees")
                employees = main_window.controller.get_all_employees()
            else:
                # Search employees
                print(f"Debug: Searching employees with text: {text}")
                employees = main_window.controller.search_employees(text)
            
            print(f"Debug: Found {len(employees)} employees after search")
            
            if not employees:
                # Show "no results" message
                print(f"Debug: No employees found, showing no results message")
                no_results_label = QLabel("نتیجه‌ای یافت نشد")
                no_results_label.setStyleSheet("""
                    color: #6b7280; 
                    font-size: 16px; 
                    text-align: center; 
                    padding: 40px;
                """)
                no_results_label.setAlignment(Qt.AlignCenter)
                self.employee_cards_layout.insertWidget(0, no_results_label)
            else:
                # Add filtered employees
                print(f"Debug: Adding filtered employees")
                for employee in employees:
                    self.add_employee_card(employee)
        else:
            print(f"Debug: No controller found in main window")
    
    def edit_employee(self, employee):
        """Edit an employee using the employee dialog."""
        print(f"Debug: EmployeeListDialog.edit_employee called for employee: {employee.employee_id if employee else 'None'}")
        
        # Get the main window to access the controller
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            print(f"Debug: Showing edit dialog")
            dialog = EmployeeDialog(self, employee)
            if dialog.exec_() == QDialog.Accepted:
                print(f"Debug: Employee edit dialog accepted")
                data = dialog.get_employee_data()
                print(f"Debug: Employee data from edit dialog: {data}")
                main_window.controller.update_employee(
                    employee.employee_id,
                    first_name=data['first_name'],
                    last_name=data['last_name'],
                    role=data['role'],
                    photo_path=data['photo_path']
                )
                print(f"Debug: Employee updated successfully")
                # Refresh the employee list
                self.load_employees()
            else:
                print(f"Debug: Employee edit dialog rejected")
        else:
            print(f"Debug: No controller found in main window")
    
    def delete_employee(self, employee):
        """Delete an employee with confirmation."""
        print(f"Debug: EmployeeListDialog.delete_employee called for employee: {employee.employee_id if employee else 'None'}")
        
        # Get the main window to access the controller
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            print(f"Debug: Showing confirmation dialog")
            reply = QMessageBox.question(
                self, "تایید حذف",
                f"آیا مطمئن هستید که می‌خواهید {employee.full_name} را حذف کنید؟",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                print(f"Debug: User confirmed employee deletion")
                main_window.controller.delete_employee(employee.employee_id)
                print(f"Debug: Employee deleted successfully")
                # Refresh the employee list
                self.load_employees()
            else:
                print(f"Debug: User cancelled employee deletion")
        else:
            print(f"Debug: No controller found in main window")

class AbsenceListDialog(QDialog):
    """Modal dialog for displaying the absence list with better space utilization."""
    
    def __init__(self, parent=None):
        print(f"Debug: AbsenceListDialog.__init__ called")
        super().__init__(parent)
        print(f"Debug: Setting up UI for absence list dialog")
        self.setup_ui()
        print(f"Debug: Loading absences")
        self.load_absences()
        print(f"Debug: AbsenceListDialog initialization completed")
    
    def setup_ui(self):
        print(f"Debug: AbsenceListDialog.setup_ui called")
        self.setWindowTitle("لیست غیبت‌ها")
        self.setModal(True)
        
        # Adaptive sizing - larger modal for better space utilization
        base_width = 900
        base_height = 600
        scale_factor = AdaptiveUI.get_scale_factor()
        self.resize(int(base_width * scale_factor), int(base_height * scale_factor))
        
        self.setStyleSheet("""
            QDialog {
                background: #f8fafc;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(20)
        layout_margins = AdaptiveUI.scale_value(30)
        title_font_size = AdaptiveUI.get_adaptive_font_size(20)
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Title
        title = QLabel("لیست غیبت‌ها")
        title.setFont(QFont("Tahoma", title_font_size, QFont.Bold))
        title.setStyleSheet("color: #111827; margin-bottom: 15px; font-family: 'Tahoma', Arial, sans-serif;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Absence list section with enhanced styling
        print(f"Debug: Creating absence list section")
        list_container = QWidget()
        list_container.setStyleSheet("""
            QWidget {
                background: white;
                border: 1px solid #e2e8f0;
                border-radius: 12px;
                padding: 20px;
            }
        """)
        
        list_layout = QVBoxLayout()
        list_layout.setSpacing(15)
        list_layout.setContentsMargins(0, 0, 0, 0)
        
        # Absence scroll area
        print(f"Debug: Creating absence scroll area")
        self.absence_scroll_area = QScrollArea()
        self.absence_scroll_area.setWidgetResizable(True)
        self.absence_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background: transparent;
            }
            QScrollBar:vertical {
                background: #f1f5f9;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 4px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: #94a3b8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        
        # Container for absence cards
        print(f"Debug: Creating absence cards container")
        self.absence_cards_container = QWidget()
        self.absence_cards_layout = QVBoxLayout()
        self.absence_cards_layout.setSpacing(12)
        self.absence_cards_layout.setContentsMargins(0, 0, 0, 0)
        self.absence_cards_container.setLayout(self.absence_cards_layout)
        
        # Add a "loading" message initially
        self.loading_label = QLabel("در حال بارگذاری غیبت‌ها...")
        self.loading_label.setStyleSheet("""
            color: #6b7280; 
            font-size: 16px; 
            text-align: center; 
            padding: 40px;
        """)
        self.loading_label.setAlignment(Qt.AlignCenter)
        self.absence_cards_layout.addWidget(self.loading_label)
        
        # Add a spacer to push cards to the top
        self.absence_cards_layout.addStretch()
        
        self.absence_scroll_area.setWidget(self.absence_cards_container)
        list_layout.addWidget(self.absence_scroll_area)
        
        list_container.setLayout(list_layout)
        layout.addWidget(list_container)
        
        # Close button
        print(f"Debug: Creating close button")
        close_btn = ElegantButton("بستن", primary=False)
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
                font-size: 14px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        
        # Center the close button
        button_container = QWidget()
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        button_layout.addStretch()
        button_container.setLayout(button_layout)
        layout.addWidget(button_container)
        
        self.setLayout(layout)
        print(f"Debug: AbsenceListDialog UI setup completed")
    
    def load_absences(self):
        """Load and display absences in the modal."""
        print(f"Debug: AbsenceListDialog.load_absences called")
        
        # Hide the loading message
        if hasattr(self, 'loading_label'):
            self.loading_label.hide()
            print(f"Debug: Loading message hidden")
        
        # Clear existing cards (but keep the stretch)
        for i in reversed(range(self.absence_cards_layout.count() - 1)):  # -1 to keep the stretch
            child = self.absence_cards_layout.itemAt(i).widget()
            if child and child != self.loading_label:
                child.deleteLater()
                print(f"Debug: Deleted existing absence card {i}")
        
        # Get absences from the main window's controller
        main_window = self.parent()
        print(f"Debug: Main window parent: {main_window}")
        if hasattr(main_window, 'controller'):
            print(f"Debug: Main window has controller")
            absences = main_window.controller.get_all_absences()
            print(f"Debug: Found {len(absences)} absences in modal")
            
            if not absences:
                # Show "no absences" message
                print(f"Debug: No absences found, showing message")
                no_absences_label = QLabel("هیچ غیبتی ثبت نشده است")
                no_absences_label.setStyleSheet("""
                    color: #6b7280; 
                    font-size: 16px; 
                    text-align: center; 
                    padding: 40px;
                """)
                no_absences_label.setAlignment(Qt.AlignCenter)
                self.absence_cards_layout.insertWidget(0, no_absences_label)
            else:
                # Add absence cards
                for absence in absences:
                    print(f"Debug: Adding absence: {absence.employee.full_name if hasattr(absence, 'employee') else 'Unknown'}")
                    self.add_absence_card(absence)
        else:
            print(f"Debug: No controller found in main window")
            # Show error message
            error_label = QLabel("خطا در بارگذاری غیبت‌ها")
            error_label.setStyleSheet("""
                color: #dc2626; 
                font-size: 16px; 
                text-align: center; 
                padding: 40px;
            """)
            error_label.setAlignment(Qt.AlignCenter)
            self.absence_cards_layout.insertWidget(0, error_label)
    
    def add_absence_card(self, absence):
        """Add an absence card to the list."""
        print(f"Debug: AbsenceListDialog.add_absence_card called")
        
        employee_name = getattr(absence, 'employee', None)
        if employee_name and hasattr(employee_name, 'full_name'):
            employee_name = employee_name.full_name
        else:
            employee_name = "کارمند نامشخص"
        
        absence_type = getattr(absence, 'category', 'نوع نامشخص')
        date = getattr(absence, 'date', 'تاریخ نامشخص')
        
        print(f"Debug: Creating card for absence: {employee_name} - {absence_type}")
        
        card = QWidget()
        card.setStyleSheet("""
            QWidget {
                background: white;
                border: 1px solid #e2e8f0;
                border-radius: 10px;
                padding: 15px;
            }
            QWidget:hover {
                border-color: #4f46e5;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }
        """)
        
        card_layout = QHBoxLayout()
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(15)
        
        # Employee info section
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)
        info_layout.setContentsMargins(0, 0, 0, 0)
        
        # Employee name
        name_label = QLabel(employee_name)
        name_label.setStyleSheet("color: #111827; font-weight: bold; font-size: 16px;")
        
        # Absence type with icon
        type_container = QWidget()
        type_layout = QHBoxLayout()
        type_layout.setContentsMargins(0, 0, 0, 0)
        type_layout.setSpacing(8)
        
        # Icon based on absence type
        icon_map = {
            "مرخصی": "🏖️",
            "بیمار": "🏥",
            "غایب": "❌"
        }
        icon = icon_map.get(absence_type, "📋")
        
        icon_label = QLabel(icon)
        icon_label.setStyleSheet("font-size: 16px;")
        
        type_label = QLabel(absence_type)
        type_label.setStyleSheet("color: #6b7280; font-size: 14px;")
        
        type_layout.addWidget(icon_label)
        type_layout.addWidget(type_label)
        type_container.setLayout(type_layout)
        
        # Date
        date_label = QLabel(f"تاریخ: {date}")
        date_label.setStyleSheet("color: #9ca3af; font-size: 12px;")
        
        info_layout.addWidget(name_label)
        info_layout.addWidget(type_container)
        info_layout.addWidget(date_label)
        
        card_layout.addLayout(info_layout)
        card_layout.addStretch()
        
        # Actions section (visible to all users)
        print(f"Debug: Adding absence management actions")
        actions_layout = QVBoxLayout()
        actions_layout.setSpacing(8)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        
        # Remove absence button
        remove_btn = ElegantButton("🗑️ حذف")
        remove_btn.setFixedSize(70, 28)
        remove_btn.setToolTip("حذف غیبت")
        remove_btn.clicked.connect(lambda: self.remove_absence(absence))
        remove_btn.setStyleSheet("""
            QPushButton {
                background: #fef2f2;
                color: #dc2626;
                border: 1px solid #fecaca;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover {
                background: #fee2e2;
                border-color: #fca5a5;
            }
        """)
        
        actions_layout.addWidget(remove_btn)
        card_layout.addLayout(actions_layout)
        
        card.setLayout(card_layout)
        
        # Insert before the stretch
        insert_position = self.absence_cards_layout.count() - 1
        print(f"Debug: Inserting absence card at position {insert_position}")
        self.absence_cards_layout.insertWidget(insert_position, card)
        print(f"Debug: Absence card inserted successfully")
    
    def remove_absence(self, absence):
        """Remove an absence record."""
        print(f"Debug: AbsenceListDialog.remove_absence called")
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            # Get employee name for confirmation
            employee_name = getattr(absence, 'employee', None)
            if employee_name and hasattr(employee_name, 'full_name'):
                employee_name = employee_name.full_name
            else:
                employee_name = "این کارمند"
            
            print(f"Debug: Removing absence for employee: {employee_name}")
            
            reply = QMessageBox.question(
                self, "تایید حذف",
                f"آیا مطمئن هستید که می‌خواهید غیبت {employee_name} را حذف کنید؟",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                print(f"Debug: User confirmed absence removal")
                # Remove the absence - we need to pass the employee, not the absence object
                # First get the employee from the absence
                employee = getattr(absence, 'employee', None)
                if employee:
                    print(f"Debug: Removing absence for employee: {employee.employee_id}")
                    success = main_window.controller.remove_absence(employee)
                else:
                    print(f"Debug: No employee found in absence")
                    success = False
                
                print(f"Debug: Remove absence result: {success}")
                
                if success:
                    print(f"Debug: Absence removed successfully")
                    QMessageBox.information(self, "موفقیت", "غیبت با موفقیت حذف شد.")
                    # Reload the absence list
                    print(f"Debug: Reloading absence list")
                    self.load_absences()
                else:
                    print(f"Debug: Failed to remove absence")
                    QMessageBox.warning(self, "خطا", "خطا در حذف غیبت. لطفاً دوباره تلاش کنید.")
            else:
                print(f"Debug: User cancelled absence removal")
        else:
            print(f"Debug: No controller found in main window")

class AbsenceManagementDialog(QDialog):
    """Comprehensive modal dialog for absence management including all controls."""
    
    def __init__(self, parent=None):
        print(f"Debug: AbsenceManagementDialog.__init__ called")
        super().__init__(parent)
        print(f"Debug: Setting up UI for comprehensive absence management dialog")
        self.setup_ui()
        print(f"Debug: Loading data")
        self.load_data()
        print(f"Debug: AbsenceManagementDialog initialization completed")
    
    def setup_ui(self):
        print(f"Debug: AbsenceManagementDialog.setup_ui called")
        self.setWindowTitle("مدیریت کامل غیبت‌ها")
        self.setModal(True)
        
        # Adaptive sizing - large modal for comprehensive management
        base_width = 1000
        base_height = 700
        scale_factor = AdaptiveUI.get_scale_factor()
        self.resize(int(base_width * scale_factor), int(base_height * scale_factor))
        
        self.setStyleSheet("""
            QDialog {
                background: #f8fafc;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Get adaptive values
        layout_spacing = AdaptiveUI.get_adaptive_spacing(20)
        layout_margins = AdaptiveUI.scale_value(30)
        title_font_size = AdaptiveUI.get_adaptive_font_size(20)
        
        layout = QVBoxLayout()
        layout.setSpacing(layout_spacing)
        layout.setContentsMargins(layout_margins, layout_margins, layout_margins, layout_margins)
        
        # Title
        title = QLabel("🔧 مدیریت کامل غیبت‌ها")
        title.setFont(QFont("Tahoma", title_font_size, QFont.Bold))
        title.setStyleSheet("color: #111827; margin-bottom: 20px; font-family: 'Tahoma', Arial, sans-serif;")
        title.setAlignment(Qt.AlignCenter)
        layout.addWidget(title)
        
        # Create two-column layout for better space utilization
        content_layout = QHBoxLayout()
        content_layout.setSpacing(30)
        
        # Left column: Absence Management Controls
        left_column = QWidget()
        left_layout = QVBoxLayout()
        left_layout.setSpacing(20)
        
        # Absence Management Controls Group
        controls_group = ElegantGroupBox("ثبت غیبت جدید")
        controls_layout = QVBoxLayout()
        controls_layout.setSpacing(15)
        
        # Employee selection
        emp_selection = QWidget()
        emp_layout = QHBoxLayout()
        emp_layout.setSpacing(10)
        emp_layout.setContentsMargins(0, 0, 0, 0)
        
        emp_label = QLabel("👤 کارمند:")
        emp_label.setStyleSheet("color: #374151; font-weight: 600; font-size: 14px; min-width: 80px;")
        
        self.absence_emp_combo = QComboBox()
        self.absence_emp_combo.setStyleSheet("""
            QComboBox {
                padding: 12px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 14px;
                background: white;
                min-width: 200px;
                color: #374151;
            }
            QComboBox:focus {
                border-color: #4f46e5;
                outline: none;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #64748b;
            }
            QComboBox QAbstractItemView {
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                background: white;
                selection-background-color: #4f46e5;
                selection-color: white;
            }
        """)
        
        emp_layout.addWidget(emp_label)
        emp_layout.addWidget(self.absence_emp_combo)
        emp_layout.addStretch()
        emp_selection.setLayout(emp_layout)
        
        # Absence type selection
        type_selection = QWidget()
        type_layout = QHBoxLayout()
        type_layout.setSpacing(10)
        type_layout.setContentsMargins(0, 0, 0, 0)
        
        type_label = QLabel("🏷️ نوع غیبت:")
        type_label.setStyleSheet("color: #374151; font-weight: 600; font-size: 14px; min-width: 80px;")
        
        self.absence_category_combo = QComboBox()
        self.absence_category_combo.addItems(["مرخصی", "بیمار", "غایب"])
        self.absence_category_combo.setStyleSheet("""
            QComboBox {
                padding: 12px;
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                font-size: 14px;
                background: white;
                min-width: 200px;
                color: #374151;
            }
            QComboBox:focus {
                border-color: #4f46e5;
                outline: none;
            }
            QComboBox::drop-down {
                border: none;
                width: 30px;
            }
            QComboBox::down-arrow {
                image: none;
                border-left: 5px solid transparent;
                border-right: 5px solid transparent;
                border-top: 5px solid #64748b;
            }
            QComboBox QAbstractItemView {
                border: 2px solid #e2e8f0;
                border-radius: 8px;
                background: white;
                selection-background-color: #4f46e5;
                selection-color: white;
            }
        """)
        
        type_layout.addWidget(type_label)
        type_layout.addWidget(self.absence_category_combo)
        type_layout.addStretch()
        type_selection.setLayout(type_layout)
        
        # Submit button
        self.mark_absent_btn = ElegantButton("✅ ثبت غیبت", primary=True)
        self.mark_absent_btn.clicked.connect(self.mark_employee_absent)
        self.mark_absent_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #10b981, stop:1 #059669);
                color: white;
                border: none;
                border-radius: 10px;
                padding: 14px 28px;
                font-weight: bold;
                font-size: 15px;
                min-width: 150px;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #34d399, stop:1 #10b981);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #059669, stop:1 #047857);
            }
        """)
        
        # Center the button
        button_container = QWidget()
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(self.mark_absent_btn)
        button_layout.addStretch()
        button_container.setLayout(button_layout)
        
        controls_layout.addWidget(emp_selection)
        controls_layout.addWidget(type_selection)
        controls_layout.addWidget(button_container)
        controls_group.setLayout(controls_layout)
        left_layout.addWidget(controls_group)
        
        # Quick Stats Group
        stats_group = ElegantGroupBox("آمار سریع")
        stats_layout = QVBoxLayout()
        stats_layout.setSpacing(15)
        
        # Stats display
        self.stats_label = QLabel("در حال بارگذاری آمار...")
        self.stats_label.setStyleSheet("""
            color: #6b7280; 
            font-size: 14px; 
            text-align: center; 
            padding: 20px;
        """)
        self.stats_label.setAlignment(Qt.AlignCenter)
        stats_layout.addWidget(self.stats_label)
        
        stats_group.setLayout(stats_layout)
        left_layout.addWidget(stats_group)
        
        left_column.setLayout(left_layout)
        
        # Right column: Absence List
        right_column = QWidget()
        right_layout = QVBoxLayout()
        right_layout.setSpacing(20)
        
        # Absence List Group
        list_group = ElegantGroupBox("لیست غیبت‌ها")
        list_layout = QVBoxLayout()
        list_layout.setSpacing(15)
        
        # Absence scroll area
        self.absence_scroll_area = QScrollArea()
        self.absence_scroll_area.setWidgetResizable(True)
        self.absence_scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background: transparent;
            }
            QScrollBar:vertical {
                background: #f1f5f9;
                width: 8px;
                border-radius: 4px;
            }
            QScrollBar::handle:vertical {
                background: #cbd5e1;
                border-radius: 4px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: #94a3b8;
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                height: 0px;
            }
        """)
        
        # Container for absence cards
        self.absence_cards_container = QWidget()
        self.absence_cards_layout = QVBoxLayout()
        self.absence_cards_layout.setSpacing(12)
        self.absence_cards_layout.setContentsMargins(0, 0, 0, 0)
        self.absence_cards_container.setLayout(self.absence_cards_layout)
        
        # Add a "loading" message initially
        self.loading_label = QLabel("در حال بارگذاری غیبت‌ها...")
        self.loading_label.setStyleSheet("""
            color: #6b7280; 
            font-size: 16px; 
            text-align: center; 
            padding: 40px;
        """)
        self.loading_label.setAlignment(Qt.AlignCenter)
        self.absence_cards_layout.addWidget(self.loading_label)
        
        # Add a spacer to push cards to the top
        self.absence_cards_layout.addStretch()
        
        self.absence_scroll_area.setWidget(self.absence_cards_container)
        list_layout.addWidget(self.absence_scroll_area)
        
        list_group.setLayout(list_layout)
        right_layout.addWidget(list_group)
        
        right_column.setLayout(right_layout)
        
        # Add columns to content layout
        content_layout.addWidget(left_column, 1)
        content_layout.addWidget(right_column, 2)
        
        layout.addLayout(content_layout)
        
        # Close button
        close_btn = ElegantButton("بستن", primary=False)
        close_btn.clicked.connect(self.accept)
        close_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
                font-size: 14px;
                min-width: 100px;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        
        # Center the close button
        button_container = QWidget()
        button_layout = QHBoxLayout()
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        button_layout.addStretch()
        button_container.setLayout(button_layout)
        layout.addWidget(button_container)
        
        self.setLayout(layout)
        print(f"Debug: AbsenceManagementDialog UI setup completed")
    
    def load_data(self):
        """Load employees and absences data."""
        print(f"Debug: AbsenceManagementDialog.load_data called")
        
        # Load employees for combo box
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            employees = main_window.controller.get_all_employees()
            self.absence_emp_combo.clear()
            for employee in employees:
                self.absence_emp_combo.addItem(employee.full_name)
            
            # Load absences
            self.load_absences()
            
            # Update stats
            self.update_stats()
        else:
            print(f"Debug: No controller found in main window")
    
    def load_absences(self):
        """Load and display absences."""
        print(f"Debug: AbsenceManagementDialog.load_absences called")
        
        # Hide the loading message
        if hasattr(self, 'loading_label'):
            self.loading_label.hide()
        
        # Clear existing cards (but keep the stretch)
        for i in reversed(range(self.absence_cards_layout.count() - 1)):
            child = self.absence_cards_layout.itemAt(i).widget()
            if child and child != self.loading_label:
                child.deleteLater()
        
        # Get absences from the main window's controller
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            absences = main_window.controller.get_all_absences()
            
            if not absences:
                # Show "no absences" message
                no_absences_label = QLabel("هیچ غیبتی ثبت نشده است")
                no_absences_label.setStyleSheet("""
                    color: #6b7280; 
                    font-size: 16px; 
                    text-align: center; 
                    padding: 40px;
                """)
                no_absences_label.setAlignment(Qt.AlignCenter)
                self.absence_cards_layout.insertWidget(0, no_absences_label)
            else:
                # Add absence cards
                for absence in absences:
                    self.add_absence_card(absence)
        else:
            print(f"Debug: No controller found in main window")
    
    def add_absence_card(self, absence):
        """Add an absence card to the list."""
        print(f"Debug: AbsenceManagementDialog.add_absence_card called")
        
        employee_name = getattr(absence, 'employee', None)
        if employee_name and hasattr(employee_name, 'full_name'):
            employee_name = employee_name.full_name
        else:
            employee_name = "کارمند نامشخص"
        
        absence_type = getattr(absence, 'category', 'نوع نامشخص')
        date = getattr(absence, 'date', 'تاریخ نامشخص')
        
        card = QWidget()
        card.setStyleSheet("""
            QWidget {
                background: white;
                border: 1px solid #e2e8f0;
                border-radius: 10px;
                padding: 15px;
            }
            QWidget:hover {
                border-color: #4f46e5;
                box-shadow: 0 4px 6px -1px rgba(0, 0, 0, 0.1);
            }
        """)
        
        card_layout = QHBoxLayout()
        card_layout.setContentsMargins(0, 0, 0, 0)
        card_layout.setSpacing(15)
        
        # Employee info section
        info_layout = QVBoxLayout()
        info_layout.setSpacing(5)
        info_layout.setContentsMargins(0, 0, 0, 0)
        
        # Employee name
        name_label = QLabel(employee_name)
        name_label.setStyleSheet("color: #111827; font-weight: bold; font-size: 16px;")
        
        # Absence type with icon
        type_container = QWidget()
        type_layout = QHBoxLayout()
        type_layout.setContentsMargins(0, 0, 0, 0)
        type_layout.setSpacing(8)
        
        # Icon based on absence type
        icon_map = {
            "مرخصی": "🏖️",
            "بیمار": "🏥",
            "غایب": "❌"
        }
        icon = icon_map.get(absence_type, "📋")
        
        icon_label = QLabel(icon)
        icon_label.setStyleSheet("font-size: 16px;")
        
        type_label = QLabel(absence_type)
        type_label.setStyleSheet("color: #6b7280; font-size: 14px;")
        
        type_layout.addWidget(icon_label)
        type_layout.addWidget(type_label)
        type_container.setLayout(type_layout)
        
        # Date
        date_label = QLabel(f"تاریخ: {date}")
        date_label.setStyleSheet("color: #9ca3af; font-size: 12px;")
        
        info_layout.addWidget(name_label)
        info_layout.addWidget(type_container)
        info_layout.addWidget(date_label)
        
        card_layout.addLayout(info_layout)
        card_layout.addStretch()
        
        # Actions section
        actions_layout = QVBoxLayout()
        actions_layout.setSpacing(8)
        actions_layout.setContentsMargins(0, 0, 0, 0)
        
        # Remove absence button
        remove_btn = ElegantButton("🗑️ حذف")
        remove_btn.setFixedSize(70, 28)
        remove_btn.setToolTip("حذف غیبت")
        remove_btn.clicked.connect(lambda: self.remove_absence(absence))
        remove_btn.setStyleSheet("""
            QPushButton {
                background: #fef2f2;
                color: #dc2626;
                border: 1px solid #fecaca;
                border-radius: 6px;
                padding: 5px 10px;
                font-size: 11px;
                font-weight: 500;
            }
            QPushButton:hover {
                background: #fee2e2;
                border-color: #fca5a5;
            }
        """)
        
        actions_layout.addWidget(remove_btn)
        card_layout.addLayout(actions_layout)
        
        card.setLayout(card_layout)
        
        # Insert before the stretch
        insert_position = self.absence_cards_layout.count() - 1
        self.absence_cards_layout.insertWidget(insert_position, card)
    
    def remove_absence(self, absence):
        """Remove an absence record."""
        print(f"Debug: AbsenceManagementDialog.remove_absence called")
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            # Get employee name for confirmation
            employee_name = getattr(absence, 'employee', None)
            if employee_name and hasattr(employee_name, 'full_name'):
                employee_name = employee_name.full_name
            else:
                employee_name = "این کارمند"
            
            reply = QMessageBox.question(
                self, "تایید حذف",
                f"آیا مطمئن هستید که می‌خواهید غیبت {employee_name} را حذف کنید؟",
                QMessageBox.Yes | QMessageBox.No
            )
            
            if reply == QMessageBox.Yes:
                # Remove the absence
                employee = getattr(absence, 'employee', None)
                if employee:
                    success = main_window.controller.remove_absence(employee)
                    
                    if success:
                        QMessageBox.information(self, "موفقیت", "غیبت با موفقیت حذف شد.")
                        # Reload data
                        self.load_absences()
                        self.update_stats()
                    else:
                        QMessageBox.warning(self, "خطا", "خطا در حذف غیبت. لطفاً دوباره تلاش کنید.")
            else:
                print(f"Debug: User cancelled absence removal")
        else:
            print(f"Debug: No controller found in main window")
    
    def mark_employee_absent(self):
        """Mark an employee as absent."""
        print(f"Debug: AbsenceManagementDialog.mark_employee_absent called")
        try:
            # Get selected employee
            current_text = self.absence_emp_combo.currentText()
            if not current_text:
                QMessageBox.warning(self, "خطا", "لطفاً یک کارمند انتخاب کنید.")
                return
            
            # Get selected category
            category = self.absence_category_combo.currentText()
            if not category:
                QMessageBox.warning(self, "خطا", "لطفاً نوع غیبت را انتخاب کنید.")
                return
            
            # Find employee by name
            main_window = self.parent()
            if not main_window or not hasattr(main_window, 'controller'):
                QMessageBox.critical(self, "خطا", "خطا در دسترسی به کنترلر.")
                return
            
            employee = None
            for emp in main_window.controller.get_all_employees():
                if emp.full_name == current_text:
                    employee = emp
                    break
            
            if not employee:
                QMessageBox.warning(self, "خطا", f"کارمند '{current_text}' یافت نشد.")
                return
            
            # Mark employee as absent
            success = main_window.controller.mark_employee_absent(employee, category)
            
            if success:
                QMessageBox.information(self, "موفقیت", f"کارمند {employee.full_name} با موفقیت به عنوان {category} ثبت شد.")
                
                # Clear selections
                self.absence_emp_combo.setCurrentText("")
                self.absence_category_combo.setCurrentText("")
                
                # Reload data
                self.load_absences()
                self.update_stats()
                
                # Update main window displays
                main_window.update_shift_displays()
            else:
                QMessageBox.warning(self, "خطا", "خطا در ثبت غیبت. لطفاً دوباره تلاش کنید.")
                
        except Exception as e:
            print(f"Debug: Exception in mark_employee_absent: {e}")
            QMessageBox.critical(self, "خطا", f"خطای غیرمنتظره: {str(e)}")
    
    def update_stats(self):
        """Update the quick stats display."""
        print(f"Debug: AbsenceManagementDialog.update_stats called")
        
        main_window = self.parent()
        if main_window and hasattr(main_window, 'controller'):
            absences = main_window.controller.get_all_absences()
            employees = main_window.controller.get_all_employees()
            
            total_employees = len(employees)
            total_absences = len(absences)
            
            # Count by category
            absence_counts = {'مرخصی': 0, 'بیمار': 0, 'غایب': 0}
            for absence in absences:
                category = getattr(absence, 'category', 'غایب')
                if category in absence_counts:
                    absence_counts[category] += 1
            
            # Create stats text
            stats_text = f"""
            <div style='text-align: center; padding: 20px;'>
                <h3 style='color: #1e293b; margin-bottom: 15px;'>📊 آمار کلی</h3>
                <p style='color: #374151; font-size: 16px; margin: 8px 0;'>
                    <strong>کل کارمندان:</strong> {total_employees}
                </p>
                <p style='color: #374151; font-size: 16px; margin: 8px 0;'>
                    <strong>کل غیبت‌ها:</strong> {total_absences}
                </p>
                <hr style='border: 1px solid #e2e8f0; margin: 15px 0;'>
                <p style='color: #6b7280; font-size: 14px; margin: 8px 0;'>
                    🏖️ مرخصی: {absence_counts['مرخصی']}
                </p>
                <p style='color: #6b7280; font-size: 14px; margin: 8px 0;'>
                    🏥 بیمار: {absence_counts['بیمار']}
                </p>
                <p style='color: #6b7280; font-size: 14px; margin: 8px 0;'>
                    ❌ غایب: {absence_counts['غایب']}
                </p>
            </div>
            """
            
            self.stats_label.setText(stats_text)
        else:
            self.stats_label.setText("خطا در بارگذاری آمار")
