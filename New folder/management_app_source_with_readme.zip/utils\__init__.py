"""
Utils Package

This package contains utility functions for the management application.
"""

# Empty __init__.py to avoid import issues with PyInstaller
