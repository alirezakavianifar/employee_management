import sys
import os
import logging
import importlib.util
from PyQt5.QtWidgets import QApplication
from PyQt5.QtCore import QTranslator, QLocale, Qt
from PyQt5.QtGui import QFont

def import_main_window():
    """Dynamically import MainWindow to handle PyInstaller issues."""
    try:
        # First try direct import for PyInstaller
        if getattr(sys, 'frozen', False):
            # Running as PyInstaller executable
            print("Debug: Running as frozen executable, trying direct import")
            try:
                import management_app.views.main_window as main_window_module
                print("Debug: Direct import successful")
                return main_window_module.MainWindow
            except ImportError as e1:
                print(f"Debug: Direct import failed: {e1}")
                # Try alternative import paths
                try:
                    import views.main_window as main_window_module
                    print("Debug: Alternative import successful")
                    return main_window_module.MainWindow
                except ImportError as e2:
                    print(f"Debug: Alternative import failed: {e2}")
                    # Try relative import
                    try:
                        from .views.main_window import MainWindow
                        print("Debug: Relative import successful")
                        return MainWindow
                    except ImportError as e3:
                        print(f"Debug: Relative import failed: {e3}")
                        raise e1
        else:
            # Running as script - add parent directory to path
            print("Debug: Running as script, adding parent directory to path")
            parent_dir = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
            sys.path.insert(0, parent_dir)
            from management_app.views.main_window import MainWindow
            return MainWindow
    except ImportError as e:
        print(f"Debug: All import attempts failed: {e}")
        # Final fallback: try to load from file path directly
        try:
            current_dir = os.path.dirname(os.path.abspath(__file__))
            main_window_path = os.path.join(current_dir, 'views', 'main_window.py')
            print(f"Debug: Trying file path import from: {main_window_path}")
            if os.path.exists(main_window_path):
                spec = importlib.util.spec_from_file_location("main_window", main_window_path)
                main_window_module = importlib.util.module_from_spec(spec)
                spec.loader.exec_module(main_window_module)
                print("Debug: File path import successful")
                return main_window_module.MainWindow
            else:
                print(f"Debug: File not found at: {main_window_path}")
        except Exception as fallback_error:
            print(f"Debug: File path import failed: {fallback_error}")
        raise e

def setup_logging():
    """Setup logging configuration."""
    print(f"Debug: setup_logging called")
    log_dir = "data/logs"
    print(f"Debug: Log directory: {log_dir}")
    os.makedirs(log_dir, exist_ok=True)
    print(f"Debug: Log directory created/verified")
    
    logging.basicConfig(
        level=logging.INFO,
        format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
        handlers=[
            logging.FileHandler(os.path.join(log_dir, "management_app.log"), encoding='utf-8'),
            logging.StreamHandler(sys.stdout)
        ]
    )
    print(f"Debug: Logging configuration completed")

def setup_fonts():
    """Setup Persian-compatible fonts."""
    print(f"Debug: setup_fonts called")
    app = QApplication.instance()
    if app:
        print(f"Debug: QApplication instance found, setting Tahoma font")
        # Set Tahoma as the default font for better Persian text support
        font = QFont("Tahoma", 9)
        app.setFont(font)
        print(f"Debug: Tahoma font set successfully")
    else:
        print(f"Debug: No QApplication instance found")

def setup_rtl():
    """Setup Right-to-Left layout for Persian/Arabic interface."""
    print(f"Debug: setup_rtl called")
    app = QApplication.instance()
    if app:
        print(f"Debug: QApplication instance found, setting RTL layout")
        # Set RTL layout direction for Persian/Arabic interface
        app.setLayoutDirection(Qt.RightToLeft)
        # Set RTL locale
        locale = QLocale(QLocale.Persian, QLocale.Iran)
        QLocale.setDefault(locale)
        print(f"Debug: RTL layout and Persian locale set successfully")
    else:
        print(f"Debug: No QApplication instance found")

def main():
    """Main entry point for the management application."""
    print(f"Debug: main function called")
    try:
        # Setup logging
        print(f"Debug: Setting up logging")
        setup_logging()
        logging.info("Starting Management Application")
        
        # Create application
        print(f"Debug: Creating QApplication")
        app = QApplication(sys.argv)
        app.setApplicationName("سیستم مدیریت شیفت کارمندان")
        app.setApplicationVersion("1.0.0")
        
        # Setup fonts
        print(f"Debug: Setting up fonts")
        setup_fonts()
        
        # Setup RTL layout
        print(f"Debug: Setting up RTL layout")
        setup_rtl()
        
        # Create and show main window
        print(f"Debug: Importing MainWindow")
        MainWindow = import_main_window()
        print(f"Debug: Creating MainWindow")
        main_window = MainWindow()
        print(f"Debug: MainWindow created")
        # MainWindow handles its own visibility
        # main_window.show()
        
        logging.info("Management Application started successfully")
        print(f"Debug: Management Application started successfully")
        
        # Start event loop
        print(f"Debug: Starting event loop")
        sys.exit(app.exec_())
        
    except Exception as e:
        print(f"Debug: Exception in main function: {e}")
        logging.error(f"Failed to start Management Application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    print(f"Debug: Script started, __name__ == '__main__'")
    main()
