from typing import Optional, Dict, Any
from datetime import datetime
import os
from PyQt5.QtGui import QPixmap, QIcon, QPainter
from PyQt5.QtCore import QSize, Qt
import sys

class Employee:
    """Employee model class."""
    
    def __init__(self, employee_id: str, first_name: str, last_name: str, role: str = "", photo_path: str = ""):
        print(f"Debug: Employee.__init__ called for {employee_id}: {first_name} {last_name}, role: {role}, photo_path: {photo_path}")
        self.employee_id = employee_id
        self.first_name = first_name
        self.last_name = last_name
        self.role = role
        self.photo_path = photo_path
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()
        print(f"Debug: Employee {employee_id} created successfully")
    
    @property
    def full_name(self) -> str:
        """Get employee's full name."""
        result = f"{self.first_name} {self.last_name}"
        print(f"Debug: Employee.full_name called for {self.employee_id}, result: {result}")
        return result
    
    @property
    def display_name(self) -> str:
        """Get display name (first name only for display app)."""
        result = self.first_name
        print(f"Debug: Employee.display_name called for {self.employee_id}, result: {result}")
        return result
    
    def has_photo(self) -> bool:
        """Check if employee has a photo."""
        if not self.photo_path:
            print(f"Debug: Employee {self.employee_id} has no photo_path")
            return False
        
        print(f"Debug: Employee {self.employee_id} photo_path: {self.photo_path}")
        
        # First try the path as-is (in case it's already absolute)
        if os.path.exists(self.photo_path):
            print(f"Debug: Photo exists at original path: {self.photo_path}")
            return True
        
        # If the path is absolute but doesn't exist, try to find it relative to data directory
        if os.path.isabs(self.photo_path):
            # Extract just the filename from the absolute path
            filename = os.path.basename(self.photo_path)
            print(f"Debug: Absolute path doesn't exist, trying filename: {filename}")
            
            # Try relative to data directory
            if getattr(sys, 'frozen', False):
                # Running from executable
                exe_dir = os.path.dirname(sys.executable)
                print(f"Debug: Running from executable, exe_dir: {exe_dir}")
                # Look for data folder relative to executable
                data_dir = os.path.join(exe_dir, "data")
                if not os.path.exists(data_dir):
                    # Try parent directory
                    data_dir = os.path.join(os.path.dirname(exe_dir), "data")
                    print(f"Debug: Trying parent directory for data: {data_dir}")
            else:
                # Running from source
                data_dir = os.path.join(os.getcwd(), "data")
                print(f"Debug: Running from source, data_dir: {data_dir}")
            
            # Try the data directory path with just the filename
            if os.path.exists(data_dir):
                full_path = os.path.join(data_dir, "images", "staff", filename)
                print(f"Debug: Trying data directory path: {full_path}")
                if os.path.exists(full_path):
                    # Update the photo_path to the full path
                    self.photo_path = full_path
                    print(f"Debug: Photo found at data directory path: {full_path}")
                    return True
        
        # Try relative to data directory (for when app runs from dist folder)
        # Get the directory where the executable is located
        if getattr(sys, 'frozen', False):
            # Running from executable
            exe_dir = os.path.dirname(sys.executable)
            print(f"Debug: Running from executable, exe_dir: {exe_dir}")
            # Look for data folder relative to executable
            data_dir = os.path.join(exe_dir, "data")
            if not os.path.exists(data_dir):
                # Try parent directory
                data_dir = os.path.join(os.path.dirname(exe_dir), "data")
                print(f"Debug: Trying parent directory for data: {data_dir}")
        else:
            # Running from source
            data_dir = os.path.join(os.getcwd(), "data")
            print(f"Debug: Running from source, data_dir: {data_dir}")
        
        # Try the data directory path
        if os.path.exists(data_dir):
            full_path = os.path.join(data_dir, self.photo_path)
            print(f"Debug: Trying data directory path: {full_path}")
            if os.path.exists(full_path):
                # Update the photo_path to the full path
                self.photo_path = full_path
                print(f"Debug: Photo found at data directory path: {full_path}")
                return True
        
        # Try relative to the current working directory
        current_dir = os.getcwd()
        full_path = os.path.join(current_dir, self.photo_path)
        print(f"Debug: Trying current directory path: {full_path}")
        if os.path.exists(full_path):
            # Update the photo_path to the full path
            self.photo_path = full_path
            print(f"Debug: Photo found at current directory path: {full_path}")
            return True
        
        print(f"Debug: Photo not found for employee {self.employee_id}")
        return False
    
    def get_photo_pixmap(self, size: QSize = QSize(400, 400)) -> QPixmap:
        """Get employee photo as QPixmap."""
        print(f"Debug: Employee.get_photo_pixmap called for {self.employee_id} with size: {size}")
        
        if self.has_photo():
            # Ensure we have the full path
            photo_path = self.photo_path
            if not os.path.isabs(photo_path):
                # Try to resolve relative path using the same logic as has_photo
                if getattr(sys, 'frozen', False):
                    # Running from executable
                    exe_dir = os.path.dirname(sys.executable)
                    # Look for data folder relative to executable
                    data_dir = os.path.join(exe_dir, "data")
                    if not os.path.exists(data_dir):
                        # Try parent directory
                        data_dir = os.path.join(os.path.dirname(exe_dir), "data")
                else:
                    # Running from source
                    data_dir = os.path.join(os.getcwd(), "data")
                
                if os.path.exists(data_dir):
                    full_path = os.path.join(data_dir, photo_path)
                    if os.path.exists(full_path):
                        photo_path = full_path
                    else:
                        # Try current directory
                        full_path = os.path.join(os.getcwd(), photo_path)
                        if os.path.exists(full_path):
                            photo_path = full_path
            
            print(f"Debug: Final photo_path for pixmap: {photo_path}")
            if os.path.exists(photo_path):
                pixmap = QPixmap(photo_path)
                if not pixmap.isNull():
                    result = pixmap.scaled(size, Qt.KeepAspectRatio, Qt.SmoothTransformation)
                    print(f"Debug: Photo pixmap created successfully for {self.employee_id}")
                    return result
                else:
                    print(f"Debug: Photo pixmap is null for {self.employee_id}")
            else:
                print(f"Debug: Photo path does not exist: {photo_path}")
        else:
            print(f"Debug: Employee {self.employee_id} has no photo, creating placeholder")
        
        # Return placeholder pixmap
        result = self._create_placeholder_pixmap(size)
        print(f"Debug: Returning placeholder pixmap for {self.employee_id}")
        return result
    
    def get_photo_icon(self, size: QSize = QSize(400, 400)) -> QIcon:
        """Get employee photo as QIcon."""
        print(f"Debug: Employee.get_photo_icon called for {self.employee_id} with size: {size}")
        pixmap = self.get_photo_pixmap(size)
        icon = QIcon(pixmap)
        print(f"Debug: Photo icon created for {self.employee_id}")
        return icon
    
    def _create_placeholder_pixmap(self, size: QSize) -> QPixmap:
        """Create a placeholder pixmap for employees without photos."""
        print(f"Debug: Employee._create_placeholder_pixmap called for {self.employee_id} with size: {size}")
        
        pixmap = QPixmap(size)
        pixmap.fill(Qt.lightGray)
        
        # Add text
        painter = QPainter(pixmap)
        painter.setPen(Qt.darkGray)
        font = painter.font()
        font.setPointSize(12)
        painter.setFont(font)
        
        # Center the text
        text = f"{self.first_name}\n{self.last_name}"
        painter.drawText(pixmap.rect(), Qt.AlignCenter, text)
        painter.end()
        
        print(f"Debug: Placeholder pixmap created for {self.employee_id}")
        return pixmap
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert employee to dictionary for JSON serialization."""
        result = {
            "employee_id": self.employee_id,
            "first_name": self.first_name,
            "last_name": self.last_name,
            "role": self.role,
            "photo_path": self.photo_path,
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
        print(f"Debug: Employee.to_dict called for {self.employee_id}, result: {result}")
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any]) -> 'Employee':
        """Create employee from dictionary."""
        print(f"Debug: Employee.from_dict called with data: {data}")
        employee = cls(
            employee_id=data.get("employee_id", ""),
            first_name=data.get("first_name", ""),
            last_name=data.get("last_name", ""),
            role=data.get("role", ""),
            photo_path=data.get("photo_path", "")
        )
        employee.created_at = data.get("created_at", datetime.now().isoformat())
        employee.updated_at = data.get("updated_at", datetime.now().isoformat())
        print(f"Debug: Employee created from dict: {employee.employee_id}")
        return employee
    
    def update(self, **kwargs):
        """Update employee fields."""
        print(f"Debug: Employee.update called for {self.employee_id} with kwargs: {kwargs}")
        for key, value in kwargs.items():
            if hasattr(self, key):
                setattr(self, key, value)
                print(f"Debug: Updated {key} to {value} for {self.employee_id}")
        self.updated_at = datetime.now().isoformat()
        print(f"Debug: Employee {self.employee_id} updated successfully")
    
    def __str__(self) -> str:
        result = f"Employee({self.employee_id}: {self.full_name})"
        print(f"Debug: Employee.__str__ called for {self.employee_id}, result: {result}")
        return result
    
    def __repr__(self) -> str:
        result = self.__str__()
        print(f"Debug: Employee.__repr__ called for {self.employee_id}, result: {result}")
        return result
    
    def __eq__(self, other) -> bool:
        if not isinstance(other, Employee):
            print(f"Debug: Employee.__eq__ called for {self.employee_id}, other is not Employee: {type(other)}")
            return False
        result = self.employee_id == other.employee_id
        print(f"Debug: Employee.__eq__ called for {self.employee_id}, comparing with {other.employee_id}, result: {result}")
        return result
    
    def __hash__(self) -> int:
        result = hash(self.employee_id)
        print(f"Debug: Employee.__hash__ called for {self.employee_id}, result: {result}")
        return result
