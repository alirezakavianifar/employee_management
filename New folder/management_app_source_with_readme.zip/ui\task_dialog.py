from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QFormLayout,
                             QLabel, QLineEdit, QTextEdit, QComboBox, QSpinBox,
                             QDoubleSpinBox, QDateEdit, QPushButton, QDialogButtonBox,
                             QGroupBox, QTableWidget, QTableWidgetItem, QHeaderView,
                             QMessageBox, QTabWidget, QWidget, QProgressBar)
from PyQt5.QtCore import Qt, QDate, pyqtSignal
from PyQt5.QtGui import QFont, QColor
from datetime import datetime, date
from management_app.models.task import Task, TaskStatus, TaskPriority, TaskManager

class TaskDialog(QDialog):
    """Dialog for adding/editing tasks."""
    
    task_saved = pyqtSignal(Task)
    
    def __init__(self, parent=None, task=None, task_manager=None):
        super().__init__(parent)
        self.task = task
        self.task_manager = task_manager or TaskManager()
        self.setup_ui()
        if task:
            self.load_task_data()
    
    def setup_ui(self):
        """Setup the user interface."""
        self.setWindowTitle("مدیریت وظیفه")
        self.setMinimumSize(500, 400)
        self.setLayoutDirection(Qt.RightToLeft)
        
        # Set proper font for Arabic text
        font = QFont("Tahoma", 9)
        self.setFont(font)
        
        layout = QVBoxLayout()
        
        # Form layout
        form_layout = QFormLayout()
        form_layout.setSpacing(15)
        
        # Title
        self.title_edit = QLineEdit()
        self.title_edit.setFont(font)
        self.title_edit.setPlaceholderText("عنوان وظیفه")
        self.title_edit.setStyleSheet("""
            QLineEdit {
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QLineEdit:focus {
                border-color: #4f46e5;
            }
        """)
        form_layout.addRow("عنوان:", self.title_edit)
        
        # Description
        self.description_edit = QTextEdit()
        self.description_edit.setFont(font)
        self.description_edit.setPlaceholderText("توضیحات وظیفه")
        self.description_edit.setMaximumHeight(80)
        self.description_edit.setStyleSheet("""
            QTextEdit {
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QTextEdit:focus {
                border-color: #4f46e5;
            }
        """)
        form_layout.addRow("توضیحات:", self.description_edit)
        
        # Priority
        self.priority_combo = QComboBox()
        self.priority_combo.setFont(font)
        for priority in TaskPriority:
            self.priority_combo.addItem(priority.value, priority)
        self.priority_combo.setStyleSheet("""
            QComboBox {
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QComboBox:focus {
                border-color: #4f46e5;
            }
        """)
        form_layout.addRow("اولویت:", self.priority_combo)
        
        # Estimated hours
        self.estimated_hours_spin = QDoubleSpinBox()
        self.estimated_hours_spin.setFont(font)
        self.estimated_hours_spin.setRange(0.5, 100.0)
        self.estimated_hours_spin.setSuffix(" ساعت")
        self.estimated_hours_spin.setValue(1.0)
        self.estimated_hours_spin.setStyleSheet("""
            QDoubleSpinBox {
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QDoubleSpinBox:focus {
                border-color: #4f46e5;
            }
        """)
        form_layout.addRow("ساعت تخمینی:", self.estimated_hours_spin)
        
        # Target date
        self.target_date_edit = QDateEdit()
        self.target_date_edit.setFont(font)
        self.target_date_edit.setDate(QDate.currentDate())
        self.target_date_edit.setCalendarPopup(True)
        self.target_date_edit.setStyleSheet("""
            QDateEdit {
                padding: 8px;
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QDateEdit:focus {
                border-color: #4f46e5;
            }
        """)
        form_layout.addRow("تاریخ هدف:", self.target_date_edit)
        
        layout.addLayout(form_layout)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        save_btn = QPushButton("ذخیره")
        save_btn.setFont(font)
        save_btn.setStyleSheet("""
            QPushButton {
                background: #4f46e5;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QPushButton:hover {
                background: #4338ca;
            }
        """)
        save_btn.clicked.connect(self.save_task)
        
        cancel_btn = QPushButton("لغو")
        cancel_btn.setFont(font)
        cancel_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                padding: 10px 20px;
                border-radius: 6px;
                font-weight: bold;
                font-size: 14px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        cancel_btn.clicked.connect(self.reject)
        
        button_layout.addWidget(save_btn)
        button_layout.addWidget(cancel_btn)
        button_layout.addStretch()
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def load_task_data(self):
        """Load existing task data into the form."""
        if not self.task:
            return
        
        self.title_edit.setText(self.task.title)
        self.description_edit.setPlainText(self.task.description)
        
        # Set priority
        for i in range(self.priority_combo.count()):
            if self.priority_combo.itemData(i) == self.task.priority:
                self.priority_combo.setCurrentIndex(i)
                break
        
        self.estimated_hours_spin.setValue(self.task.estimated_hours)
        
        # Set target date
        try:
            target_date = datetime.strptime(self.task.target_date, "%Y-%m-%d").date()
            self.target_date_edit.setDate(QDate(target_date.year, target_date.month, target_date.day))
        except:
            self.target_date_edit.setDate(QDate.currentDate())
    
    def save_task(self):
        """Save the task data."""
        title = self.title_edit.text().strip()
        if not title:
            QMessageBox.warning(self, "خطا", "لطفاً عنوان وظیفه را وارد کنید")
            return
        
        description = self.description_edit.toPlainText().strip()
        priority = self.priority_combo.currentData()
        estimated_hours = self.estimated_hours_spin.value()
        target_date = self.target_date_edit.date().toString("yyyy-MM-dd")
        
        if self.task:
            # Update existing task
            self.task.title = title
            self.task.description = description
            self.task.priority = priority
            self.task.estimated_hours = estimated_hours
            self.task.target_date = target_date
            self.task.updated_at = datetime.now().isoformat()
        else:
            # Create new task
            self.task = Task(
                task_id="",  # Will be set by task manager
                title=title,
                description=description,
                priority=priority,
                estimated_hours=estimated_hours,
                target_date=target_date
            )
        
        self.task_saved.emit(self.task)
        self.accept()

class TaskManagementDialog(QDialog):
    """Dialog for comprehensive task management."""
    
    def __init__(self, parent=None, task_manager=None):
        super().__init__(parent)
        self.task_manager = task_manager or TaskManager()
        self.parent = parent
        self.setup_ui()
        self.refresh_tasks()
    
    def save_data_to_controller(self):
        """Save data to the main controller if available."""
        try:
            if self.parent and hasattr(self.parent, 'controller'):
                # Get the main controller from the parent window
                controller = self.parent.controller
                if hasattr(controller, 'save_data'):
                    success = controller.save_data()
                    if success:
                        print("Data saved to controller successfully")
                    else:
                        print("Failed to save data to controller")
                    return success
            return False
        except Exception as e:
            print(f"Error saving data to controller: {e}")
            return False
    
    def setup_ui(self):
        """Setup the user interface."""
        self.setWindowTitle("مدیریت وظایف و سفارشات")
        self.setMinimumSize(1200, 800)
        self.resize(1200, 800)
        self.setLayoutDirection(Qt.RightToLeft)
        
        # Set proper font for Arabic text
        font = QFont("Tahoma", 12)
        self.setFont(font)
        
        layout = QVBoxLayout()
        
        # Tab widget for different views
        tab_widget = QTabWidget()
        tab_widget.setFont(font)
        tab_widget.setLayoutDirection(Qt.RightToLeft)
        
        # Tasks tab
        tasks_tab = self.create_tasks_tab()
        tab_widget.addTab(tasks_tab, "وظایف")
        
        # Progress tab
        progress_tab = self.create_progress_tab()
        tab_widget.addTab(progress_tab, "پیشرفت")
        
        # AI Analysis tab
        ai_tab = self.create_ai_analysis_tab()
        tab_widget.addTab(ai_tab, "تحلیل هوش مصنوعی")
        
        layout.addWidget(tab_widget)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        add_task_btn = QPushButton("➕ وظیفه جدید")
        add_task_btn.setFont(font)
        add_task_btn.setMinimumHeight(50)
        add_task_btn.setStyleSheet("""
            QPushButton {
                background: #10b981;
                color: white;
                border: none;
                padding: 16px 32px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 18px;
                font-family: 'Tahoma', Arial, sans-serif;
                min-height: 30px;
            }
            QPushButton:hover {
                background: #059669;
            }
        """)
        add_task_btn.clicked.connect(self.add_new_task)
        
        close_btn = QPushButton("بستن")
        close_btn.setFont(font)
        close_btn.setMinimumHeight(50)
        close_btn.setStyleSheet("""
            QPushButton {
                background: #6b7280;
                color: white;
                border: none;
                padding: 16px 32px;
                border-radius: 10px;
                font-weight: bold;
                font-size: 18px;
                font-family: 'Tahoma', Arial, sans-serif;
                min-height: 30px;
            }
            QPushButton:hover {
                background: #4b5563;
            }
        """)
        close_btn.clicked.connect(self.accept)
        
        button_layout.addWidget(add_task_btn)
        button_layout.addStretch()
        button_layout.addWidget(close_btn)
        
        layout.addLayout(button_layout)
        self.setLayout(layout)
    
    def create_tasks_tab(self):
        """Create the tasks management tab."""
        tab = QWidget()
        tab.setLayoutDirection(Qt.RightToLeft)
        layout = QVBoxLayout()
        
        # Set font for the tab
        font = QFont("Tahoma", 12)
        tab.setFont(font)
        
        # Tasks table
        self.tasks_table = QTableWidget()
        self.tasks_table.setColumnCount(7)
        self.tasks_table.setFont(font)
        self.tasks_table.setHorizontalHeaderLabels([
            "شناسه", "عنوان", "اولویت", "وضعیت", "ساعت تخمینی", "تاریخ هدف", "عملیات"
        ])
        
        # Set table properties
        header = self.tasks_table.horizontalHeader()
        header.setSectionResizeMode(1, QHeaderView.Stretch)  # Title column stretches
        header.setSectionResizeMode(0, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(2, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(3, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(4, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(5, QHeaderView.ResizeToContents)
        header.setSectionResizeMode(6, QHeaderView.ResizeToContents)
        
        self.tasks_table.setStyleSheet("""
            QTableWidget {
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                background: white;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QTableWidget::item {
                padding: 16px;
                border-bottom: 1px solid #f3f4f6;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QHeaderView::section {
                background: #f9fafb;
                padding: 16px;
                border: none;
                border-bottom: 2px solid #e5e7eb;
                font-weight: bold;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Set minimum row height to accommodate larger buttons
        self.tasks_table.verticalHeader().setDefaultSectionSize(70)
        
        layout.addWidget(self.tasks_table)
        tab.setLayout(layout)
        return tab
    
    def create_progress_tab(self):
        """Create the progress tracking tab."""
        tab = QWidget()
        tab.setLayoutDirection(Qt.RightToLeft)
        layout = QVBoxLayout()
        
        # Set font for the tab
        font = QFont("Tahoma", 12)
        tab.setFont(font)
        
        # Progress overview
        progress_group = QGroupBox("نمای کلی پیشرفت")
        progress_group.setFont(font)
        progress_group.setLayoutDirection(Qt.RightToLeft)
        progress_layout = QFormLayout()
        
        self.total_tasks_label = QLabel("0")
        self.total_tasks_label.setFont(font)
        self.completed_tasks_label = QLabel("0")
        self.completed_tasks_label.setFont(font)
        self.in_progress_tasks_label = QLabel("0")
        self.in_progress_tasks_label.setFont(font)
        self.pending_tasks_label = QLabel("0")
        self.pending_tasks_label.setFont(font)
        
        progress_layout.addRow("کل وظایف:", self.total_tasks_label)
        progress_layout.addRow("تکمیل شده:", self.completed_tasks_label)
        progress_layout.addRow("در حال انجام:", self.in_progress_tasks_label)
        progress_layout.addRow("در انتظار:", self.pending_tasks_label)
        
        # Progress bar
        self.progress_bar = QProgressBar()
        self.progress_bar.setRange(0, 100)
        self.progress_bar.setValue(0)
        self.progress_bar.setStyleSheet("""
            QProgressBar {
                border: 2px solid #e5e7eb;
                border-radius: 6px;
                text-align: center;
                font-weight: bold;
            }
            QProgressBar::chunk {
                background: qlineargradient(x1:0, y1:0, x2:1, y2:0,
                    stop:0 #10b981, stop:1 #059669);
                border-radius: 4px;
            }
        """)
        progress_layout.addRow("درصد پیشرفت:", self.progress_bar)
        
        progress_group.setLayout(progress_layout)
        layout.addWidget(progress_group)
        
        # Hours tracking
        hours_group = QGroupBox("پیگیری ساعات")
        hours_layout = QFormLayout()
        
        self.total_estimated_label = QLabel("0 ساعت")
        self.total_actual_label = QLabel("0 ساعت")
        self.completed_estimated_label = QLabel("0 ساعت")
        self.completed_actual_label = QLabel("0 ساعت")
        
        hours_layout.addRow("کل ساعت تخمینی:", self.total_estimated_label)
        hours_layout.addRow("کل ساعت واقعی:", self.total_actual_label)
        hours_layout.addRow("ساعت تخمینی تکمیل شده:", self.completed_estimated_label)
        hours_layout.addRow("ساعت واقعی تکمیل شده:", self.completed_actual_label)
        
        hours_group.setLayout(hours_layout)
        layout.addWidget(hours_group)
        
        layout.addStretch()
        tab.setLayout(layout)
        return tab
    
    def create_ai_analysis_tab(self):
        """Create the AI analysis tab."""
        tab = QWidget()
        tab.setLayoutDirection(Qt.RightToLeft)
        layout = QVBoxLayout()
        
        # Set font for the tab
        font = QFont("Tahoma", 12)
        tab.setFont(font)
        
        # AI recommendations
        ai_group = QGroupBox("توصیه‌های هوش مصنوعی")
        ai_group.setFont(font)
        ai_group.setLayoutDirection(Qt.RightToLeft)
        ai_layout = QVBoxLayout()
        
        self.ai_recommendations_label = QLabel("در حال بارگذاری تحلیل...")
        self.ai_recommendations_label.setFont(font)
        self.ai_recommendations_label.setStyleSheet("""
            QLabel {
                padding: 15px;
                background: #f8fafc;
                border: 1px solid #e5e7eb;
                border-radius: 6px;
                font-size: 14px;
                line-height: 1.5;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        self.ai_recommendations_label.setWordWrap(True)
        ai_layout.addWidget(self.ai_recommendations_label)
        
        ai_group.setLayout(ai_layout)
        layout.addWidget(ai_group)
        
        # Capacity analysis
        capacity_group = QGroupBox("تحلیل ظرفیت")
        capacity_layout = QFormLayout()
        
        self.current_capacity_label = QLabel("0")
        self.next_week_orders_label = QLabel("0")
        self.two_weeks_orders_label = QLabel("0")
        self.capacity_status_label = QLabel("نامشخص")
        
        capacity_layout.addRow("ظرفیت فعلی:", self.current_capacity_label)
        capacity_layout.addRow("سفارشات هفته آینده:", self.next_week_orders_label)
        capacity_layout.addRow("سفارشات دو هفته آینده:", self.two_weeks_orders_label)
        capacity_layout.addRow("وضعیت ظرفیت:", self.capacity_status_label)
        
        capacity_group.setLayout(capacity_layout)
        layout.addWidget(capacity_group)
        
        layout.addStretch()
        tab.setLayout(layout)
        return tab
    
    def refresh_tasks(self):
        """Refresh the tasks table and progress data."""
        print(f"refresh_tasks called")
        print(f"Task manager has {len(self.task_manager.tasks)} tasks")
        for task_id, task in self.task_manager.tasks.items():
            print(f"  Task {task_id}: {task.title} - {task.status.value}")
        
        self.refresh_tasks_table()
        self.refresh_progress_data()
        self.refresh_ai_analysis()
        print("refresh_tasks completed")
    
    def refresh_tasks_table(self):
        """Refresh the tasks table."""
        self.tasks_table.setRowCount(0)
        
        # Set font for buttons
        font = QFont("Tahoma", 12)
        
        for task in self.task_manager.tasks.values():
            row = self.tasks_table.rowCount()
            self.tasks_table.insertRow(row)
            
            # Task ID
            self.tasks_table.setItem(row, 0, QTableWidgetItem(task.task_id))
            
            # Title
            self.tasks_table.setItem(row, 1, QTableWidgetItem(task.title))
            
            # Priority
            priority_item = QTableWidgetItem(task.priority.value)
            if task.priority == TaskPriority.URGENT:
                priority_item.setBackground(QColor("#fef2f2"))
                priority_item.setForeground(QColor("#dc2626"))
            elif task.priority == TaskPriority.HIGH:
                priority_item.setBackground(QColor("#fff7ed"))
                priority_item.setForeground(QColor("#ea580c"))
            self.tasks_table.setItem(row, 2, priority_item)
            
            # Status
            status_item = QTableWidgetItem(task.status.value)
            if task.status == TaskStatus.COMPLETED:
                status_item.setBackground(QColor("#f0fdf4"))
                status_item.setForeground(QColor("#16a34a"))
            elif task.status == TaskStatus.IN_PROGRESS:
                status_item.setBackground(QColor("#eff6ff"))
                status_item.setForeground(QColor("#2563eb"))
            self.tasks_table.setItem(row, 3, status_item)
            
            # Estimated hours
            self.tasks_table.setItem(row, 4, QTableWidgetItem(f"{task.estimated_hours} ساعت"))
            
            # Target date
            self.tasks_table.setItem(row, 5, QTableWidgetItem(task.target_date))
            
            # Actions
            actions_widget = QWidget()
            actions_layout = QHBoxLayout()
            actions_layout.setContentsMargins(0, 0, 0, 0)
            
            if task.status == TaskStatus.PENDING:
                start_btn = QPushButton("شروع")
                start_btn.setFont(font)
                start_btn.setMinimumHeight(45)
                start_btn.setStyleSheet("""
                    QPushButton {
                        background: #10b981;
                        color: white;
                        border: none;
                        padding: 12px 20px;
                        border-radius: 8px;
                        font-size: 16px;
                        font-family: 'Tahoma', Arial, sans-serif;
                        min-height: 25px;
                        min-width: 80px;
                    }
                    QPushButton:hover {
                        background: #059669;
                    }
                """)
                start_btn.clicked.connect(lambda checked, t=task: self.start_task(t))
                actions_layout.addWidget(start_btn)
            
            elif task.status == TaskStatus.IN_PROGRESS:
                complete_btn = QPushButton("تکمیل")
                complete_btn.setFont(font)
                complete_btn.setMinimumHeight(45)
                complete_btn.setStyleSheet("""
                    QPushButton {
                        background: #4f46e5;
                        color: white;
                        border: none;
                        padding: 12px 20px;
                        border-radius: 8px;
                        font-size: 16px;
                        font-family: 'Tahoma', Arial, sans-serif;
                        min-height: 25px;
                        min-width: 80px;
                    }
                    QPushButton:hover {
                        background: #4338ca;
                    }
                """)
                complete_btn.clicked.connect(lambda checked, t=task: self.complete_task(t))
                actions_layout.addWidget(complete_btn)
            
            edit_btn = QPushButton("ویرایش")
            edit_btn.setFont(font)
            edit_btn.setMinimumHeight(45)
            edit_btn.setStyleSheet("""
                QPushButton {
                    background: #f59e0b;
                    color: white;
                    border: none;
                    padding: 12px 20px;
                    border-radius: 8px;
                    font-size: 16px;
                    font-family: 'Tahoma', Arial, sans-serif;
                    min-height: 25px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background: #d97706;
                }
            """)
            edit_btn.clicked.connect(lambda checked, t=task: self.edit_task(t))
            actions_layout.addWidget(edit_btn)
            
            delete_btn = QPushButton("حذف")
            delete_btn.setFont(font)
            delete_btn.setMinimumHeight(45)
            delete_btn.setStyleSheet("""
                QPushButton {
                    background: #ef4444;
                    color: white;
                    border: none;
                    padding: 12px 20px;
                    border-radius: 8px;
                    font-size: 16px;
                    font-family: 'Tahoma', Arial, sans-serif;
                    min-height: 25px;
                    min-width: 80px;
                }
                QPushButton:hover {
                    background: #dc2626;
                }
            """)
            delete_btn.clicked.connect(lambda checked, t=task: self.delete_task(t))
            actions_layout.addWidget(delete_btn)
            
            actions_widget.setLayout(actions_layout)
            self.tasks_table.setCellWidget(row, 6, actions_widget)
    
    def refresh_progress_data(self):
        """Refresh the progress data."""
        progress = self.task_manager.get_task_progress()
        
        self.total_tasks_label.setText(str(progress["total_tasks"]))
        self.completed_tasks_label.setText(str(progress["completed_tasks"]))
        self.in_progress_tasks_label.setText(str(progress["in_progress_tasks"]))
        self.pending_tasks_label.setText(str(progress["pending_tasks"]))
        
        self.progress_bar.setValue(int(progress["progress_percentage"]))
        
        self.total_estimated_label.setText(f"{progress['total_estimated_hours']} ساعت")
        self.total_actual_label.setText(f"{progress['total_actual_hours']} ساعت")
        self.completed_estimated_label.setText(f"{progress['completed_estimated_hours']} ساعت")
        self.completed_actual_label.setText(f"{progress['completed_actual_hours']} ساعت")
    
    def refresh_ai_analysis(self):
        """Refresh the AI analysis data."""
        try:
            from shared.ai_rules import AIRulesEngine
            
            ai_engine = AIRulesEngine()
            
            # Get current week data
            current_week = ai_engine.get_week_number()
            if current_week is None:
                current_week = datetime.now().isocalendar()[1]
            next_week = current_week + 1
            two_weeks = current_week + 2
            
            # Get tasks for next weeks
            next_week_tasks = self.task_manager.get_tasks_by_week(next_week)
            two_weeks_tasks = self.task_manager.get_tasks_by_week(two_weeks)
            
            # Calculate total hours for orders
            next_week_hours = sum(task.estimated_hours for task in next_week_tasks if task.estimated_hours is not None)
            two_weeks_hours = sum(task.estimated_hours for task in two_weeks_tasks if task.estimated_hours is not None)
            
            # Mock capacity (this should come from settings)
            current_capacity = 10  # Default capacity
            
            # Create orders data for AI analysis
            orders_data = [
                {'week': next_week, 'quantity': next_week_hours},
                {'week': two_weeks, 'quantity': two_weeks_hours}
            ]
            
            # Get AI recommendation
            recommendation = ai_engine.analyze_capacity_vs_orders(current_capacity, orders_data)
            
            # Update UI
            self.ai_recommendations_label.setText(recommendation)
            self.current_capacity_label.setText(str(current_capacity))
            self.next_week_orders_label.setText(f"{next_week_hours} ساعت")
            self.two_weeks_orders_label.setText(f"{two_weeks_hours} ساعت")
            
            # Determine capacity status
            if next_week_hours is None:
                next_week_hours = 0
            if two_weeks_hours is None:
                two_weeks_hours = 0
            if current_capacity is None:
                current_capacity = 10
                
            if next_week_hours <= current_capacity:
                self.capacity_status_label.setText("ظرفیت کافی")
                self.capacity_status_label.setStyleSheet("color: #16a34a; font-weight: bold;")
            elif next_week_hours + two_weeks_hours >= current_capacity * 2 * 1.15:
                self.capacity_status_label.setText("نیاز به اضافه‌کاری")
                self.capacity_status_label.setStyleSheet("color: #dc2626; font-weight: bold;")
            else:
                self.capacity_status_label.setText("ظرفیت متعادل")
                self.capacity_status_label.setStyleSheet("color: #f59e0b; font-weight: bold;")
                
        except Exception as e:
            self.ai_recommendations_label.setText(f"خطا در تحلیل: {str(e)}")
    
    def add_new_task(self):
        """Add a new task."""
        dialog = TaskDialog(self, task_manager=self.task_manager)
        dialog.task_saved.connect(self.on_task_saved)
        if dialog.exec_() == QDialog.Accepted:
            self.refresh_tasks()
    
    def on_task_saved(self, task):
        """Handle when a task is saved."""
        try:
            print(f"on_task_saved called with task: {task}")
            print(f"Task ID: '{task.task_id}' (empty: {not task.task_id})")
            print(f"Task title: {task.title}")
            print(f"Task priority: {task.priority}")
            print(f"Task estimated hours: {task.estimated_hours}")
            print(f"Task target date: {task.target_date}")
            
            if not task.task_id:  # New task
                print("Adding new task to task manager...")
                # Add the task to the task manager
                task_id = self.task_manager.add_existing_task(task)
                print(f"Task added with ID: {task_id}")
                print(f"Task manager now has {len(self.task_manager.tasks)} tasks")
            else:  # Existing task updated
                print(f"Updating existing task: {task.task_id}")
                # Update the task in the task manager
                success = self.task_manager.update_task(
                    task.task_id,
                    title=task.title,
                    description=task.description,
                    priority=task.priority,
                    estimated_hours=task.estimated_hours,
                    target_date=task.target_date
                )
                if success:
                    print(f"Task updated: {task.task_id}")
                else:
                    print(f"Failed to update task: {task.task_id}")
            
            # Refresh the display
            print("Refreshing task display...")
            self.refresh_tasks()
            
            # Save data to controller
            print("Saving data to controller...")
            self.save_data_to_controller()
            
            print("Task save process completed successfully")
            
        except Exception as e:
            print(f"Error handling task save: {e}")
            import traceback
            traceback.print_exc()
            from PyQt5.QtWidgets import QMessageBox
            QMessageBox.critical(self, "خطا", f"خطا در ذخیره وظیفه: {str(e)}")
    
    def edit_task(self, task):
        """Edit an existing task."""
        dialog = TaskDialog(self, task=task, task_manager=self.task_manager)
        dialog.task_saved.connect(self.on_task_saved)
        if dialog.exec_() == QDialog.Accepted:
            self.refresh_tasks()
    
    def start_task(self, task):
        """Start a task."""
        if task.start_task():
            QMessageBox.information(self, "موفق", f"وظیفه '{task.title}' شروع شد")
            self.refresh_tasks()
    
    def complete_task(self, task):
        """Complete a task."""
        from PyQt5.QtWidgets import QInputDialog
        
        actual_hours, ok = QInputDialog.getDouble(
            self, "ساعت واقعی", 
            f"ساعت واقعی صرف شده برای '{task.title}':", 
            task.estimated_hours, 0.5, 100.0, 1
        )
        
        if ok:
            notes, ok = QInputDialog.getText(
                self, "یادداشت", 
                f"یادداشت برای '{task.title}':"
            )
            
            if task.complete_task(actual_hours, notes or ""):
                QMessageBox.information(self, "موفق", f"وظیفه '{task.title}' تکمیل شد")
                self.refresh_tasks()
    
    def delete_task(self, task):
        """Delete a task."""
        reply = QMessageBox.question(
            self, "تأیید حذف", 
            f"آیا از حذف وظیفه '{task.title}' اطمینان دارید؟",
            QMessageBox.Yes | QMessageBox.No,
            QMessageBox.No
        )
        
        if reply == QMessageBox.Yes:
            if self.task_manager.delete_task(task.task_id):
                QMessageBox.information(self, "موفق", "وظیفه حذف شد")
                self.refresh_tasks()
