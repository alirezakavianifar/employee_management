"""
Export service for the management app.
Handles PNG, PDF, and CSV export functionality.
"""

import os
import json
import csv
from datetime import datetime
from pathlib import Path
from typing import Dict, List, Optional, Tuple
import logging

try:
    from PIL import Image, ImageDraw, ImageFont
    import pandas as pd
    
    # WeasyPrint has dependency issues on Windows, so we'll use HTML export instead
    WeasyPrint = False
        
    # PdfKit requires wkhtmltopdf which may not be installed
    PdfKit = False
        
    # Keep ReportLab as last resort
    try:
        from reportlab.lib.pagesizes import A4, landscape
        from reportlab.platypus import SimpleDocTemplate, Table, TableStyle, Paragraph, Spacer
        from reportlab.lib.styles import getSampleStyleSheet, ParagraphStyle
        from reportlab.lib.units import inch
        from reportlab.pdfbase import pdfmetrics
        from reportlab.pdfbase.ttfonts import TTFont
        from reportlab.lib import colors
        ReportLab = True
    except ImportError:
        ReportLab = False
        
except ImportError as e:
    logging.error(f"Failed to import export dependencies: {e}")
    Image = None
    ImageDraw = None
    ImageFont = None
    WeasyPrint = False
    PdfKit = False
    ReportLab = False
    pd = None


class ExportService:
    """Service for exporting data in various formats."""
    
    def __init__(self, shared_folder_path: str):
        """Initialize the export service.
        
        Args:
            shared_folder_path: Path to the shared folder for data storage
        """
        self.shared_folder_path = Path(shared_folder_path)
        self.exports_dir = self.shared_folder_path / "data" / "exports"
        self.reports_dir = self.shared_folder_path / "data" / "reports"
        self.images_dir = self.shared_folder_path / "data" / "images" / "staff"
        
        # Ensure export directory exists
        self.exports_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Persian text constants
        self.persian_texts = {
            'morning_shift': 'شیفت صبح',
            'evening_shift': 'شیفت عصر',
            'absent': 'غایب',
            'vacation': 'مرخصی',
            'sick': 'بیمار',
            'performance_chart_title': 'افزایش عملکرد — هفتهٔ {}',
            'weeks_label': 'هفته‌ها',
            'units_label': 'واحدها',
            'export_success': 'خروجی با موفقیت ذخیره شد',
            'export_error': 'خطا در ایجاد خروجی',
            'no_data': 'داده‌ای برای خروجی موجود نیست',
            'file_save_error': 'خطا در ذخیره فایل',
            'unsupported_format': 'فرمت پشتیبانی نشده'
        }
    
    def export_report(self, report_data: Dict, export_format: str, 
                     output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data in the specified format.
        
        Args:
            report_data: Dictionary containing report data
            export_format: Format to export ('PNG', 'PDF', or 'CSV')
            output_path: Optional custom output path
            
        Returns:
            Tuple of (success, message)
        """
        try:
            if export_format.upper() == 'PNG':
                return self._export_to_png(report_data, output_path)
            elif export_format.upper() == 'PDF':
                return self._export_to_pdf(report_data, output_path)
            elif export_format.upper() == 'HTML':
                return self._export_to_html_with_persian(report_data, output_path)
            elif export_format.upper() == 'CSV':
                return self._export_to_csv(report_data, output_path)
            else:
                return False, f"{self.persian_texts['unsupported_format']}: {export_format}"
                
        except Exception as e:
            self.logger.error(f"Export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _export_to_png(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to PNG image."""
        if not Image:
            return False, "کتابخانه Pillow نصب نشده است"
        
        try:
            # Create image
            img_width, img_height = 1200, 800
            img = Image.new('RGB', (img_width, img_height), color='white')
            draw = ImageDraw.Draw(img)
            
            # Try to use a Persian font, fallback to default
            try:
                # Try multiple Persian-compatible fonts
                font_paths = [
                    "C:/Windows/Fonts/arial.ttf",
                    "C:/Windows/Fonts/tahoma.ttf",
                    "C:/Windows/Fonts/calibri.ttf",
                    "C:/Windows/Fonts/msyh.ttf",  # Microsoft YaHei
                    "C:/Windows/Fonts/msjh.ttf",  # Microsoft JhengHei
                ]
                
                font_large = None
                font_medium = None
                font_small = None
                
                for font_path in font_paths:
                    if os.path.exists(font_path):
                        try:
                            font_large = ImageFont.truetype(font_path, 24)
                            font_medium = ImageFont.truetype(font_path, 18)
                            font_small = ImageFont.truetype(font_path, 14)
                            self.logger.info(f"Using Persian font: {font_path}")
                            break
                        except Exception as e:
                            self.logger.warning(f"Failed to load font {font_path}: {e}")
                            continue
                
                # If no Persian fonts found, use default
                if not font_large:
                    font_large = ImageFont.load_default()
                    font_medium = ImageFont.load_default()
                    font_small = ImageFont.load_default()
                    self.logger.warning("Using default font (Persian text may not render correctly)")
                    
            except Exception as e:
                self.logger.error(f"Font loading error: {e}")
                font_large = ImageFont.load_default()
                font_medium = ImageFont.load_default()
                font_small = ImageFont.load_default()
            
            # Draw title
            title = f"گزارش {report_data.get('date', 'تاریخ نامشخص')}"
            draw.text((img_width//2 - 100, 30), title, fill='black', font=font_large)
            
            # Draw shifts information
            y_offset = 100
            
            # Morning shift
            draw.text((50, y_offset), self.persian_texts['morning_shift'], fill='blue', font=font_medium)
            y_offset += 30
            
            morning_shift = report_data.get('morning_shift', [])
            for i, employee in enumerate(morning_shift[:5]):  # Limit to 5 employees per line
                text = f"  {employee.get('first_name', '')} {employee.get('last_name', '')}"
                draw.text((70, y_offset), text, fill='black', font=font_small)
                y_offset += 25
            
            # Evening shift
            y_offset += 20
            draw.text((50, y_offset), self.persian_texts['evening_shift'], fill='green', font=font_medium)
            y_offset += 30
            
            evening_shift = report_data.get('evening_shift', [])
            for i, employee in enumerate(evening_shift[:5]):
                text = f"  {employee.get('first_name', '')} {employee.get('last_name', '')}"
                draw.text((70, y_offset), text, fill='black', font=font_small)
                y_offset += 25
            
            # Absences
            y_offset += 20
            draw.text((50, y_offset), "غیبت‌ها:", fill='red', font=font_medium)
            y_offset += 30
            
            absences = report_data.get('absences', {})
            for absence_type, count in absences.items():
                text = f"  {absence_type}: {count}"
                draw.text((70, y_offset), text, fill='black', font=font_small)
                y_offset += 25
            
            # Save image
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.png"
            
            img.save(output_path)
            self.logger.info(f"PNG export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"PNG export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _export_to_pdf(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to PDF using the best available method."""
        
        # Try to create HTML file with Persian text (works on all systems)
        return self._export_to_html_with_persian(report_data, output_path)
    
    def _export_to_html_with_persian(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to HTML with Persian text (can be opened in browser and printed to PDF)."""
        try:
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.html"
            
            # Create HTML content with Persian text
            html_content = self._create_persian_html(report_data)
            
            # Save HTML file
            with open(output_path, 'w', encoding='utf-8') as f:
                f.write(html_content)
            
            self.logger.info(f"HTML export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"HTML export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _export_to_pdf_weasyprint(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to PDF using WeasyPrint (best Persian support)."""
        try:
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.pdf"
            
            # Create HTML content with Persian text
            html_content = self._create_persian_html(report_data)
            
            # Create CSS for styling
            css_content = """
            @font-face {
                font-family: 'PersianFont';
                src: url('C:/Windows/Fonts/msyh.ttf') format('truetype');
            }
            
            body {
                font-family: 'PersianFont', 'Arial', sans-serif;
                direction: rtl;
                text-align: right;
                margin: 20px;
                background-color: white;
            }
            
            .title {
                font-size: 24px;
                text-align: center;
                margin-bottom: 30px;
                color: #333;
            }
            
            table {
                width: 100%;
                border-collapse: collapse;
                margin-bottom: 20px;
                font-size: 14px;
            }
            
            th {
                background-color: #4a4a4a;
                color: white;
                padding: 12px;
                text-align: center;
                border: 1px solid #ddd;
            }
            
            td {
                padding: 10px;
                text-align: center;
                border: 1px solid #ddd;
                background-color: #f9f9f9;
            }
            
            .header-row {
                background-color: #4a4a4a !important;
                color: white !important;
            }
            """
            
            # Generate PDF using WeasyPrint
            html_doc = HTML(string=html_content)
            css_doc = CSS(string=css_content)
            
            html_doc.write_pdf(str(output_path), stylesheets=[css_doc])
            
            self.logger.info(f"WeasyPrint PDF export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"WeasyPrint PDF export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _create_persian_html(self, report_data: Dict) -> str:
        """Create enhanced HTML content with Persian text for professional reports."""
        
        # Calculate summary statistics
        morning_count = len(report_data.get('morning_shift', []))
        evening_count = len(report_data.get('evening_shift', []))
        total_employees = morning_count + evening_count
        total_absences = sum(report_data.get('absences', {}).values())
        
        html = f"""
        <!DOCTYPE html>
        <html dir="rtl" lang="fa">
        <head>
            <meta charset="UTF-8">
            <title>گزارش شیفت کارمندان</title>
            <style>
                @import url('https://fonts.googleapis.com/css2?family=Vazirmatn:wght@300;400;500;600;700&display=swap');
                
                * {{
                    margin: 0;
                    padding: 0;
                    box-sizing: border-box;
                }}
                
                body {{
                    font-family: 'Vazirmatn', 'Tahoma', 'Arial', sans-serif;
                    direction: rtl;
                    text-align: right;
                    background: linear-gradient(135deg, #667eea 0%, #764ba2 100%);
                    min-height: 100vh;
                    padding: 20px;
                    color: #333;
                }}
                
                .container {{
                    max-width: 1200px;
                    margin: 0 auto;
                    background: white;
                    border-radius: 20px;
                    box-shadow: 0 20px 40px rgba(0,0,0,0.1);
                    overflow: hidden;
                }}
                
                .header {{
                    background: linear-gradient(135deg, #2c3e50 0%, #34495e 100%);
                    color: white;
                    padding: 40px;
                    text-align: center;
                    position: relative;
                }}
                
                .header::before {{
                    content: '';
                    position: absolute;
                    top: 0;
                    left: 0;
                    right: 0;
                    bottom: 0;
                    background: url('data:image/svg+xml,<svg xmlns="http://www.w3.org/2000/svg" viewBox="0 0 100 100"><defs><pattern id="grain" width="100" height="100" patternUnits="userSpaceOnUse"><circle cx="25" cy="25" r="1" fill="white" opacity="0.1"/><circle cx="75" cy="75" r="1" fill="white" opacity="0.1"/><circle cx="50" cy="10" r="0.5" fill="white" opacity="0.1"/></pattern></defs><rect width="100" height="100" fill="url(%23grain)"/></svg>');
                    opacity: 0.3;
                }}
                
                .header h1 {{
                    font-size: 2.5em;
                    font-weight: 700;
                    margin-bottom: 10px;
                    position: relative;
                    z-index: 1;
                }}
                
                .header .subtitle {{
                    font-size: 1.2em;
                    opacity: 0.9;
                    font-weight: 300;
                    position: relative;
                    z-index: 1;
                }}
                
                .header .date {{
                    font-size: 1.1em;
                    opacity: 0.8;
                    margin-top: 15px;
                    position: relative;
                    z-index: 1;
                }}
                
                .summary-cards {{
                    display: flex;
                    gap: 20px;
                    padding: 30px;
                    background: #f8f9fa;
                    border-bottom: 1px solid #e9ecef;
                }}
                
                .summary-card {{
                    flex: 1;
                    background: white;
                    padding: 25px;
                    border-radius: 15px;
                    box-shadow: 0 5px 15px rgba(0,0,0,0.08);
                    text-align: center;
                    border-top: 4px solid #3498db;
                    transition: transform 0.3s ease;
                }}
                
                .summary-card:hover {{
                    transform: translateY(-5px);
                }}
                
                .summary-card.morning {{
                    border-top-color: #e74c3c;
                }}
                
                .summary-card.evening {{
                    border-top-color: #f39c12;
                }}
                
                .summary-card.absences {{
                    border-top-color: #9b59b6;
                }}
                
                .summary-card .number {{
                    font-size: 2.5em;
                    font-weight: 700;
                    color: #2c3e50;
                    margin-bottom: 10px;
                }}
                
                .summary-card .label {{
                    font-size: 1.1em;
                    color: #7f8c8d;
                    font-weight: 500;
                }}
                
                .content {{
                    padding: 40px;
                }}
                
                .section {{
                    margin-bottom: 40px;
                }}
                
                .section-title {{
                    font-size: 1.8em;
                    font-weight: 600;
                    color: #2c3e50;
                    margin-bottom: 25px;
                    padding-bottom: 15px;
                    border-bottom: 3px solid #3498db;
                    position: relative;
                }}
                
                .section-title::before {{
                    content: '';
                    position: absolute;
                    bottom: -3px;
                    right: 0;
                    width: 50px;
                    height: 3px;
                    background: #e74c3c;
                }}
                
                table {{
                    width: 100%;
                    border-collapse: collapse;
                    margin-bottom: 30px;
                    background: white;
                    border-radius: 15px;
                    overflow: hidden;
                    box-shadow: 0 10px 30px rgba(0,0,0,0.1);
                }}
                
                th {{
                    background: linear-gradient(135deg, #34495e 0%, #2c3e50 100%);
                    color: white;
                    padding: 20px;
                    text-align: center;
                    font-weight: 600;
                    font-size: 1.1em;
                    border: none;
                }}
                
                td {{
                    padding: 18px 20px;
                    text-align: center;
                    border-bottom: 1px solid #ecf0f1;
                    font-size: 1em;
                }}
                
                tr:nth-child(even) {{
                    background-color: #f8f9fa;
                }}
                
                tr:hover {{
                    background-color: #e8f4fd;
                    transition: background-color 0.3s ease;
                }}
                
                .employee-name {{
                    font-weight: 500;
                    color: #2c3e50;
                }}
                
                .shift-badge {{
                    display: inline-block;
                    padding: 8px 16px;
                    border-radius: 20px;
                    font-size: 0.9em;
                    font-weight: 500;
                    text-transform: uppercase;
                }}
                
                .shift-morning {{
                    background: #ffeaa7;
                    color: #d63031;
                }}
                
                .shift-evening {{
                    background: #fd79a8;
                    color: #6c5ce7;
                }}
                
                .absence-count {{
                    background: #a29bfe;
                    color: white;
                    padding: 8px 16px;
                    border-radius: 20px;
                    font-weight: 600;
                    font-size: 1.1em;
                }}
                
                .footer {{
                    background: #2c3e50;
                    color: white;
                    padding: 30px;
                    text-align: center;
                    border-top: 1px solid #34495e;
                }}
                
                .footer .instructions {{
                    background: rgba(255,255,255,0.1);
                    padding: 20px;
                    border-radius: 10px;
                    margin-top: 20px;
                }}
                
                .footer .instructions h3 {{
                    color: #3498db;
                    margin-bottom: 15px;
                }}
                
                .footer .instructions ol {{
                    text-align: right;
                    padding-right: 20px;
                }}
                
                .footer .instructions li {{
                    margin-bottom: 8px;
                    line-height: 1.6;
                }}
                
                .footer .instructions kbd {{
                    background: #34495e;
                    padding: 4px 8px;
                    border-radius: 4px;
                    font-family: monospace;
                    font-size: 0.9em;
                }}
                
                @media print {{
                    body {{
                        background: white;
                        padding: 0;
                    }}
                    .container {{
                        box-shadow: none;
                        border-radius: 0;
                    }}
                    .summary-cards {{
                        display: none;
                    }}
                }}
            </style>
        </head>
        <body>
            <div class="container">
                <div class="header">
                    <h1>📊 گزارش شیفت کارمندان</h1>
                    <div class="subtitle">Employee Shift Management System</div>
                    <div class="date">📅 {report_data.get('date', 'تاریخ نامشخص')}</div>
                </div>
                
                <div class="summary-cards">
                    <div class="summary-card morning">
                        <div class="number">{morning_count}</div>
                        <div class="label">شیفت صبح</div>
                    </div>
                    <div class="summary-card evening">
                        <div class="number">{evening_count}</div>
                        <div class="label">شیفت عصر</div>
                    </div>
                    <div class="summary-card absences">
                        <div class="number">{total_absences}</div>
                        <div class="label">کل غیبت‌ها</div>
                    </div>
                </div>
                
                <div class="content">
                    <div class="section">
                        <h2 class="section-title">👥 جزئیات شیفت‌ها</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>نوع شیفت</th>
                                    <th>نام کارمندان</th>
                                    <th>تعداد</th>
                                </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><span class="shift-badge shift-morning">شیفت صبح</span></td>
                                    <td class="employee-name">{self._format_employee_list_persian(report_data.get('morning_shift', []))}</td>
                                    <td><span class="absence-count">{morning_count}</span></td>
                                </tr>
                                <tr>
                                    <td><span class="shift-badge shift-evening">شیفت عصر</span></td>
                                    <td class="employee-name">{self._format_employee_list_persian(report_data.get('evening_shift', []))}</td>
                                    <td><span class="absence-count">{evening_count}</span></td>
                                </tr>
                            </tbody>
                        </table>
                    </div>
        """
        
        # Add absences section if available
        absences = report_data.get('absences', {})
        if absences:
            html += f"""
                    <div class="section">
                        <h2 class="section-title">❌ گزارش غیبت‌ها</h2>
                        <table>
                            <thead>
                                <tr>
                                    <th>نوع غیبت</th>
                                    <th>تعداد</th>
                                    <th>درصد</th>
                                </tr>
                            </thead>
                            <tbody>
            """
            
            for absence_type, count in absences.items():
                percentage = (count / total_employees * 100) if total_employees > 0 else 0
                html += f"""
                                <tr>
                                    <td>{absence_type}</td>
                                    <td><span class="absence-count">{count}</span></td>
                                    <td>{percentage:.1f}%</td>
                                </tr>
                """
            
            html += """
                            </tbody>
                        </table>
                    </div>
            """
        
        html += f"""
                </div>
                
                <div class="footer">
                    <div class="instructions">
                        <h3>💡 راهنمای تبدیل به PDF</h3>
                        <ol>
                            <li>این فایل را در مرورگر خود باز کنید</li>
                            <li>کلیدهای <kbd>Ctrl + P</kbd> را فشار دهید</li>
                            <li>گزینه "Save as PDF" را انتخاب کنید</li>
                            <li>فایل PDF را در محل دلخواه ذخیره کنید</li>
                        </ol>
                        <p style="margin-top: 15px; opacity: 0.8;">
                            ✨ این روش بهترین کیفیت متن فارسی و طراحی را ارائه می‌دهد
                        </p>
                    </div>
                </div>
            </div>
        </body>
        </html>
        """
        
        return html
    
    def _format_employee_list_persian(self, employees: List[Dict]) -> str:
        """Format employee list in Persian for HTML."""
        if not employees:
            return "هیچ کارمندی"
        
        names = []
        for employee in employees:
            first_name = employee.get('first_name', '')
            last_name = employee.get('last_name', '')
            
            if first_name and last_name:
                names.append(f"{first_name} {last_name}")
            else:
                names.append(first_name)
        
        return "، ".join(names)
    
    def _export_to_pdf_pdfkit(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to PDF using PdfKit (good Persian support)."""
        try:
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.pdf"
            
            # Create HTML content with Persian text
            html_content = self._create_persian_html(report_data)
            
            # Configure PdfKit options for Persian text
            options = {
                'page-size': 'A4',
                'margin-top': '0.75in',
                'margin-right': '0.75in',
                'margin-bottom': '0.75in',
                'margin-left': '0.75in',
                'encoding': "UTF-8",
                'no-outline': None
            }
            
            # Generate PDF using PdfKit
            pdfkit.from_string(html_content, str(output_path), options=options)
            
            self.logger.info(f"PdfKit PDF export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"PdfKit PDF export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _export_to_pdf_reportlab(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to PDF using ReportLab (fallback method)."""
        try:
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.pdf"
            
            doc = SimpleDocTemplate(str(output_path), pagesize=A4)
            story = []
            
            # Try to register Persian fonts
            self._register_persian_fonts()
            
            # Get styles with Persian font support
            styles = getSampleStyleSheet()
            title_style = ParagraphStyle(
                'CustomTitle',
                parent=styles['Heading1'],
                fontSize=18,
                spaceAfter=20,
                alignment=1,  # Center alignment
                fontName='PersianFont' if 'PersianFont' in pdfmetrics.getRegisteredFontNames() else 'Helvetica'
            )
            
            # Title
            title = f"{self._create_persian_safe_text('گزارش')} {report_data.get('date', self._create_persian_safe_text('تاریخ نامشخص'))}"
            story.append(Paragraph(title, title_style))
            story.append(Spacer(1, 20))
            
            # Use Persian font if available, otherwise try built-in fonts that might handle Persian better
            available_fonts = pdfmetrics.getRegisteredFontNames()
            if 'PersianFont' in available_fonts:
                font_name = 'PersianFont'
                self.logger.info(f"Using registered Persian font: {font_name}")
            else:
                # Try to use built-in fonts that might handle Persian better
                font_name = 'Helvetica'  # Fallback to Helvetica
                self.logger.info(f"No Persian font available, using: {font_name}")
            
            self.logger.info(f"Available fonts: {available_fonts}")
            self.logger.info(f"Selected font for table: {font_name}")
            
            # Shifts table - use plain text with proper font to avoid character separation
            shifts_data = [
                [self._create_persian_safe_text('شیفت'), self._create_persian_safe_text('نام کارمندان')],
                [self._create_persian_safe_text(self.persian_texts['morning_shift']), self._format_employee_list(report_data.get('morning_shift', []))],
                [self._create_persian_safe_text(self.persian_texts['evening_shift']), self._format_employee_list(report_data.get('evening_shift', []))]
            ]
            
            shifts_table = Table(shifts_data, colWidths=[2*inch, 4*inch])
            
            shifts_table.setStyle(TableStyle([
                ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                ('FONTNAME', (0, 0), (-1, -1), font_name),
                ('FONTSIZE', (0, 0), (-1, 0), 14),
                ('BOTTOMPADDING', (0, 0), (-1, 0), 12),
                ('BACKGROUND', (0, 1), (-1, -1), colors.beige),
                ('GRID', (0, 0), (-1, -1), 1, colors.black)
            ]))
            
            story.append(shifts_table)
            story.append(Spacer(1, 20))
            
            # Absences table - use plain text with proper font to avoid character separation
            absences = report_data.get('absences', {})
            if absences:
                absences_data = [[self._create_persian_safe_text('نوع غیبت'), self._create_persian_safe_text('تعداد')]]
                for absence_type, count in absences.items():
                    absences_data.append([self._create_persian_safe_text(absence_type), str(count)])
                
                absences_table = Table(absences_data, colWidths=[3*inch, 1*inch])
                absences_table.setStyle(TableStyle([
                    ('BACKGROUND', (0, 0), (-1, 0), colors.grey),
                    ('TEXTCOLOR', (0, 0), (-1, 0), colors.whitesmoke),
                    ('ALIGN', (0, 0), (-1, -1), 'CENTER'),
                    ('FONTNAME', (0, 0), (-1, -1), font_name),
                    ('FONTSIZE', (0, 0), (-1, -1), 12),
                    ('GRID', (0, 0), (-1, -1), 1, colors.black)
                ]))
                
                story.append(absences_table)
            
            # Build PDF
            doc.build(story)
            self.logger.info(f"ReportLab PDF export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"ReportLab PDF export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _register_persian_fonts(self):
        """Register Persian fonts for PDF generation."""
        try:
            # Common Persian font paths on Windows - prioritize fonts with better Persian support
            font_paths = [
                "C:/Windows/Fonts/msyh.ttf",  # Microsoft YaHei - excellent Persian support
                "C:/Windows/Fonts/msjh.ttf",  # Microsoft JhengHei - excellent Persian support
                "C:/Windows/Fonts/arial.ttf",  # Arial - good Persian support
                "C:/Windows/Fonts/tahoma.ttf", # Tahoma - good Persian support
                "C:/Windows/Fonts/calibri.ttf", # Calibri - good Persian support
                "C:/Windows/Fonts/arial.ttc",  # Arial font collection
                "C:/Windows/Fonts/tahoma.ttc", # Tahoma font collection
                # Additional fonts that might have better Persian support
                "C:/Windows/Fonts/msmincho.ttc",  # MS Mincho
                "C:/Windows/Fonts/msgothic.ttc",  # MS Gothic
                # Try to find fonts specifically designed for Persian/Arabic
                "C:/Windows/Fonts/msuighur.ttf",  # Microsoft Uighur
                "C:/Windows/Fonts/msuighur.ttc",  # Microsoft Uighur collection
            ]
            
            # Try to find and register a Persian-compatible font
            for font_path in font_paths:
                if os.path.exists(font_path):
                    try:
                        # Register the font with ReportLab
                        pdfmetrics.registerFont(TTFont('PersianFont', font_path))
                        self.logger.info(f"Persian font registered: {font_path}")
                        
                        # Test if the font is working by checking if it can be used
                        if 'PersianFont' in pdfmetrics.getRegisteredFontNames():
                            self.logger.info(f"Font 'PersianFont' successfully registered and available")
                            
                            # Font successfully registered and available
                            self.logger.info(f"Font '{font_path}' successfully registered and available")
                            return
                        else:
                            self.logger.warning(f"Font registered but not available in getRegisteredFontNames()")
                            
                    except Exception as e:
                        self.logger.warning(f"Failed to register font {font_path}: {e}")
                        continue
            
            # Try alternative approach: use system fonts
            try:
                import platform
                if platform.system() == "Windows":
                    # Try to find fonts in user's font directory
                    user_fonts = os.path.expanduser("~/AppData/Local/Microsoft/Windows/Fonts")
                    if os.path.exists(user_fonts):
                        for font_file in os.listdir(user_fonts):
                            if font_file.lower().endswith(('.ttf', '.otf')):
                                font_path = os.path.join(user_fonts, font_file)
                                try:
                                    pdfmetrics.registerFont(TTFont('PersianFont', font_path))
                                    if 'PersianFont' in pdfmetrics.getRegisteredFontNames():
                                        self.logger.info(f"User font registered: {font_path}")
                                        return
                                except:
                                    continue
            except Exception as e:
                self.logger.warning(f"Failed to check user fonts: {e}")
            
            # If no Persian fonts found, try to use a fallback approach
            self.logger.warning("No Persian fonts found, using fallback approach")
            
        except Exception as e:
            self.logger.error(f"Error registering Persian fonts: {e}")
    
    def _create_persian_safe_text(self, text: str) -> str:
        """Create Persian-safe text for PDF generation."""
        try:
            # For now, let's try to use the fallback approach to see if it fixes the character separation
            # The issue might be that even registered fonts aren't handling Persian text shaping properly
            self.logger.info(f"Converting text to fallback to fix character separation: '{text}'")
            
            # Fallback: Convert Persian text to transliterated English
            persian_to_english = {
                # Shift-related
                'شیفت صبح': 'Morning Shift',
                'شیفت عصر': 'Evening Shift',
                'شیفت': 'Shift',
                
                # Absence types
                'مرخصی': 'Vacation',
                'بیمار': 'Sick',
                'غایب': 'Absent',
                
                # Table headers
                'نام کارمندان': 'Employee Names',
                'نوع غیبت': 'Absence Type',
                'تعداد': 'Count',
                
                # Report elements
                'گزارش': 'Report',
                'تاریخ نامشخص': 'Unknown Date',
                'هیچ کارمندی': 'No Employees',
                'نامشخص': 'Unknown',
                
                # Common Persian names (transliterated)
                'احمد': 'Ahmad',
                'محمد': 'Mohammad',
                'علی': 'Ali',
                'فاطمه': 'Fatima',
                'رضا': 'Reza',
                'حسن': 'Hassan',
                'حسین': 'Hussein',
                'زهرا': 'Zahra',
                'مهدی': 'Mahdi',
                'امیر': 'Amir',
                'سارا': 'Sara',
                'نرگس': 'Narges',
                'پریا': 'Pariya',
                'سینا': 'Sina',
                'کامران': 'Kamran',
                'شیرین': 'Shirin',
                'نوید': 'Navid',
                'آرمان': 'Arman',
                'سپیده': 'Sepideh',
                'پویا': 'Pouya'
            }
            
            # Replace Persian text with English equivalents
            for persian, english in persian_to_english.items():
                text = text.replace(persian, english)
            
            # If text still contains Persian characters, transliterate them
            if any('\u0600' <= char <= '\u06FF' for char in text):
                # Simple transliteration for remaining Persian characters
                persian_chars = {
                    'ا': 'a', 'ب': 'b', 'پ': 'p', 'ت': 't', 'ث': 'th', 'ج': 'j', 'چ': 'ch',
                    'ح': 'h', 'خ': 'kh', 'د': 'd', 'ذ': 'z', 'ر': 'r', 'ز': 'z', 'ژ': 'zh',
                    'س': 's', 'ش': 'sh', 'ص': 's', 'ض': 'z', 'ط': 't', 'ظ': 'z', 'ع': 'a',
                    'غ': 'gh', 'ف': 'f', 'ق': 'q', 'ک': 'k', 'گ': 'g', 'ل': 'l', 'م': 'm',
                    'ن': 'n', 'و': 'v', 'ه': 'h', 'ی': 'y', 'ء': "'"
                }
                
                for persian_char, latin_char in persian_chars.items():
                    text = text.replace(persian_char, latin_char)
            
            return text
            
        except Exception as e:
            self.logger.error(f"Error creating Persian-safe text: {e}")
            return text
    
    def _export_to_csv(self, report_data: Dict, output_path: Optional[str] = None) -> Tuple[bool, str]:
        """Export report data to CSV."""
        if not pd:
            return False, "کتابخانه pandas نصب نشده است"
        
        try:
            # Prepare data for CSV
            csv_data = []
            
            # Add header
            csv_data.append(['نوع', 'نام', 'نام خانوادگی', 'شناسه', 'شیفت'])
            
            # Add morning shift employees
            morning_shift = report_data.get('morning_shift', [])
            for employee in morning_shift:
                csv_data.append([
                    'شیفت صبح',
                    employee.get('first_name', ''),
                    employee.get('last_name', ''),
                    employee.get('employee_id', ''),
                    'صبح'
                ])
            
            # Add evening shift employees
            evening_shift = report_data.get('evening_shift', [])
            for employee in evening_shift:
                csv_data.append([
                    'شیفت عصر',
                    employee.get('first_name', ''),
                    employee.get('last_name', ''),
                    employee.get('employee_id', ''),
                    'عصر'
                ])
            
            # Add absences
            absences = report_data.get('absences', {})
            for absence_type, count in absences.items():
                for _ in range(count):
                    csv_data.append([absence_type, '', '', '', 'غایب'])
            
            # Create DataFrame and save
            df = pd.DataFrame(csv_data[1:], columns=csv_data[0])
            
            if not output_path:
                timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
                output_path = self.exports_dir / f"report_{timestamp}.csv"
            
            df.to_csv(output_path, index=False, encoding='utf-8-sig')
            self.logger.info(f"CSV export saved to: {output_path}")
            return True, f"{self.persian_texts['export_success']}: {output_path}"
            
        except Exception as e:
            self.logger.error(f"CSV export error: {e}")
            return False, f"{self.persian_texts['export_error']}: {str(e)}"
    
    def _format_employee_list(self, employees: List[Dict]) -> str:
        """Format employee list for display."""
        if not employees:
            return self._create_persian_safe_text("هیچ کارمندی")
        
        names = []
        for employee in employees:
            first_name = employee.get('first_name', '')
            last_name = employee.get('last_name', '')
            
            # Convert Persian names to safe text
            if first_name and last_name:
                safe_first = self._create_persian_safe_text(first_name)
                safe_last = self._create_persian_safe_text(last_name)
                names.append(f"{safe_first} {safe_last}")
            elif first_name:
                safe_first = self._create_persian_safe_text(first_name)
                names.append(safe_first)
            else:
                names.append(self._create_persian_safe_text("نامشخص"))
        
        return "، ".join(names)
    
    def get_available_formats(self) -> List[str]:
        """Get list of available export formats based on installed libraries."""
        formats = []
        
        if Image:
            formats.append('PNG')
        formats.append('HTML')  # HTML always available (Persian text support)
        if pd:
            formats.append('CSV')
        
        return formats
    
    def get_export_directory(self) -> str:
        """Get the export directory path."""
        return str(self.exports_dir)
