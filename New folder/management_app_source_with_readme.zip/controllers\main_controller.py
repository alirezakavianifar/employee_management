import os
import csv
import logging
from typing import Dict, List, Optional, Tuple
from datetime import datetime
from PyQt5.QtWidgets import QMessageBox, QFileDialog
from PyQt5.QtGui import QPixmap
from PyQt5.QtCore import QObject, pyqtSignal

from management_app.models.employee import Employee
from management_app.models.shift import Shift, ShiftManager
from management_app.models.absence import Absence, AbsenceManager
from management_app.models.task import Task, TaskManager

import json
import os
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional

from shared.json_handler import JSONHandler
from shared.sync import SyncManager

class MainController(QObject):
    """Main controller for the management application."""
    
    # Signals for UI updates
    employees_updated = pyqtSignal()
    shifts_updated = pyqtSignal()
    absences_updated = pyqtSignal()
    tasks_updated = pyqtSignal()
    settings_updated = pyqtSignal()
    sync_triggered = pyqtSignal()
    
    def __init__(self, data_dir: str = "data"):
        super().__init__()
        print(f"Debug: MainController.__init__ called with data_dir: {data_dir}")
        self.data_dir = data_dir
        self.json_handler = JSONHandler(data_dir)
        self.sync_manager = SyncManager(data_dir)
        
        # Initialize data structures
        self.employees: Dict[str, Employee] = {}
        self.shift_manager = ShiftManager()
        self.absence_manager = AbsenceManager()
        self.task_manager = TaskManager()
        self.settings = {
            "shift_capacity": 5,
            "morning_capacity": 5,
            "evening_capacity": 5,
            "shared_folder_path": data_dir,
            "managers": []
        }
        
        # Setup logging
        logging.basicConfig(
            filename=os.path.join(data_dir, "logs", "main_controller.log"),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
        
        print(f"Debug: About to call load_data")
        # Load initial data
        self.load_data()
        
        # Setup sync
        self.sync_manager.add_sync_callback(self.on_sync_triggered)
        self.sync_manager.start_sync()
    
    def load_data(self):
        """Load data from JSON files."""
        try:
            print(f"Debug: load_data called, data_dir: {self.data_dir}")
            
            # Load today's report
            report_data = self.json_handler.ensure_today_report_exists()
            print(f"Debug: Report data loaded: {list(report_data.keys()) if report_data else 'None'}")
            
            # Load settings
            if "settings" in report_data:
                self.settings.update(report_data["settings"])
                print(f"Debug: Settings loaded: {self.settings}")
                
                # Ensure shift manager capacity matches settings
                if "shift_capacity" in self.settings:
                    print(f"Debug: Setting shift manager capacity to {self.settings['shift_capacity']}")
                    self.shift_manager.set_capacity(self.settings["shift_capacity"])
                    # Also update individual shift capacities
                    self.settings["morning_capacity"] = self.settings["shift_capacity"]
                    self.settings["evening_capacity"] = self.settings["shift_capacity"]
                else:
                    print(f"Debug: No shift_capacity in settings, using default")
                    self.settings["shift_capacity"] = self.shift_manager.capacity
                    self.settings["morning_capacity"] = self.shift_manager.capacity
                    self.settings["evening_capacity"] = self.shift_manager.capacity
                

                
                print(f"Debug: Final settings after sync: {self.settings}")
                print(f"Debug: Shift manager capacity: {self.shift_manager.capacity}")
            

            
            # Load employees from both employees and managers lists
            if "employees" in report_data:
                print(f"Debug: Loading {len(report_data['employees'])} employees")
                self._load_employees_from_list(report_data["employees"])
            
            if "managers" in report_data:
                print(f"Debug: Loading {len(report_data['managers'])} managers")
                self._load_employees_from_list(report_data["managers"])
            
            print(f"Debug: Total employees loaded: {len(self.employees)}")
            
            # Load shifts
            if "shifts" in report_data:
                self._load_shifts_from_data(report_data["shifts"])
            
            # Load absences
            if "absences" in report_data:
                self._load_absences_from_data(report_data["absences"])
            
            # Load tasks
            if "tasks" in report_data:
                self._load_tasks_from_data(report_data["tasks"])
            
            logging.info("Data loaded successfully")
            
        except Exception as e:
            logging.error(f"Error loading data: {e}")
            print(f"Debug: Error loading data: {e}")
            self._show_error_dialog("خطا در بارگذاری داده‌ها", str(e))
    

    
    def _load_employees_from_list(self, employees_data: List[Dict]):
        """Load employees from a list of employee data."""
        print(f"Debug: _load_employees_from_list called with {len(employees_data)} items")
        for employee_data in employees_data:
            # Use the correct field name from Employee.to_dict()
            employee_id = employee_data.get("employee_id", employee_data.get("id", f"emp_{len(self.employees)}"))
            
            # Skip if employee already exists (prevents duplicates)
            if employee_id in self.employees:
                print(f"Debug: Skipping duplicate employee: {employee_id}")
                continue
                
            print(f"Debug: Creating employee: {employee_id} - {employee_data.get('first_name')} {employee_data.get('last_name')}")
            employee = Employee(
                employee_id=employee_id,
                first_name=employee_data.get("first_name", ""),
                last_name=employee_data.get("last_name", ""),
                role=employee_data.get("role", "Employee"),  # Default role
                photo_path=employee_data.get("photo_path", "")
            )
            
            # Set creation/update times if available
            if "created_at" in employee_data:
                employee.created_at = employee_data["created_at"]
            if "updated_at" in employee_data:
                employee.updated_at = employee_data["updated_at"]
                
            self.employees[employee.employee_id] = employee
            print(f"Debug: Employee added to dict: {employee_id}")
        
        print(f"Debug: Employees dict now has {len(self.employees)} items")
    
    def _load_shifts_from_data(self, shifts_data: Dict):
        """Load shifts from data."""
        try:
            self.shift_manager = ShiftManager.from_dict(shifts_data, self.employees)
        except Exception as e:
            logging.error(f"Error loading shifts: {e}")
    
    def _load_absences_from_data(self, absences_data: Dict):
        """Load absences from data."""
        try:
            self.absence_manager = AbsenceManager.from_dict(absences_data, self.employees)
        except Exception as e:
            logging.error(f"Error loading absences: {e}")
    
    def _load_tasks_from_data(self, tasks_data: Dict):
        """Load tasks from data."""
        try:
            self.task_manager = TaskManager.from_dict(tasks_data)
        except Exception as e:
            logging.error(f"Error loading tasks: {e}")
    
    def save_data(self):
        """Save current data to JSON files."""
        try:
            # Track that we're about to save data
            import time
            self._last_save_time = time.time()
            
            # Determine managers to display - prioritize user-selected managers
            managers_to_display = []
            
            # First, check if user has selected specific managers in settings
            if 'managers' in self.settings and self.settings['managers']:
                print(f"DEBUG: Using user-selected managers from settings: {len(self.settings['managers'])}")
                # Use user-selected managers
                for manager_data in self.settings['managers']:
                    if isinstance(manager_data, dict) and 'employee_id' in manager_data:
                        # Find the employee object to get complete data
                        employee_id = manager_data['employee_id']
                        if employee_id in self.employees:
                            managers_to_display.append(self.employees[employee_id].to_dict())
                        else:
                            # If employee not found, use the data from settings
                            managers_to_display.append(manager_data)
            else:
                print(f"DEBUG: No user-selected managers, using auto-categorized managers")
                # Fallback to auto-categorized managers based on role
                managers_to_display = [emp.to_dict() for emp in self.employees.values() 
                                     if emp.role.lower().startswith(('مدیر', 'manager'))]
            
            # Prepare report data
            report_data = {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "employees": [emp.to_dict() for emp in self.employees.values() if not emp.role.lower().startswith(('مدیر', 'manager'))],
                "managers": managers_to_display,
                "shifts": self.shift_manager.to_dict(),
                "absences": self.absence_manager.to_dict(),
                "tasks": self.task_manager.to_dict(),
                "settings": self.settings,
                "last_modified": datetime.now().isoformat()
            }
            
            print(f"DEBUG: Saving data with {len(report_data.get('employees', []))} employees and {len(report_data.get('managers', []))} managers")
            print(f"DEBUG: Managers being saved: {[m.get('first_name', '') + ' ' + m.get('last_name', '') for m in report_data.get('managers', [])]}")
            if 'shifts' in report_data:
                morning_assignments = report_data['shifts'].get('morning', {}).get('assigned_employees', [])
                evening_assignments = report_data['shifts'].get('evening', {}).get('assigned_employees', [])
                morning_count = len([emp for emp in morning_assignments if emp])
                evening_count = len([emp for emp in evening_assignments if emp])
                print(f"DEBUG: Saving shifts with {morning_count} morning assignments and {evening_count} evening assignments")
                print(f"DEBUG: Morning assignments: {morning_assignments}")
                print(f"DEBUG: Evening assignments: {evening_assignments}")
            
            # Save to file
            success = self.json_handler.write_today_report(report_data)
            if success:
                logging.info("Data saved successfully")
                return True
            else:
                logging.error("Failed to save data")
                return False
                
        except Exception as e:
            logging.error(f"Error saving data: {e}")
            self._show_error_dialog("خطا در ذخیره داده‌ها", str(e))
            return False
    
    # Employee Management Methods
    
    def add_employee(self, first_name: str, last_name: str, role: str = "", photo_path: str = "") -> bool:
        """Add a new employee."""
        try:
            # Generate unique ID
            employee_id = f"emp_{len(self.employees)}_{int(datetime.now().timestamp())}"
            
            employee = Employee(
                employee_id=employee_id,
                first_name=first_name,
                last_name=last_name,
                role=role,
                photo_path=photo_path
            )
            
            self.employees[employee_id] = employee
            self.employees_updated.emit()
            
            # Auto-save
            self.save_data()
            
            logging.info(f"Employee added: {employee.full_name}")
            return True
            
        except Exception as e:
            logging.error(f"Error adding employee: {e}")
            self._show_error_dialog("خطا در افزودن کارمند", str(e))
            return False
    
    def update_employee(self, employee_id: str, **kwargs) -> bool:
        """Update employee information."""
        try:
            if employee_id not in self.employees:
                return False
            
            employee = self.employees[employee_id]
            employee.update(**kwargs)
            
            self.employees_updated.emit()
            self.save_data()
            
            logging.info(f"Employee updated: {employee.full_name}")
            return True
            
        except Exception as e:
            logging.error(f"Error updating employee: {e}")
            self._show_error_dialog("خطا در بروزرسانی کارمند", str(e))
            return False
    
    def delete_employee(self, employee_id: str) -> bool:
        """Delete an employee."""
        try:
            if employee_id not in self.employees:
                return False
            
            employee = self.employees[employee_id]
            
            # Remove from shifts
            self.shift_manager.remove_employee_from_shift(employee, "morning")
            self.shift_manager.remove_employee_from_shift(employee, "evening")
            
            # Remove absences
            self.absence_manager.remove_employee_absences(employee)
            
            # Remove employee
            del self.employees[employee_id]
            
            self.employees_updated.emit()
            self.shifts_updated.emit()
            self.absences_updated.emit()
            self.save_data()
            
            logging.info(f"Employee deleted: {employee.full_name}")
            return True
            
        except Exception as e:
            logging.error(f"Error deleting employee: {e}")
            self._show_error_dialog("خطا در حذف کارمند", str(e))
            return False
    
    def import_employees_from_csv(self, file_path: str) -> Tuple[int, int]:
        """Import employees from CSV file."""
        try:
            imported_count = 0
            skipped_count = 0
            
            with open(file_path, 'r', encoding='utf-8') as file:
                reader = csv.DictReader(file)
                
                for row in reader:
                    first_name = row.get('first_name', '').strip()
                    last_name = row.get('last_name', '').strip()
                    role = row.get('role', '').strip()
                    
                    if first_name and last_name:
                        # Check for duplicates
                        is_duplicate = any(
                            emp.first_name == first_name and emp.last_name == last_name
                            for emp in self.employees.values()
                        )
                        
                        if not is_duplicate:
                            self.add_employee(first_name, last_name, role)
                            imported_count += 1
                        else:
                            skipped_count += 1
            
            logging.info(f"CSV import completed: {imported_count} imported, {skipped_count} skipped")
            return imported_count, skipped_count
            
        except Exception as e:
            logging.error(f"Error importing CSV: {e}")
            self._show_error_dialog("خطا در وارد کردن CSV", str(e))
            return 0, 0
    
    # Shift Management Methods
    
    def assign_employee_to_shift(self, employee: Employee, shift_type: str, slot_index: int = None) -> bool:
        """Assign employee to a shift, optionally to a specific slot."""
        try:
            print(f"DEBUG: MainController.assign_employee_to_shift called - employee: {employee.employee_id}, shift_type: {shift_type}, slot_index: {slot_index}")
            
            # Check if shift exists
            shift = self.shift_manager.get_shift(shift_type)
            if not shift:
                print(f"DEBUG: MainController.assign_employee_to_shift - shift not found: {shift_type}")
                self._show_error_dialog("خطا", "شیفت مورد نظر یافت نشد")
                return False
            
            # Check if employee is marked as absent (cannot be assigned to any shift)
            today = datetime.now().strftime("%Y-%m-%d")
            if self.absence_manager.has_absence_for_employee(employee, today):
                absence = self.absence_manager.get_absence_for_employee(employee, today)
                absence_type = absence.category if absence else "غایب"
                print(f"DEBUG: MainController.assign_employee_to_shift - employee {employee.employee_id} is marked as absent ({absence_type})")
                self._show_error_dialog(
                    "خطا در تخصیص شیفت", 
                    f"کارمند {employee.full_name} به عنوان {absence_type} ثبت شده است.\nکارمندان غایب نمی‌توانند به شیفت تخصیص داده شوند.\n\nلطفاً ابتدا غیبت کارمند را حذف کنید."
                )
                return False
            
            # Check if employee is already assigned to another shift
            current_shifts = self.shift_manager.get_employee_shifts(employee)
            print(f"DEBUG: MainController.assign_employee_to_shift - current_shifts for employee {employee.employee_id}: {current_shifts}")
            
            if current_shifts and shift_type not in current_shifts:
                shift_names = []
                for s in current_shifts:
                    if s == "morning":
                        shift_names.append("صبح")
                    elif s == "evening":
                        shift_names.append("عصر")
                    else:
                        shift_names.append(s)
                
                print(f"DEBUG: MainController.assign_employee_to_shift - employee {employee.employee_id} already assigned to shifts: {shift_names}")
                self._show_error_dialog(
                    "خطا در تخصیص شیفت", 
                    f"کارمند {employee.full_name} قبلاً به شیفت {', '.join(shift_names)} تخصیص داده شده است.\nهر کارمند فقط می‌تواند به یک شیفت تخصیص داده شود."
                )
                return False
            
            # If slot_index is provided, assign to specific slot
            if slot_index is not None:
                print(f"DEBUG: MainController.assign_employee_to_shift - assigning to specific slot {slot_index}")
                success = self.shift_manager.assign_employee_to_slot(employee, shift_type, slot_index)
            else:
                # Otherwise, assign to first available slot
                print(f"DEBUG: MainController.assign_employee_to_shift - assigning to first available slot")
                success = self.shift_manager.assign_employee(employee, shift_type)
            
            print(f"DEBUG: MainController.assign_employee_to_shift - assignment result: {success}")
            
            if success:
                self.shifts_updated.emit()
                self.save_data()
                logging.info(f"Employee {employee.full_name} assigned to {shift_type} shift slot {slot_index if slot_index is not None else 'auto'}")
                print(f"DEBUG: MainController.assign_employee_to_shift - assignment successful, signals emitted")
                return True
            else:
                print(f"DEBUG: MainController.assign_employee_to_shift - assignment failed")
                self._show_error_dialog("خطا", "نمی‌توان کارمند را به این شیفت اضافه کرد")
                return False
                
        except Exception as e:
            print(f"DEBUG: MainController.assign_employee_to_shift - exception: {e}")
            logging.error(f"Error assigning employee to shift: {e}")
            self._show_error_dialog("خطا در تخصیص شیفت", str(e))
            return False
    
    def remove_employee_from_shift(self, employee: Employee, shift_type: str) -> bool:
        """Remove employee from a shift."""
        try:
            success = self.shift_manager.remove_employee_from_shift(employee, shift_type)
            
            if success:
                self.shifts_updated.emit()
                self.save_data()
                logging.info(f"Employee {employee.full_name} removed from {shift_type} shift")
                return True
            else:
                return False
                
        except Exception as e:
            logging.error(f"Error removing employee from shift: {e}")
            self._show_error_dialog("خطا در حذف از شیفت", str(e))
            return False
    
    def clear_shift(self, shift_type: str) -> bool:
        """Clear all employees from a shift."""
        try:
            self.shift_manager.clear_shift(shift_type)
            self.shifts_updated.emit()
            self.save_data()
            
            logging.info(f"Shift {shift_type} cleared")
            return True
            
        except Exception as e:
            logging.error(f"Error clearing shift: {e}")
            self._show_error_dialog("خطا در پاک کردن شیفت", str(e))
            return False
    
    def set_shift_capacity(self, capacity: int):
        """Set shift capacity."""
        try:
            print(f"DEBUG: MainController.set_shift_capacity called with capacity: {capacity}")
            print(f"DEBUG: Previous settings capacity: {self.settings.get('shift_capacity')}")
            print(f"DEBUG: Previous shift manager capacity: {self.shift_manager.capacity}")
            
            # Update settings first
            self.settings["shift_capacity"] = capacity
            self.settings["morning_capacity"] = capacity
            self.settings["evening_capacity"] = capacity
            
            # Update shift manager
            self.shift_manager.set_capacity(capacity)
            
            print(f"DEBUG: Settings capacity: {self.settings['shift_capacity']}")
            print(f"DEBUG: Shift manager capacity: {self.shift_manager.capacity}")
            
            self.settings_updated.emit()
            logging.info(f"Shift capacity set to {capacity}")
        except Exception as e:
            logging.error(f"Error setting shift capacity: {e}")
            raise
    
    def change_shift_capacity(self, capacity: int):
        """Change shift capacity (alias for set_shift_capacity)."""
        self.set_shift_capacity(capacity)
    
    # Absence Management Methods
    
    def mark_employee_absent(self, employee: Employee, category: str, notes: str = "") -> bool:
        """Mark an employee as absent."""
        try:
            # Create absence
            absence = Absence(employee, category, notes=notes)
            
            # Add to absence manager
            success = self.absence_manager.add_absence(absence)
            
            if success:
                # Remove from shifts
                self.shift_manager.remove_employee_from_shift(employee, "morning")
                self.shift_manager.remove_employee_from_shift(employee, "evening")
                
                self.absences_updated.emit()
                self.shifts_updated.emit()
                self.save_data()
                
                logging.info(f"Employee {employee.full_name} marked as {category}")
                return True
            else:
                return False
                
        except Exception as e:
            logging.error(f"Error marking employee absent: {e}")
            self._show_error_dialog("خطا در ثبت غیبت", str(e))
            return False
    
    def remove_absence(self, employee: Employee) -> bool:
        """Remove absence for an employee."""
        try:
            # Get all absences for employee
            absences = self.absence_manager.get_absences_by_employee(employee)
            
            for absence in absences:
                self.absence_manager.remove_absence(absence)
            
            self.absences_updated.emit()
            self.save_data()
            
            logging.info(f"Absence removed for {employee.full_name}")
            return True
            
        except Exception as e:
            logging.error(f"Error removing absence: {e}")
            self._show_error_dialog("خطا در حذف غیبت", str(e))
            return False
    
    def get_all_absences(self) -> List[Absence]:
        """Get all absences from all categories."""
        try:
            all_absences = []
            for category in self.absence_manager.absences:
                all_absences.extend(self.absence_manager.absences[category])
            return all_absences
        except Exception as e:
            logging.error(f"Error getting all absences: {e}")
            return []
    
    # Settings Methods
    
    def update_settings(self, **kwargs) -> bool:
        """Update application settings."""
        try:
            for key, value in kwargs.items():
                if key in self.settings:
                    self.settings[key] = value
            
            self.settings_updated.emit()
            self.save_data()
            
            logging.info("Settings updated")
            return True
            
        except Exception as e:
            logging.error(f"Error updating settings: {e}")
            self._show_error_dialog("خطا در بروزرسانی تنظیمات", str(e))
            return False
    
    def set_shared_folder_path(self, new_path: str) -> bool:
        """Set new shared folder path."""
        try:
            if not os.path.exists(new_path):
                os.makedirs(new_path, exist_ok=True)
            
            self.settings["shared_folder_path"] = new_path
            self.data_dir = new_path
            
            # Reinitialize handlers with new path
            self.json_handler = JSONHandler(new_path)
            self.sync_manager.stop_sync()
            self.sync_manager = SyncManager(new_path)
            self.sync_manager.add_sync_callback(self.on_sync_triggered)
            self.sync_manager.start_sync()
            
            self.settings_updated.emit()
            self.save_data()
            
            logging.info(f"Shared folder path changed to: {new_path}")
            return True
            
        except Exception as e:
            logging.error(f"Error changing shared folder path: {e}")
            self._show_error_dialog("خطا در تغییر مسیر پوشه مشترک", str(e))
            return False
    
    # Sync Methods
    
    def on_sync_triggered(self):
        """Handle sync trigger from file system."""
        try:
            # Get the current file modification time to check if we need to reload
            current_file_path = self.json_handler.get_today_filepath()
            if not os.path.exists(current_file_path):
                return
            
            current_mtime = os.path.getmtime(current_file_path)
            
            # Check if this is our own save operation by comparing modification time
            # If the file was modified very recently (within 3 seconds), it's likely our own save
            import time
            time_since_modification = time.time() - current_mtime
            
            if hasattr(self, '_last_save_time') and time_since_modification < 3.0:
                # This is likely our own save operation, don't reload
                print(f"DEBUG: Skipping sync reload - this appears to be our own save operation (time_since_mod: {time_since_modification:.2f}s)")
                self.sync_triggered.emit()
                return
            
            # Additional check: if we saved recently, skip reload to prevent sync loops
            if hasattr(self, '_last_save_time') and (time.time() - self._last_save_time) < 5.0:
                print(f"DEBUG: Skipping sync reload - we saved recently ({time.time() - self._last_save_time:.2f}s ago)")
                self.sync_triggered.emit()
                return
            
            print(f"DEBUG: External file change detected, reloading data (time_since_mod: {time_since_modification:.2f}s)")
            
            # Store current data to preserve during reload
            current_count = len(self.employees)
            current_absences = None
            if hasattr(self, 'absence_manager') and self.absence_manager:
                current_absences = self.absence_manager.to_dict()
                print(f"DEBUG: Storing current absences for preservation: {current_absences}")
            
            # Store current shift assignments to restore them if needed
            current_morning_assignments = []
            current_evening_assignments = []
            
            if hasattr(self, 'shift_manager') and self.shift_manager:
                morning_shift = self.shift_manager.get_shift("morning")
                evening_shift = self.shift_manager.get_shift("evening")
                
                if morning_shift and hasattr(morning_shift, 'assigned_employees'):
                    current_morning_assignments = [emp.employee_id if emp else None for emp in morning_shift.assigned_employees]
                    print(f"DEBUG: Storing current morning assignments: {current_morning_assignments}")
                
                if evening_shift and hasattr(evening_shift, 'assigned_employees'):
                    current_evening_assignments = [emp.employee_id if emp else None for emp in evening_shift.assigned_employees]
                    print(f"DEBUG: Storing current evening assignments: {current_evening_assignments}")
            
            # Reload data (with duplicate protection now in place)
            self.load_data()
            
            # Restore shift assignments if they were lost during reload
            if current_morning_assignments or current_evening_assignments:
                print(f"DEBUG: Attempting to restore shift assignments after reload")
                
                morning_shift = self.shift_manager.get_shift("morning")
                evening_shift = self.shift_manager.get_shift("evening")
                
                # Restore morning shift assignments
                if morning_shift and current_morning_assignments:
                    restored_morning = 0
                    for i, emp_id in enumerate(current_morning_assignments):
                        if emp_id and emp_id in self.employees and i < len(morning_shift.assigned_employees):
                            if morning_shift.assigned_employees[i] is None:
                                morning_shift.assigned_employees[i] = self.employees[emp_id]
                                restored_morning += 1
                    print(f"DEBUG: Restored {restored_morning} morning shift assignments")
                
                # Restore evening shift assignments
                if evening_shift and current_evening_assignments:
                    restored_evening = 0
                    for i, emp_id in enumerate(current_evening_assignments):
                        if emp_id and emp_id in self.employees and i < len(evening_shift.assigned_employees):
                            if evening_shift.assigned_employees[i] is None:
                                evening_shift.assigned_employees[i] = self.employees[emp_id]
                                restored_evening += 1
                    print(f"DEBUG: Restored {restored_evening} evening shift assignments")
            
            # Restore absences if they were lost during reload
            if current_absences:
                # Check if absences were lost (empty or significantly reduced)
                current_absence_count = self.absence_manager.get_total_absences()
                original_absence_count = sum(len(absences) for absences in current_absences.values())
                
                if current_absence_count < original_absence_count:
                    print(f"DEBUG: Absences were lost during reload ({current_absence_count} vs {original_absence_count}), restoring...")
                    # Restore the absences using the improved from_dict method
                    self.absence_manager = AbsenceManager.from_dict(current_absences, self.employees)
                    print(f"DEBUG: Restored absences, new count: {self.absence_manager.get_total_absences()}")
            
            # Only emit signals if data actually changed
            new_count = len(self.employees)
            if new_count != current_count:
                self.employees_updated.emit()
                self.shifts_updated.emit()
                self.absences_updated.emit()
            else:
                # Even if employee count didn't change, we should update shifts display
                # in case assignments were restored
                self.shifts_updated.emit()
            
            self.sync_triggered.emit()
            logging.info("Sync completed")
        except Exception as e:
            logging.error(f"Error during sync: {e}")
            print(f"DEBUG: Error during sync: {e}")
    
    def force_sync(self):
        """Force a manual sync."""
        self.sync_manager.force_sync()
    
    # Utility Methods
    
    def _show_error_dialog(self, title: str, message: str):
        """Show error dialog with Persian text."""
        msg_box = QMessageBox()
        msg_box.setIcon(QMessageBox.Critical)
        msg_box.setWindowTitle(title)
        msg_box.setText(message)
        msg_box.exec_()
    
    def get_employee_by_id(self, employee_id: str) -> Optional[Employee]:
        """Get employee by ID."""
        return self.employees.get(employee_id)
    
    def get_all_employees(self) -> List[Employee]:
        """Get all employees."""
        print(f"Debug: get_all_employees called, returning {len(self.employees)} employees")
        for emp_id, emp in self.employees.items():
            print(f"Debug: Employee {emp_id}: {emp.first_name} {emp.last_name}")
        return list(self.employees.values())
    
    def search_employees(self, query: str) -> List[Employee]:
        """Search employees by name."""
        query = query.lower()
        results = []
        
        for employee in self.employees.values():
            if (query in employee.first_name.lower() or 
                query in employee.last_name.lower() or
                query in employee.full_name.lower()):
                results.append(employee)
        
        return results
    
    # Task Management Methods
    
    def add_task(self, title: str, description: str = "", priority: str = "متوسط",
                 estimated_hours: float = 1.0, target_date: str = None) -> str:
        """Add a new task."""
        try:
            from management_app.models.task import TaskPriority
            
            # Convert priority string to enum
            priority_enum = TaskPriority.MEDIUM
            for p in TaskPriority:
                if p.value == priority:
                    priority_enum = p
                    break
            
            task_id = self.task_manager.add_task(
                title=title,
                description=description,
                priority=priority_enum,
                estimated_hours=estimated_hours,
                target_date=target_date
            )
            
            self.tasks_updated.emit()
            self.save_data()
            logging.info(f"Task added: {title}")
            return task_id
            
        except Exception as e:
            logging.error(f"Error adding task: {e}")
            self._show_error_dialog("خطا در افزودن وظیفه", str(e))
            return ""
    
    def update_task(self, task_id: str, **kwargs) -> bool:
        """Update task properties."""
        try:
            if self.task_manager.update_task(task_id, **kwargs):
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Task updated: {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error updating task: {e}")
            self._show_error_dialog("خطا در بروزرسانی وظیفه", str(e))
            return False
    
    def delete_task(self, task_id: str) -> bool:
        """Delete a task."""
        try:
            if self.task_manager.delete_task(task_id):
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Task deleted: {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error deleting task: {e}")
            self._show_error_dialog("خطا در حذف وظیفه", str(e))
            return False
    
    def start_task(self, task_id: str) -> bool:
        """Start a task."""
        try:
            task = self.task_manager.get_task(task_id)
            if task and task.start_task():
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Task started: {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error starting task: {e}")
            self._show_error_dialog("خطا در شروع وظیفه", str(e))
            return False
    
    def complete_task(self, task_id: str, actual_hours: float = None, notes: str = "") -> bool:
        """Complete a task."""
        try:
            task = self.task_manager.get_task(task_id)
            if task and task.complete_task(actual_hours, notes):
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Task completed: {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error completing task: {e}")
            self._show_error_dialog("خطا در تکمیل وظیفه", str(e))
            return False
    
    def get_task(self, task_id: str) -> Optional[Task]:
        """Get a task by ID."""
        return self.task_manager.get_task(task_id)
    
    def get_all_tasks(self) -> List[Task]:
        """Get all tasks."""
        return list(self.task_manager.tasks.values())
    
    def get_tasks_by_status(self, status: str) -> List[Task]:
        """Get tasks by status."""
        try:
            from management_app.models.task import TaskStatus
            
            # Convert status string to enum
            status_enum = TaskStatus.PENDING
            for s in TaskStatus:
                if s.value == status:
                    status_enum = s
                    break
            
            return self.task_manager.get_tasks_by_status(status_enum)
            
        except Exception as e:
            logging.error(f"Error getting tasks by status: {e}")
            return []
    
    def get_tasks_by_week(self, week_number: int) -> List[Task]:
        """Get tasks for a specific week."""
        return self.task_manager.get_tasks_by_week(week_number)
    
    def get_tasks_by_date(self, target_date: str) -> List[Task]:
        """Get tasks for a specific date."""
        return self.task_manager.get_tasks_by_date(target_date)
    
    def get_in_progress_tasks(self) -> List[Task]:
        """Get all tasks currently in progress."""
        return self.task_manager.get_in_progress_tasks()
    
    def get_completed_tasks(self, date: str = None) -> List[Task]:
        """Get all completed tasks, optionally for a specific date."""
        return self.task_manager.get_completed_tasks(date)
    
    def get_pending_tasks(self) -> List[Task]:
        """Get all pending tasks."""
        return self.task_manager.get_pending_tasks()
    
    def get_task_progress(self) -> Dict[str, Any]:
        """Get overall task progress statistics."""
        return self.task_manager.get_task_progress()
    
    def assign_employee_to_task(self, task_id: str, employee_id: str) -> bool:
        """Assign an employee to a task."""
        try:
            task = self.task_manager.get_task(task_id)
            if task and task.assign_employee(employee_id):
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Employee {employee_id} assigned to task {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error assigning employee to task: {e}")
            self._show_error_dialog("خطا در تخصیص کارمند به وظیفه", str(e))
            return False
    
    def remove_employee_from_task(self, task_id: str, employee_id: str) -> bool:
        """Remove an employee from a task."""
        try:
            task = self.task_manager.get_task(task_id)
            if task and task.remove_employee(employee_id):
                self.tasks_updated.emit()
                self.save_data()
                logging.info(f"Employee {employee_id} removed from task {task_id}")
                return True
            return False
            
        except Exception as e:
            logging.error(f"Error removing employee from task: {e}")
            self._show_error_dialog("خطا در حذف کارمند از وظیفه", str(e))
            return False
    
    def cleanup(self):
        """Cleanup resources."""
        try:
            self.sync_manager.stop_sync()
            logging.info("Controller cleanup completed")
        except Exception as e:
            logging.error(f"Error during cleanup: {e}")
