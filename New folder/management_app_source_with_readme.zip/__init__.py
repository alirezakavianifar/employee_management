"""
Management Application Package

This package contains the management application for employee shift management.
"""

__version__ = "1.0.0"
__author__ = "Management System"
