from typing import List, Dict, Any, Optional
from datetime import datetime
from .employee import Employee

class Shift:
    """Shift model class for managing shift assignments."""
    
    def __init__(self, shift_type: str, capacity: int = 5):
        print(f"DEBUG: Shift.__init__ called - shift_type: '{shift_type}', capacity: {capacity}")
        self.shift_type = shift_type  # "morning" or "evening"
        self.capacity = capacity
        self.assigned_employees: List[Optional[Employee]] = [None] * capacity  # Slot-based assignments
        self.created_at = datetime.now().isoformat()
        self.updated_at = datetime.now().isoformat()
        print(f"DEBUG: Shift.__init__ completed - shift: {self}")
    
    @property
    def is_full(self) -> bool:
        """Check if shift is at full capacity."""
        return all(emp is not None for emp in self.assigned_employees)
    
    @property
    def available_slots(self) -> int:
        """Get number of available slots."""
        return sum(1 for emp in self.assigned_employees if emp is None)
    
    @property
    def display_name(self) -> str:
        """Get display name for the shift."""
        if self.shift_type == "morning":
            return "صبح"
        elif self.shift_type == "evening":
            return "عصر"
        return self.shift_type
    
    def assign_employee_to_slot(self, employee: Employee, slot_index: int) -> bool:
        """
        Assign employee to a specific slot.
        
        Args:
            employee: Employee to assign
            slot_index: Slot index (0 to capacity-1)
            
        Returns:
            True if employee was assigned, False if slot is invalid or occupied
        """
        print(f"DEBUG: Shift.assign_employee_to_slot called - shift: '{self.shift_type}', employee: '{employee.employee_id}', slot_index: {slot_index}")
        
        if slot_index < 0 or slot_index >= self.capacity:
            print(f"DEBUG: Shift.assign_employee_to_slot - invalid slot_index: {slot_index}")
            return False
        
        if self.assigned_employees[slot_index] is not None:
            print(f"DEBUG: Shift.assign_employee_to_slot - slot {slot_index} already occupied by: {self.assigned_employees[slot_index]}")
            return False
        
        # Remove employee from other slots first
        self.remove_employee(employee)
        
        # Assign to the specific slot
        self.assigned_employees[slot_index] = employee
        self.updated_at = datetime.now().isoformat()
        print(f"DEBUG: Shift.assign_employee_to_slot - successfully assigned employee '{employee.employee_id}' to slot {slot_index}")
        return True
    
    def get_employee_at_slot(self, slot_index: int) -> Optional[Employee]:
        """Get employee at a specific slot."""
        if 0 <= slot_index < self.capacity:
            return self.assigned_employees[slot_index]
        return None
    
    def clear_slot(self, slot_index: int) -> bool:
        """Clear a specific slot."""
        if 0 <= slot_index < self.capacity:
            if self.assigned_employees[slot_index] is not None:
                self.assigned_employees[slot_index] = None
                self.updated_at = datetime.now().isoformat()
                return True
        return False
    
    def add_employee(self, employee: Employee) -> bool:
        """
        Add employee to first available slot if capacity allows.
        
        Returns:
            True if employee was added, False if shift is full
        """
        if self.is_full:
            return False
        
        # Find first available slot
        for i, emp in enumerate(self.assigned_employees):
            if emp is None:
                return self.assign_employee_to_slot(employee, i)
        
        return False
    
    def remove_employee(self, employee: Employee) -> bool:
        """Remove employee from shift (from any slot)."""
        for i, emp in enumerate(self.assigned_employees):
            if emp == employee:
                self.assigned_employees[i] = None
                self.updated_at = datetime.now().isoformat()
                return True
        return False
    
    def clear_shift(self):
        """Clear all employees from shift."""
        self.assigned_employees = [None] * self.capacity
        self.updated_at = datetime.now().isoformat()
    
    def get_employee_by_id(self, employee_id: str) -> Optional[Employee]:
        """Get employee by ID from this shift."""
        for employee in self.assigned_employees:
            if employee and employee.employee_id == employee_id:
                return employee
        return None
    
    def is_employee_assigned(self, employee: Employee) -> bool:
        """Check if employee is assigned to this shift."""
        return employee in self.assigned_employees
    
    def set_capacity(self, new_capacity: int):
        """Set new capacity for the shift."""
        if new_capacity < 0:
            new_capacity = 0
        
        print(f"DEBUG: Shift.set_capacity called - current: {self.capacity}, new: {new_capacity}")
        
        # Resize the assigned_employees list
        if new_capacity > self.capacity:
            # Expand: add None slots
            self.assigned_employees.extend([None] * (new_capacity - self.capacity))
            print(f"DEBUG: Expanded capacity from {self.capacity} to {new_capacity}")
        else:
            # Shrink: remove excess employees and slots
            # Check if we're about to lose any assigned employees
            lost_employees = [emp for emp in self.assigned_employees[new_capacity:] if emp is not None]
            if lost_employees:
                print(f"DEBUG: Warning: Reducing capacity from {self.capacity} to {new_capacity} will remove {len(lost_employees)} assigned employees")
                for emp in lost_employees:
                    print(f"DEBUG: Employee {emp.employee_id} will be removed from slot")
            
            self.assigned_employees = self.assigned_employees[:new_capacity]
            print(f"DEBUG: Reduced capacity from {self.capacity} to {new_capacity}")
        
        self.capacity = new_capacity
        self.updated_at = datetime.now().isoformat()
        print(f"DEBUG: Shift capacity updated to {self.capacity}")
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert shift to dictionary for JSON serialization."""
        result = {
            "shift_type": self.shift_type,
            "capacity": self.capacity,
            "assigned_employees": [emp.employee_id if emp else None for emp in self.assigned_employees],
            "created_at": self.created_at,
            "updated_at": self.updated_at
        }
        print(f"DEBUG: Shift.to_dict called - shift: '{self.shift_type}', result: {result}")
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], employees_dict: Dict[str, Employee]) -> 'Shift':
        """Create shift from dictionary."""
        print(f"DEBUG: Shift.from_dict called - data: {data}")
        print(f"DEBUG: Shift.from_dict - employees_dict has {len(employees_dict)} employees: {list(employees_dict.keys())}")
        shift = cls(
            shift_type=data.get("shift_type", ""),
            capacity=data.get("capacity", 5)
        )
        
        # Restore employee assignments
        employee_ids = data.get("assigned_employees", [])
        print(f"DEBUG: Shift.from_dict - restoring employee assignments: {employee_ids}")
        print(f"DEBUG: Shift.from_dict - shift capacity: {shift.capacity}, assignments list length: {len(employee_ids)}")
        
        # Ensure we don't exceed capacity
        max_assignments = min(len(employee_ids), shift.capacity)
        successful_assignments = 0
        
        for i in range(max_assignments):
            emp_id = employee_ids[i] if i < len(employee_ids) else None
            if emp_id is not None and emp_id in employees_dict:
                shift.assigned_employees[i] = employees_dict[emp_id]
                successful_assignments += 1
                print(f"DEBUG: Shift.from_dict - assigned employee '{emp_id}' to slot {i}")
            elif emp_id is not None:
                print(f"DEBUG: Shift.from_dict - employee '{emp_id}' not found in employees_dict")
        
        print(f"DEBUG: Shift.from_dict - successfully restored {successful_assignments} assignments out of {len([x for x in employee_ids if x is not None])} requested")
        
        shift.created_at = data.get("created_at", datetime.now().isoformat())
        shift.updated_at = data.get("updated_at", datetime.now().isoformat())
        print(f"DEBUG: Shift.from_dict completed - shift: {shift}")
        return shift
    
    def __str__(self) -> str:
        return f"Shift({self.display_name}: {sum(1 for emp in self.assigned_employees if emp is not None)}/{self.capacity})"
    
    def __repr__(self) -> str:
        return self.__str__()

class ShiftManager:
    """Manager class for handling multiple shifts."""
    
    def __init__(self, capacity: int = 5):
        print(f"DEBUG: ShiftManager.__init__ called - capacity: {capacity}")
        self.morning_shift = Shift("morning", capacity)
        self.evening_shift = Shift("evening", capacity)
        self.capacity = capacity
        print(f"DEBUG: ShiftManager.__init__ completed")
    
    def set_capacity(self, new_capacity: int):
        """Set capacity for all shifts."""
        print(f"DEBUG: ShiftManager.set_capacity called - current: {self.capacity}, new: {new_capacity}")
        self.capacity = new_capacity
        self.morning_shift.set_capacity(new_capacity)
        self.evening_shift.set_capacity(new_capacity)
        print(f"DEBUG: ShiftManager capacity updated to {self.capacity}")
    
    def get_shift(self, shift_type: str) -> Optional[Shift]:
        """Get shift by type."""
        if shift_type == "morning":
            return self.morning_shift
        elif shift_type == "evening":
            return self.evening_shift
        return None
    
    def assign_employee(self, employee: Employee, shift_type: str) -> bool:
        """Assign employee to specific shift."""
        # Check if employee is already assigned to another shift
        current_shifts = self.get_employee_shifts(employee)
        if current_shifts and shift_type not in current_shifts:
            print(f"DEBUG: Employee {employee.employee_id} is already assigned to shifts: {current_shifts}")
            return False
        
        shift = self.get_shift(shift_type)
        if shift:
            return shift.add_employee(employee)
        return False
    
    def assign_employee_to_slot(self, employee: Employee, shift_type: str, slot_index: int) -> bool:
        """Assign employee to specific shift and slot."""
        # Check if employee is already assigned to another shift
        current_shifts = self.get_employee_shifts(employee)
        if current_shifts and shift_type not in current_shifts:
            print(f"DEBUG: Employee {employee.employee_id} is already assigned to shifts: {current_shifts}")
            return False
        
        shift = self.get_shift(shift_type)
        if shift:
            return shift.assign_employee_to_slot(employee, slot_index)
        return False
    
    def remove_employee_from_shift(self, employee: Employee, shift_type: str) -> bool:
        """Remove employee from specific shift."""
        shift = self.get_shift(shift_type)
        if shift:
            return shift.remove_employee(employee)
        return False
    
    def get_employee_shifts(self, employee: Employee) -> List[str]:
        """Get all shifts an employee is assigned to."""
        shifts = []
        if self.morning_shift.is_employee_assigned(employee):
            shifts.append("morning")
        if self.evening_shift.is_employee_assigned(employee):
            shifts.append("evening")
        return shifts
    
    def clear_shift(self, shift_type: str):
        """Clear specific shift."""
        shift = self.get_shift(shift_type)
        if shift:
            shift.clear_shift()
    
    def to_dict(self) -> Dict[str, Any]:
        """Convert shift manager to dictionary."""
        result = {
            "morning": self.morning_shift.to_dict(),
            "evening": self.evening_shift.to_dict(),
            "capacity": self.capacity
        }
        print(f"DEBUG: ShiftManager.to_dict called - result: {result}")
        return result
    
    @classmethod
    def from_dict(cls, data: Dict[str, Any], employees_dict: Dict[str, Employee]) -> 'ShiftManager':
        """Create shift manager from dictionary."""
        print(f"DEBUG: ShiftManager.from_dict called - data: {data}, employees_dict keys: {list(employees_dict.keys())}")
        capacity = data.get("capacity", 5)
        manager = cls(capacity)
        
        # Restore shifts
        if "morning" in data:
            print("DEBUG: ShiftManager.from_dict - restoring morning shift")
            manager.morning_shift = Shift.from_dict(data["morning"], employees_dict)
        if "evening" in data:
            print("DEBUG: ShiftManager.from_dict - restoring evening shift")
            manager.evening_shift = Shift.from_dict(data["evening"], employees_dict)
        
        print(f"DEBUG: ShiftManager.from_dict completed - manager: {manager}")
        return manager
