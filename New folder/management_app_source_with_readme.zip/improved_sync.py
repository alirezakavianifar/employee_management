
import os
import time
import threading
from typing import Callable, Optional
import logging
from datetime import datetime

class ImprovedSyncManager:
    """Improved sync manager that uses polling instead of file monitoring."""
    
    def __init__(self, data_dir: str, sync_interval: int = 5):
        self.data_dir = data_dir
        self.sync_interval = sync_interval
        self.is_running = False
        self.callbacks = []
        self.sync_thread = None
        self.last_modified = {}
        
        # Setup logging
        log_dir = os.path.join(data_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            filename=os.path.join(log_dir, "improved_sync.log"),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
    
    def add_sync_callback(self, callback: Callable[[], None]):
        """Add a callback to be executed when sync is needed."""
        self.callbacks.append(callback)
        logging.info(f"Added sync callback. Total callbacks: {len(self.callbacks)}")
    
    def remove_sync_callback(self, callback: Callable[[], None]):
        """Remove a sync callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
            logging.info(f"Removed sync callback. Total callbacks: {len(self.callbacks)}")
    
    def _check_file_changes(self):
        """Check for file changes using polling."""
        try:
            reports_dir = os.path.join(self.data_dir, "reports")
            if not os.path.exists(reports_dir):
                return False
            
            # Check all JSON files in reports directory
            for filename in os.listdir(reports_dir):
                if filename.endswith('.json') and not filename.startswith('.'):
                    filepath = os.path.join(reports_dir, filename)
                    
                    if os.path.isfile(filepath):
                        current_mtime = os.path.getmtime(filepath)
                        
                        # Check if file was modified
                        if filename not in self.last_modified:
                            self.last_modified[filename] = current_mtime
                        elif current_mtime > self.last_modified[filename]:
                            self.last_modified[filename] = current_mtime
                            logging.info(f"File change detected: {filename}")
                            return True
            
            return False
            
        except Exception as e:
            logging.error(f"Error checking file changes: {e}")
            return False
    
    def _sync_worker(self):
        """Background worker for periodic sync."""
        logging.info("Sync worker started")
        
        while self.is_running:
            try:
                # Check for file changes
                if self._check_file_changes():
                    logging.info("File changes detected, triggering callbacks")
                    self._trigger_callbacks()
                
                # Sleep for sync interval
                time.sleep(self.sync_interval)
                
            except Exception as e:
                logging.error(f"Error in sync worker: {e}")
                time.sleep(5)  # Wait before retrying
        
        logging.info("Sync worker stopped")
    
    def _trigger_callbacks(self):
        """Trigger all registered callbacks."""
        try:
            logging.info(f"Triggering {len(self.callbacks)} callbacks")
            
            for i, callback in enumerate(self.callbacks):
                try:
                    callback()
                    logging.info(f"Callback {i+1} executed successfully")
                except Exception as e:
                    logging.error(f"Error in callback {i+1}: {e}")
                    
        except Exception as e:
            logging.error(f"Error triggering callbacks: {e}")
    
    def start_sync(self):
        """Start synchronization."""
        if self.is_running:
            logging.warning("Sync already running")
            return
        
        try:
            self.is_running = True
            self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
            self.sync_thread.start()
            
            logging.info(f"Started improved sync with {self.sync_interval}s interval")
            print(f"✅ Improved sync started with {self.sync_interval}s interval")
            
        except Exception as e:
            logging.error(f"Failed to start sync: {e}")
            print(f"❌ Failed to start sync: {e}")
    
    def stop_sync(self):
        """Stop synchronization."""
        if not self.is_running:
            return
        
        try:
            self.is_running = False
            
            if self.sync_thread:
                self.sync_thread.join(timeout=5.0)
            
            logging.info("Stopped improved sync")
            print("✅ Improved sync stopped")
            
        except Exception as e:
            logging.error(f"Failed to stop sync: {e}")
            print(f"❌ Failed to stop sync: {e}")
    
    def force_sync(self):
        """Force an immediate sync."""
        logging.info("Forcing immediate sync")
        self._trigger_callbacks()
