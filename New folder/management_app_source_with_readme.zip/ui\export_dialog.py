"""
Export dialog for selecting export format and options.
"""

from PyQt5.QtWidgets import (QDialog, QVBoxLayout, QHBoxLayout, QLabel, 
                             QComboBox, QPushButton, QProgressBar, QTextEdit,
                             QGroupBox, QCheckBox, QFileDialog, QMessageBox)
from PyQt5.QtCore import Qt, QThread, pyqtSignal
from PyQt5.QtGui import QFont
import os


class ExportWorker(QThread):
    """Worker thread for export operations."""
    
    export_progress = pyqtSignal(str)
    export_finished = pyqtSignal(bool, str)
    
    def __init__(self, export_service, report_data, export_format, output_path=None):
        super().__init__()
        self.export_service = export_service
        self.report_data = report_data
        self.export_format = export_format
        self.output_path = output_path
    
    def run(self):
        """Run the export operation."""
        try:
            self.export_progress.emit("در حال آماده‌سازی داده‌ها...")
            
            success, message = self.export_service.export_report(
                self.report_data, 
                self.export_format, 
                self.output_path
            )
            
            self.export_finished.emit(success, message)
            
        except Exception as e:
            self.export_finished.emit(False, f"خطای غیرمنتظره: {str(e)}")


class ExportDialog(QDialog):
    """Dialog for selecting export options."""
    
    def __init__(self, export_service, report_data, parent=None):
        super().__init__(parent)
        self.export_service = export_service
        self.report_data = report_data
        self.export_worker = None
        
        self.setup_ui()
        self.setup_connections()
    
    def setup_ui(self):
        """Setup the user interface."""
        self.setWindowTitle("خروجی گزارش")
        self.setFixedSize(500, 400)
        self.setWindowFlags(Qt.Dialog | Qt.WindowTitleHint | Qt.CustomizeWindowHint)
        
        # Main layout
        main_layout = QVBoxLayout()
        
        # Title
        title_label = QLabel("انتخاب فرمت خروجی")
        title_label.setFont(QFont("Tahoma", 14, QFont.Bold))
        title_label.setAlignment(Qt.AlignCenter)
        title_label.setStyleSheet("color: #2c3e50; margin: 10px;")
        main_layout.addWidget(title_label)
        
        # Export format selection
        format_group = QGroupBox("فرمت خروجی")
        format_layout = QVBoxLayout()
        
        self.format_combo = QComboBox()
        available_formats = self.export_service.get_available_formats()
        self.format_combo.addItems(available_formats)
        self.format_combo.setCurrentText(available_formats[0] if available_formats else "CSV")
        
        format_layout.addWidget(QLabel("فرمت:"))
        format_layout.addWidget(self.format_combo)
        format_group.setLayout(format_layout)
        main_layout.addWidget(format_group)
        
        # Export options
        options_group = QGroupBox("گزینه‌های خروجی")
        options_layout = QVBoxLayout()
        
        self.custom_path_checkbox = QCheckBox("انتخاب مسیر ذخیره")
        self.custom_path_checkbox.stateChanged.connect(self.on_custom_path_changed)
        
        self.custom_path_label = QLabel("مسیر پیش‌فرض: " + self.export_service.get_export_directory())
        self.custom_path_label.setWordWrap(True)
        self.custom_path_label.setStyleSheet("color: #7f8c8d; font-size: 10px;")
        
        self.browse_button = QPushButton("انتخاب مسیر...")
        self.browse_button.clicked.connect(self.browse_output_path)
        self.browse_button.setEnabled(False)
        
        options_layout.addWidget(self.custom_path_checkbox)
        options_layout.addWidget(self.custom_path_label)
        options_layout.addWidget(self.browse_button)
        options_group.setLayout(options_layout)
        main_layout.addWidget(options_group)
        
        # Progress section
        progress_group = QGroupBox("پیشرفت")
        progress_layout = QVBoxLayout()
        
        self.progress_bar = QProgressBar()
        self.progress_bar.setVisible(False)
        
        self.status_text = QTextEdit()
        self.status_text.setMaximumHeight(80)
        self.status_text.setPlaceholderText("وضعیت خروجی...")
        self.status_text.setReadOnly(True)
        
        progress_layout.addWidget(self.progress_bar)
        progress_layout.addWidget(self.status_text)
        progress_group.setLayout(progress_layout)
        main_layout.addWidget(progress_group)
        
        # Buttons
        button_layout = QHBoxLayout()
        
        self.export_button = QPushButton("خروجی")
        self.export_button.setStyleSheet("""
            QPushButton {
                background-color: #27ae60;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #2ecc71;
            }
            QPushButton:disabled {
                background-color: #bdc3c7;
            }
        """)
        
        self.cancel_button = QPushButton("انصراف")
        self.cancel_button.setStyleSheet("""
            QPushButton {
                background-color: #e74c3c;
                color: white;
                border: none;
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
            QPushButton:hover {
                background-color: #c0392b;
            }
        """)
        
        button_layout.addWidget(self.export_button)
        button_layout.addWidget(self.cancel_button)
        
        main_layout.addLayout(button_layout)
        
        self.setLayout(main_layout)
        
        # Apply Persian styling
        self.setStyleSheet("""
            QDialog {
                background-color: #ecf0f1;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QGroupBox {
                font-weight: bold;
                border: 2px solid #bdc3c7;
                border-radius: 5px;
                margin-top: 10px;
                padding-top: 10px;
            }
            QGroupBox::title {
                subcontrol-origin: margin;
                left: 10px;
                padding: 0 5px 0 5px;
            }
            QComboBox {
                padding: 5px;
                border: 1px solid #bdc3c7;
                border-radius: 3px;
                background-color: white;
            }
            QPushButton {
                padding: 8px 16px;
                border-radius: 4px;
                font-weight: bold;
            }
        """)
    
    def setup_connections(self):
        """Setup signal connections."""
        self.export_button.clicked.connect(self.start_export)
        self.cancel_button.clicked.connect(self.reject)
    
    def on_custom_path_changed(self, state):
        """Handle custom path checkbox state change."""
        self.browse_button.setEnabled(state == Qt.Checked)
    
    def browse_output_path(self):
        """Browse for custom output path."""
        current_format = self.format_combo.currentText().lower()
        file_filter = f"{current_format.upper()} Files (*.{current_format})"
        
        file_path, _ = QFileDialog.getSaveFileName(
            self,
            "انتخاب مسیر ذخیره",
            os.path.expanduser("~"),
            file_filter
        )
        
        if file_path:
            self.custom_path_label.setText(f"مسیر انتخاب شده: {file_path}")
            self.custom_path_label.setStyleSheet("color: #27ae60; font-size: 10px;")
    
    def start_export(self):
        """Start the export process."""
        if not self.report_data:
            QMessageBox.warning(self, "خطا", "داده‌ای برای خروجی موجود نیست")
            return
        
        # Get export format
        export_format = self.format_combo.currentText()
        
        # Get output path
        output_path = None
        if self.custom_path_checkbox.isChecked():
            # Get the custom path from the label
            custom_path_text = self.custom_path_label.text()
            if custom_path_text.startswith("مسیر انتخاب شده:"):
                output_path = custom_path_text.replace("مسیر انتخاب شده: ", "")
            else:
                QMessageBox.warning(self, "خطا", "لطفاً مسیر ذخیره را انتخاب کنید")
                return
        
        # Disable UI during export
        self.export_button.setEnabled(False)
        self.cancel_button.setEnabled(False)
        self.format_combo.setEnabled(False)
        self.custom_path_checkbox.setEnabled(False)
        self.browse_button.setEnabled(False)
        
        # Show progress
        self.progress_bar.setVisible(True)
        self.progress_bar.setRange(0, 0)  # Indeterminate progress
        
        # Start export worker
        self.export_worker = ExportWorker(
            self.export_service, 
            self.report_data, 
            export_format, 
            output_path
        )
        self.export_worker.export_progress.connect(self.update_progress)
        self.export_worker.export_finished.connect(self.export_finished)
        self.export_worker.start()
    
    def update_progress(self, message):
        """Update progress status."""
        self.status_text.append(message)
        self.status_text.ensureCursorVisible()
    
    def export_finished(self, success, message):
        """Handle export completion."""
        # Re-enable UI
        self.export_button.setEnabled(True)
        self.cancel_button.setEnabled(True)
        self.format_combo.setEnabled(True)
        self.custom_path_checkbox.setEnabled(True)
        self.browse_button.setEnabled(self.custom_path_checkbox.isChecked())
        
        # Hide progress
        self.progress_bar.setVisible(False)
        
        # Show result
        if success:
            self.status_text.append(f"✅ {message}")
            QMessageBox.information(self, "موفقیت", message)
        else:
            self.status_text.append(f"❌ {message}")
            QMessageBox.critical(self, "خطا", message)
        
        # Clean up worker
        if self.export_worker:
            self.export_worker.deleteLater()
            self.export_worker = None
