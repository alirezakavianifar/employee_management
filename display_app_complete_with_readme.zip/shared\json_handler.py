import json
import os
import shutil
from datetime import datetime
from typing import Dict, Any, Optional, List
import logging

class JSONHandler:
    """Handles JSON file operations with backup and conflict resolution."""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = data_dir
        print(f"Debug: JSONHandler.__init__ called with data_dir: {data_dir}")
        self.reports_dir = os.path.join(data_dir, "reports")
        self.images_dir = os.path.join(data_dir, "images", "staff")
        self.logs_dir = os.path.join(data_dir, "logs")
        
        print(f"Debug: reports_dir: {self.reports_dir}")
        print(f"Debug: images_dir: {self.images_dir}")
        print(f"Debug: logs_dir: {self.logs_dir}")
        
        # Ensure directories exist
        os.makedirs(self.reports_dir, exist_ok=True)
        os.makedirs(self.images_dir, exist_ok=True)
        os.makedirs(self.logs_dir, exist_ok=True)
        
        print(f"Debug: Directories created/verified")
        
        # Setup logging
        logging.basicConfig(
            filename=os.path.join(self.logs_dir, "json_handler.log"),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
    
    def get_today_filename(self) -> str:
        """Get today's report filename."""
        today = datetime.now().strftime("%Y-%m-%d")
        return f"report_{today}.json"
    
    def get_today_filepath(self) -> str:
        """Get today's report filepath."""
        filepath = os.path.join(self.reports_dir, self.get_today_filename())
        print(f"Debug: get_today_filepath called, reports_dir: {self.reports_dir}, filename: {self.get_today_filename()}, full path: {filepath}")
        return filepath
    
    def create_backup(self, filepath: str) -> str:
        """Create a backup of the file with timestamp."""
        if not os.path.exists(filepath):
            return ""
        
        timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
        backup_filename = f"{os.path.splitext(os.path.basename(filepath))[0]}_backup_{timestamp}.json"
        backup_path = os.path.join(self.reports_dir, backup_filename)
        
        try:
            shutil.copy2(filepath, backup_path)
            logging.info(f"Backup created: {backup_path}")
            return backup_path
        except Exception as e:
            logging.error(f"Failed to create backup: {e}")
            return ""
    
    def read_json(self, filepath: str) -> Optional[Dict[str, Any]]:
        """Read JSON file with error handling."""
        try:
            print(f"Debug: read_json called for filepath: {filepath}")
            if not os.path.exists(filepath):
                print(f"Debug: File does not exist: {filepath}")
                return None
            
            with open(filepath, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"Debug: Successfully read JSON file, data keys: {list(data.keys()) if data else 'None'}")
                logging.info(f"Successfully read: {filepath}")
                return data
        except json.JSONDecodeError as e:
            print(f"Debug: JSON decode error: {e}")
            logging.error(f"JSON decode error in {filepath}: {e}")
            return None
        except Exception as e:
            print(f"Debug: Error reading file: {e}")
            logging.error(f"Error reading {filepath}: {e}")
            return None
    
    def write_json(self, filepath: str, data: Dict[str, Any]) -> bool:
        """Write JSON file with backup creation."""
        try:
            # Create backup if file exists
            if os.path.exists(filepath):
                self.create_backup(filepath)
            
            # Write new data
            with open(filepath, 'w', encoding='utf-8') as f:
                json.dump(data, f, ensure_ascii=False, indent=2)
            
            logging.info(f"Successfully wrote: {filepath}")
            return True
        except Exception as e:
            logging.error(f"Error writing {filepath}: {e}")
            return False
    
    def read_today_report(self) -> Optional[Dict[str, Any]]:
        """Read today's report file."""
        return self.read_json(self.get_today_filepath())
    
    def write_today_report(self, data: Dict[str, Any]) -> bool:
        """Write today's report file."""
        return self.write_json(self.get_today_filepath(), data)
    
    def get_default_report_structure(self) -> Dict[str, Any]:
        """Get default report structure with sample employee data."""
        try:
            # Try to load sample employees from CSV
            sample_employees = self._load_sample_employees()
            
            # Separate employees and managers
            employees = []
            managers = []
            
            for emp in sample_employees:
                if emp.get('role', '').lower().startswith(('مدیر', 'manager')):
                    managers.append(emp)
                else:
                    employees.append(emp)
            
            print(f"Debug: Loaded {len(employees)} employees and {len(managers)} managers from sample data")
            
            return {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "employees": employees,
                "managers": managers,
                "shifts": {
                    "morning": {
                        "shift_type": "morning",
                        "capacity": 5,
                        "assigned_employees": []
                    },
                    "evening": {
                        "shift_type": "evening",
                        "capacity": 5,
                        "assigned_employees": []
                    }
                },
                "absences": {
                    "مرخصی": [],
                    "بیمار": [],
                    "غایب": []
                },
                "tasks": {
                    "tasks": {},
                    "next_task_id": 1
                },
                "settings": {
                    "shift_capacity": 5,
                    "morning_capacity": 5,
                    "evening_capacity": 5,
                    "shared_folder_path": self.data_dir
                },
                "last_modified": datetime.now().isoformat()
            }
        except Exception as e:
            print(f"Debug: Error loading sample data: {e}")
            # Fallback to empty structure
            return {
                "date": datetime.now().strftime("%Y-%m-%d"),
                "employees": [],
                "managers": [],
                "shifts": {
                    "morning": {
                        "shift_type": "morning",
                        "capacity": 5,
                        "assigned_employees": []
                    },
                    "evening": {
                        "shift_type": "evening",
                        "capacity": 5,
                        "assigned_employees": []
                    }
                },
                "absences": {
                    "مرخصی": [],
                    "بیمار": [],
                    "غایب": []
                },
                "tasks": {
                    "tasks": {},
                    "next_task_id": 1
                },
                "settings": {
                    "shift_capacity": 5,
                    "morning_capacity": 5,
                    "evening_capacity": 5,
                    "shared_folder_path": self.data_dir
                },
                "last_modified": datetime.now().isoformat()
            }
    
    def _load_sample_employees(self) -> List[Dict[str, Any]]:
        """Load sample employee data from CSV file."""
        try:
            # Look for sample_employees.csv in multiple possible locations
            possible_paths = [
                os.path.join(self.data_dir, "sample_employees.csv"),  # data/sample_employees.csv
                os.path.join(os.path.dirname(self.data_dir), "sample_employees.csv"),  # ../sample_employees.csv
                "sample_employees.csv",  # Current directory
                os.path.join(os.getcwd(), "sample_employees.csv"),  # Absolute current directory
            ]
            
            csv_path = None
            for path in possible_paths:
                if os.path.exists(path):
                    csv_path = path
                    break
            
            if not csv_path:
                print(f"Debug: Sample employees CSV not found. Tried paths:")
                for path in possible_paths:
                    print(f"  - {path} (exists: {os.path.exists(path)})")
                return []
            
            print(f"Debug: Loading sample employees from {csv_path}")
            
            import csv
            employees = []
            
            with open(csv_path, 'r', encoding='utf-8') as f:
                reader = csv.DictReader(f)
                for row in reader:
                    # Convert CSV row to employee dict
                    employee = {
                        "employee_id": row.get("employee_id", ""),
                        "first_name": row.get("first_name", ""),
                        "last_name": row.get("last_name", ""),
                        "role": row.get("role", "کارگر"),
                        "photo_path": row.get("photo_path", ""),
                        "created_at": datetime.now().isoformat(),
                        "updated_at": datetime.now().isoformat()
                    }
                    employees.append(employee)
            
            print(f"Debug: Successfully loaded {len(employees)} sample employees")
            return employees
            
        except Exception as e:
            print(f"Debug: Error loading sample employees: {e}")
            import traceback
            traceback.print_exc()
            return []
    
    def ensure_today_report_exists(self) -> Dict[str, Any]:
        """Ensure today's report exists, create if it doesn't."""
        filepath = self.get_today_filepath()
        print(f"Debug: ensure_today_report_exists called, filepath: {filepath}")
        print(f"Debug: File exists: {os.path.exists(filepath)}")
        
        if os.path.exists(filepath):
            data = self.read_json(filepath)
            print(f"Debug: Read existing file, data keys: {list(data.keys()) if data else 'None'}")
            if data:
                # Check if the existing file has employees
                emp_count = len(data.get('employees', []))
                mgr_count = len(data.get('managers', []))
                print(f"Debug: Existing file has {emp_count} employees and {mgr_count} managers")
                
                # If no employees, try to carry forward from previous day
                if emp_count == 0 and mgr_count == 0:
                    print(f"Debug: Existing file has no employees, trying to carry forward from previous day")
                    previous_data = self._get_previous_day_data()
                    if previous_data:
                        data['employees'] = previous_data.get('employees', [])
                        data['managers'] = previous_data.get('managers', [])
                        data['settings']['managers'] = previous_data.get('settings', {}).get('managers', [])
                        self.write_json(filepath, data)
                        print(f"Debug: Carried forward {len(data.get('employees', []))} employees from previous day")
                        return data
                    else:
                        print(f"Debug: No previous day data found, recreating with sample data")
                        os.remove(filepath)  # Delete empty file
                        data = None  # Force recreation
                else:
                    return data
        
        # Create default report with sample data or previous day data
        print(f"Debug: Creating new report")
        previous_data = self._get_previous_day_data()
        if previous_data and (previous_data.get('employees') or previous_data.get('managers')):
            print(f"Debug: Using previous day data as base")
            default_data = self._create_report_from_previous(previous_data)
        else:
            print(f"Debug: Using sample data as base")
            default_data = self.get_default_report_structure()
        
        print(f"Debug: Report created with {len(default_data.get('employees', []))} employees and {len(default_data.get('managers', []))} managers")
        
        success = self.write_json(filepath, default_data)
        print(f"Debug: Report file write success: {success}")
        
        return default_data
    
    def get_employee_photo_path(self, employee_id: str) -> str:
        """Get employee photo filepath."""
        return os.path.join(self.images_dir, f"{employee_id}.jpg")
    
    def save_employee_photo(self, employee_id: str, photo_data: bytes) -> bool:
        """Save employee photo."""
        try:
            photo_path = self.get_employee_photo_path(employee_id)
            with open(photo_path, 'wb') as f:
                f.write(photo_data)
            logging.info(f"Photo saved for employee {employee_id}")
            return True
        except Exception as e:
            logging.error(f"Failed to save photo for employee {employee_id}: {e}")
            return False
    
    def get_all_reports(self) -> list:
        """Get list of all report files."""
        try:
            files = [f for f in os.listdir(self.reports_dir) if f.startswith("report_") and f.endswith(".json") and not "_backup_" in f]
            return sorted(files, reverse=True)
        except Exception as e:
            logging.error(f"Error listing reports: {e}")
            return []
    
    def _get_previous_day_data(self) -> Optional[Dict[str, Any]]:
        """Get data from the most recent previous day report."""
        try:
            reports = self.get_all_reports()
            today_filename = self.get_today_filename()
            
            # Find the most recent report that's not today
            for report_file in reports:
                if report_file != today_filename:
                    filepath = os.path.join(self.reports_dir, report_file)
                    data = self.read_json(filepath)
                    if data and (data.get('employees') or data.get('managers')):
                        print(f"Debug: Found previous day data in {report_file}")
                        return data
            
            print(f"Debug: No previous day data found")
            return None
        except Exception as e:
            print(f"Debug: Error getting previous day data: {e}")
            return None
    
    def _create_report_from_previous(self, previous_data: Dict[str, Any]) -> Dict[str, Any]:
        """Create a new report based on previous day data."""
        try:
            # Start with default structure
            new_data = self.get_default_report_structure()
            
            # Carry forward employees and managers
            new_data['employees'] = previous_data.get('employees', [])
            new_data['managers'] = previous_data.get('managers', [])
            
            # Carry forward settings but update date
            if 'settings' in previous_data:
                new_data['settings'].update(previous_data['settings'])
                new_data['settings']['shared_folder_path'] = self.data_dir  # Update path
            
            # Reset shifts (clear assignments but keep structure)
            if 'shifts' in previous_data:
                for shift_type in ['morning', 'evening']:
                    if shift_type in previous_data['shifts']:
                        new_data['shifts'][shift_type]['capacity'] = previous_data['shifts'][shift_type].get('capacity', 5)
                        new_data['shifts'][shift_type]['assigned_employees'] = []  # Clear assignments
            
            # Clear absences for new day
            new_data['absences'] = {"مرخصی": [], "بیمار": [], "غایب": []}
            
            # Reset tasks for new day
            new_data['tasks'] = {"tasks": {}, "next_task_id": 1}
            
            return new_data
        except Exception as e:
            print(f"Debug: Error creating report from previous data: {e}")
            return self.get_default_report_structure()
