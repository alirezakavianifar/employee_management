#!/usr/bin/env python3
"""
Responsive Design Demo for Display App

This script demonstrates the responsive design features of the display app.
It shows how the layout adapts to different screen sizes.

Usage:
    python responsive_demo.py

Features demonstrated:
- Screen size detection
- Responsive breakpoints (mobile, tablet, desktop)
- Dynamic layout adjustment
- Responsive font sizes and spacing
- Adaptive grid layouts
"""

import sys
import os
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QHBoxLayout
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from display_app.views.main_window import DisplayMainWindow

class ResponsiveDemoWindow(QMainWindow):
    """Demo window to showcase responsive design features."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.setup_responsive_demo()
    
    def setup_ui(self):
        """Setup the demo UI."""
        self.setWindowTitle("Responsive Design Demo - Display App")
        self.setGeometry(100, 100, 1200, 800)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title
        title = QLabel("Responsive Design Demo")
        title.setFont(QFont("Tahoma", 24, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #1e3a8a; margin-bottom: 20px;")
        layout.addWidget(title)
        
        # Description
        description = QLabel("""
        This demo showcases the responsive design features of the Display App:
        
        • Screen size detection and breakpoint system
        • Dynamic layout adjustment (mobile, tablet, desktop)
        • Responsive font sizes and spacing
        • Adaptive grid layouts
        • Real-time layout updates on window resize
        
        Try resizing the window to see the responsive behavior in action!
        """)
        description.setFont(QFont("Tahoma", 12))
        description.setAlignment(Qt.AlignLeft)
        description.setWordWrap(True)
        description.setStyleSheet("color: #374151; background: #f3f4f6; padding: 20px; border-radius: 10px;")
        layout.addWidget(description)
        
        # Control buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        
        # Launch Display App button
        launch_btn = QPushButton("Launch Display App")
        launch_btn.setFont(QFont("Tahoma", 12, QFont.Bold))
        launch_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #10b981, stop:1 #059669);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #34d399, stop:1 #10b981);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #059669, stop:1 #047857);
            }
        """)
        launch_btn.clicked.connect(self.launch_display_app)
        button_layout.addWidget(launch_btn)
        
        # Test responsive button
        test_btn = QPushButton("Test Responsive Layout")
        test_btn.setFont(QFont("Tahoma", 12, QFont.Bold))
        test_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #3b82f6, stop:1 #2563eb);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #60a5fa, stop:1 #3b82f6);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #2563eb, stop:1 #1d4ed8);
            }
        """)
        test_btn.clicked.connect(self.test_responsive_layout)
        button_layout.addWidget(test_btn)
        
        layout.addLayout(button_layout)
        
        # Screen info display
        self.screen_info = QLabel()
        self.screen_info.setFont(QFont("Tahoma", 11))
        self.screen_info.setAlignment(Qt.AlignCenter)
        self.screen_info.setStyleSheet("color: #6b7280; background: #f9fafb; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;")
        layout.addWidget(self.screen_info)
        
        # Add stretch
        layout.addStretch()
        
        central_widget.setLayout(layout)
        
        # Update screen info initially
        self.update_screen_info()
    
    def setup_responsive_demo(self):
        """Setup responsive demo features."""
        # Timer to update screen info
        self.update_timer = QTimer()
        self.update_timer.timeout.connect(self.update_screen_info)
        self.update_timer.start(1000)  # Update every second
    
    def update_screen_info(self):
        """Update screen information display."""
        try:
            # Get current window size
            window_size = self.size()
            width = window_size.width()
            height = window_size.height()
            
            # Determine device type
            if width < 768:
                device_type = "Mobile"
                layout_type = "Single Column"
            elif width < 1024:
                device_type = "Tablet"
                layout_type = "2 Columns with Stacking"
            else:
                device_type = "Desktop"
                layout_type = "2 Columns"
            
            # Get screen geometry
            screen = QApplication.desktop().screenGeometry()
            screen_width = screen.width()
            screen_height = screen.height()
            
            info_text = f"""
            Current Window: {width} × {height} pixels
            Device Type: {device_type}
            Layout Type: {layout_type}
            Screen Resolution: {screen_width} × {screen_height} pixels
            """
            
            self.screen_info.setText(info_text)
            
        except Exception as e:
            print(f"Error updating screen info: {e}")
    
    def launch_display_app(self):
        """Launch the actual display app."""
        try:
            print("Launching Display App...")
            # Create and show display app window
            self.display_app = DisplayMainWindow()
            self.display_app.show()
            print("Display App launched successfully!")
            
        except Exception as e:
            print(f"Error launching display app: {e}")
            import traceback
            traceback.print_exc()
    
    def test_responsive_layout(self):
        """Test responsive layout by cycling through different window sizes."""
        try:
            print("Testing responsive layout...")
            
            # Test different window sizes
            test_sizes = [
                (400, 600),   # Mobile
                (800, 600),   # Tablet
                (1200, 800),  # Desktop
                (1600, 900),  # Large Desktop
            ]
            
            current_size_index = 0
            
            def cycle_size():
                nonlocal current_size_index
                if current_size_index < len(test_sizes):
                    width, height = test_sizes[current_size_index]
                    self.resize(width, height)
                    print(f"Resized to: {width} × {height}")
                    current_size_index += 1
                else:
                    # Reset to original size
                    self.resize(1200, 800)
                    current_size_index = 0
                    self.test_timer.stop()
                    print("Responsive layout test completed!")
            
            # Start timer to cycle through sizes
            self.test_timer = QTimer()
            self.test_timer.timeout.connect(cycle_size)
            self.test_timer.start(2000)  # Change size every 2 seconds
            
        except Exception as e:
            print(f"Error testing responsive layout: {e}")
    
    def resizeEvent(self, event):
        """Handle window resize events."""
        super().resizeEvent(event)
        # Update screen info when window is resized
        QTimer.singleShot(100, self.update_screen_info)

def main():
    """Main entry point for the responsive demo."""
    try:
        # Create application
        app = QApplication(sys.argv)
        app.setApplicationName("Responsive Design Demo")
        app.setApplicationVersion("1.0.0")
        
        # Create and show demo window
        demo_window = ResponsiveDemoWindow()
        demo_window.show()
        
        print("Responsive Design Demo started!")
        print("Try resizing the window to see responsive behavior.")
        print("Click 'Launch Display App' to see the actual responsive display app.")
        
        # Start event loop
        sys.exit(app.exec_())
        
    except Exception as e:
        print(f"Failed to start Responsive Demo: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
