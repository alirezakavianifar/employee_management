import sys
import os
from datetime import datetime
from PyQt5.QtWidgets import (QMainWindow, QWidget, QVBoxLayout, QApplication, 
                             QHBoxLayout, QPushButton, QLabel, QSpacerItem, QSizePolicy,
                             QScrollArea)
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont, QIcon

def get_data_directory():
    """Get the correct data directory path."""
    # If running as exe, look for data directory relative to exe location
    if getattr(sys, 'frozen', False):
        # Running as compiled exe
        exe_dir = os.path.dirname(sys.executable)
        data_dir = os.path.join(exe_dir, "data")
        
        # If data directory doesn't exist in exe location, try current working directory
        if not os.path.exists(data_dir):
            data_dir = os.path.join(os.getcwd(), "data")
        
        # If still doesn't exist, create it
        if not os.path.exists(data_dir):
            os.makedirs(data_dir, exist_ok=True)
            os.makedirs(os.path.join(data_dir, "logs"), exist_ok=True)
            os.makedirs(os.path.join(data_dir, "reports"), exist_ok=True)
            os.makedirs(os.path.join(data_dir, "images", "staff"), exist_ok=True)
    else:
        # Running as script - use shared data directory with management app
        data_dir = "data"
    
    return data_dir

from display_app.widgets.dashboard_widget import DashboardWidget
from display_app.services.data_service import DataService
from display_app.services.ai_service import AIService
from display_app.services.chart_service import ChartService
from display_app.utils.config_utils import ConfigUtils
from shared.json_handler import JSONHandler
from shared.improved_sync import ImprovedSyncManager as SyncManager

class DisplayMainWindow(QMainWindow):
    """Main window for the display application (full-screen dashboard)."""
    
    def __init__(self):
        super().__init__()
        
        # Set up global exception handler
        sys.excepthook = self._global_exception_handler
        
        # Get the correct data directory
        data_dir = get_data_directory()
        
        # Initialize services with error handling
        try:
            self.json_handler = JSONHandler(data_dir)
            self.sync_manager = SyncManager(data_dir, sync_interval=5)
            self.data_service = DataService(data_dir)
            self.ai_service = AIService()
            self.chart_service = ChartService()
            self.config_utils = ConfigUtils()
        except Exception as e:
            print(f"Error initializing services: {e}")
            import traceback
            traceback.print_exc()
            # Continue with partial initialization
        
        self.setup_ui()
        self.setup_connections()
        self.setup_timer()
        self.load_initial_data()
        self.initialize_timer_display()
    
    def _global_exception_handler(self, exc_type, exc_value, exc_traceback):
        """Global exception handler to prevent crashes."""
        try:
            print(f"CRITICAL ERROR: {exc_type.__name__}: {exc_value}")
            print("Attempting to recover...")
            
            # Log the error
            import traceback
            traceback.print_exc()
            
            # Try to show error status
            try:
                self.show_refresh_status("خطا - در حال بازیابی", "#ef4444")
            except:
                pass
            
            # Force cleanup
            try:
                self._perform_memory_cleanup()
            except:
                pass
            
            print("Recovery attempt completed")
            
        except Exception as recovery_error:
            print(f"Recovery failed: {recovery_error}")
            # If recovery fails, we can't do much more
    
    def initialize_timer_display(self):
        """Initialize the timer display with startup information."""
        try:
            current_time = datetime.now()
            
            # Set initial last update time
            self.last_update_time = current_time
            
            # Format startup time
            startup_str = current_time.strftime("%H:%M:%S")
            
            # Safe access to UI elements
            if hasattr(self, 'last_update_label') and self.last_update_label:
                self.last_update_label.setText(f"آخرین بروزرسانی: {startup_str}")
            
            # Set initial countdown
            self.countdown_seconds = 30
            if hasattr(self, 'countdown_label') and self.countdown_label:
                self.countdown_label.setText(f"بعدی در: {self.countdown_seconds}s")
            
            # Set initial status
            self.show_refresh_status("آماده", "#10b981")
            
        except Exception as e:
            print(f"Error initializing timer display: {e}")
            import traceback
            traceback.print_exc()
    
    def setup_ui(self):
        """Setup the user interface with responsive design."""
        self.setWindowTitle("نمایش شیفت کارمندان")
        
        # Set full screen
        self.showFullScreen()
        
        # Set window flags for kiosk mode but allow normal window controls
        self.setWindowFlags(
            Qt.Window |
            Qt.WindowStaysOnTopHint
        )
        
        # Central widget with responsive properties
        central_widget = QWidget()
        central_widget.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        self.setCentralWidget(central_widget)
        
        # Main layout with responsive properties
        layout = QVBoxLayout()
        layout.setContentsMargins(0, 0, 0, 0)
        layout.setSpacing(0)
        
        # Control bar at the top with responsive height
        self.create_control_bar(layout)
        
        # Create scrollable area for dashboard
        self.scroll_area = QScrollArea()
        self.scroll_area.setWidgetResizable(True)
        self.scroll_area.setHorizontalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setVerticalScrollBarPolicy(Qt.ScrollBarAsNeeded)
        self.scroll_area.setStyleSheet("""
            QScrollArea {
                border: none;
                background: #1e3a8a;
            }
            QScrollBar:vertical {
                border: none;
                background: rgba(255, 255, 255, 0.1);
                width: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:vertical {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 6px;
                min-height: 20px;
            }
            QScrollBar::handle:vertical:hover {
                background: rgba(255, 255, 255, 0.5);
            }
            QScrollBar::add-line:vertical, QScrollBar::sub-line:vertical {
                border: none;
                background: none;
            }
            QScrollBar:horizontal {
                border: none;
                background: rgba(255, 255, 255, 0.1);
                height: 12px;
                border-radius: 6px;
            }
            QScrollBar::handle:horizontal {
                background: rgba(255, 255, 255, 0.3);
                border-radius: 6px;
                min-width: 20px;
            }
            QScrollBar::handle:horizontal:hover {
                background: rgba(255, 255, 255, 0.5);
            }
            QScrollBar::add-line:horizontal, QScrollBar::sub-line:horizontal {
                border: none;
                background: none;
            }
        """)
        
        # Dashboard widget with responsive properties
        self.dashboard = DashboardWidget()
        self.dashboard.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
        
        # Set minimum size to ensure content is scrollable
        self.dashboard.setMinimumSize(1200, 800)  # Minimum size for proper display
        
        # Set the dashboard as the scroll area's widget
        self.scroll_area.setWidget(self.dashboard)
        
        # Add scroll area to main layout
        layout.addWidget(self.scroll_area, 1)  # Stretch factor of 1
        
        central_widget.setLayout(layout)
        
        # Setup fonts
        self.setup_fonts()
        
        # Setup responsive behavior
        self.setup_responsive_behavior()
    
    def create_control_bar(self, layout):
        """Create a responsive control bar with window control buttons."""
        control_bar = QWidget()
        
        # Set responsive height based on screen size
        if hasattr(self, 'is_mobile') and self.is_mobile:
            control_bar.setFixedHeight(40)
        elif hasattr(self, 'is_tablet') and self.is_tablet:
            control_bar.setFixedHeight(45)
        else:
            control_bar.setFixedHeight(50)
        
        # Store height for responsive updates
        self.control_bar_height = control_bar.height()
        
        control_bar.setStyleSheet("""
            QWidget {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #1e40af, stop:1 #1e3a8a);
                border-bottom: 2px solid #3b82f6;
            }
        """)
        
        control_layout = QHBoxLayout()
        control_layout.setContentsMargins(20, 10, 20, 10)
        control_layout.setSpacing(15)
        
        # Title
        title_label = QLabel("سیستم نمایش شیفت کارمندان")
        title_label.setStyleSheet("""
            QLabel {
                color: white;
                font-size: 18px;
                font-weight: bold;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        control_layout.addWidget(title_label)
        
        # Keyboard shortcuts hint
        shortcuts_label = QLabel("کلیدهای میانبر: ESC (خروج از تمام صفحه) | F11 (تغییر حالت) | Ctrl+Q (بستن) | ↑↓ (اسکرول)")
        shortcuts_label.setStyleSheet("""
            QLabel {
                color: #93c5fd;
                font-size: 11px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        control_layout.addWidget(shortcuts_label)
        
        # Spacer to push timer to center
        control_layout.addItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        
        # Timer display
        self.create_timer_display(control_layout)
        
        # Spacer to push buttons to the right
        control_layout.addItem(QSpacerItem(40, 20, QSizePolicy.Expanding, QSizePolicy.Minimum))
        
        # Control buttons
        self.create_control_buttons(control_layout)
        
        control_bar.setLayout(control_layout)
        layout.addWidget(control_bar)
    
    def create_timer_display(self, layout):
        """Create a timer display showing last update and countdown."""
        timer_widget = QWidget()
        timer_widget.setFixedSize(320, 35)
        timer_widget.setStyleSheet("""
            QWidget {
                background: rgba(255, 255, 255, 0.1);
                border: 1px solid rgba(255, 255, 255, 0.2);
                border-radius: 6px;
            }
        """)
        
        timer_layout = QHBoxLayout()
        timer_layout.setContentsMargins(10, 5, 10, 5)
        timer_layout.setSpacing(8)
        
        # Last update label
        self.last_update_label = QLabel("آخرین بروزرسانی: --")
        self.last_update_label.setStyleSheet("""
            QLabel {
                color: #93c5fd;
                font-size: 11px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        timer_layout.addWidget(self.last_update_label)
        
        # Separator
        separator = QLabel("|")
        separator.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.3);
                font-size: 11px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        timer_layout.addWidget(separator)
        
        # Countdown label
        self.countdown_label = QLabel("بعدی در: 30s")
        self.countdown_label.setStyleSheet("""
            QLabel {
                color: #10b981;
                font-size: 11px;
                font-weight: bold;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        timer_layout.addWidget(self.countdown_label)
        
        # Separator
        separator2 = QLabel("|")
        separator2.setStyleSheet("""
            QLabel {
                color: rgba(255, 255, 255, 0.3);
                font-size: 11px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        timer_layout.addWidget(separator2)
        
        # Status indicator
        self.status_label = QLabel("آماده")
        self.status_label.setStyleSheet("""
            QLabel {
                color: #10b981;
                font-size: 11px;
                font-weight: bold;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        timer_layout.addWidget(self.status_label)
        
        timer_widget.setLayout(timer_layout)
        layout.addWidget(timer_widget)
    
    def show_refresh_status(self, status: str, color: str = "#10b981"):
        """Show refresh status in the timer display."""
        try:
            # Safe access to status label
            if hasattr(self, 'status_label') and self.status_label:
                self.status_label.setText(status)
                self.status_label.setStyleSheet(f"""
                    QLabel {{
                        color: {color};
                        font-size: 11px;
                        font-weight: bold;
                        font-family: 'Tahoma', Arial, sans-serif;
                    }}
                """)
        except Exception as e:
            print(f"Error showing refresh status: {e}")
            import traceback
            traceback.print_exc()
    
    def create_control_buttons(self, layout):
        """Create the control buttons for the control bar."""
        # Exit Fullscreen Button
        exit_fullscreen_btn = QPushButton("خروج از تمام صفحه")
        exit_fullscreen_btn.setFixedSize(120, 35)
        exit_fullscreen_btn.setToolTip("خروج از حالت تمام صفحه (ESC)")
        exit_fullscreen_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #f59e0b, stop:1 #d97706);
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #fbbf24, stop:1 #f59e0b);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #d97706, stop:1 #b45309);
            }
        """)
        exit_fullscreen_btn.clicked.connect(self.toggle_fullscreen)
        layout.addWidget(exit_fullscreen_btn)
        
        # Minimize Button
        minimize_btn = QPushButton("کوچک کردن")
        minimize_btn.setFixedSize(100, 35)
        minimize_btn.setToolTip("کوچک کردن پنجره")
        minimize_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #10b981, stop:1 #059669);
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #34d399, stop:1 #10b981);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #059669, stop:1 #047857);
            }
        """)
        minimize_btn.clicked.connect(self.showMinimized)
        layout.addWidget(minimize_btn)
        
        # Close Button
        close_btn = QPushButton("بستن")
        close_btn.setFixedSize(80, 35)
        close_btn.setToolTip("بستن برنامه (Ctrl+Q)")
        close_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #ef4444, stop:1 #dc2626);
                color: white;
                border: none;
                border-radius: 6px;
                font-weight: bold;
                font-size: 12px;
                font-family: 'Tahoma', Arial, sans-serif;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #f87171, stop:1 #ef4444);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #dc2626, stop:1 #b91c1c);
            }
        """)
        close_btn.clicked.connect(self.close)
        layout.addWidget(close_btn)
    
    def toggle_fullscreen(self):
        """Toggle between fullscreen and normal mode."""
        try:
            if self.isFullScreen():
                # Exiting fullscreen - reset fullscreen layout flag
                if hasattr(self, '_fullscreen_layout_applied'):
                    delattr(self, '_fullscreen_layout_applied')
                self.showNormal()
                print("DEBUG: Exited fullscreen mode")
            else:
                # Entering fullscreen - set fullscreen layout flag
                self._fullscreen_layout_applied = False
                self.showFullScreen()
                print("DEBUG: Entered fullscreen mode")
                
        except Exception as e:
            print(f"Error toggling fullscreen: {e}")
            # Fallback to basic toggle
            if self.isFullScreen():
                self.showNormal()
            else:
                self.showFullScreen()
    
    def setup_fonts(self):
        """Setup Persian-compatible fonts."""
        # Use Tahoma font for better Persian text support
        font = QFont("Tahoma", 9)
        self.setFont(font)
        
        # Set dark theme for the main window
        self.setStyleSheet("""
            QMainWindow {
                background: #1e3a8a;
                color: white;
                font-family: 'Tahoma', Arial, sans-serif;
            }
        """)
        
        # Set RTL layout direction for Persian interface
        self.setLayoutDirection(Qt.RightToLeft)
    
    def setup_responsive_behavior(self):
        """Setup responsive behavior based on screen size."""
        try:
            # Get screen geometry
            screen = QApplication.desktop().screenGeometry()
            screen_width = screen.width()
            screen_height = screen.height()
            
            # Store screen dimensions for responsive calculations
            self.screen_width = screen_width
            self.screen_height = screen_height
            
            # For fullscreen apps, always use desktop layout regardless of actual screen size
            # This prevents layout changes when toggling fullscreen
            self.is_mobile = False
            self.is_tablet = False
            self.is_desktop = True
            
            # Store original screen dimensions for reference
            self.original_screen_width = screen_width
            self.original_screen_height = screen_height
            
            # Set responsive properties based on screen size
            self.apply_responsive_properties()
            
            print(f"DEBUG: Screen size detected: {screen_width}x{screen_height}")
            print(f"DEBUG: Using desktop layout for fullscreen app")
            
        except Exception as e:
            print(f"Error setting up responsive behavior: {e}")
            # Fallback to desktop mode
            self.is_mobile = False
            self.is_tablet = False
            self.is_desktop = True
            self.screen_width = 1920
            self.screen_height = 1080
            self.original_screen_width = 1920
            self.original_screen_height = 1080
    
    def apply_responsive_properties(self):
        """Apply responsive properties based on current screen size."""
        try:
            if hasattr(self, 'dashboard') and self.dashboard:
                # Check if we're in fullscreen mode
                if self.isFullScreen():
                    # Use stable layout for fullscreen mode
                    self.dashboard.apply_stable_layout()
                else:
                    # Use responsive layout for windowed mode
                    self.dashboard.apply_responsive_layout(
                        self.screen_width, 
                        self.screen_height,
                        self.is_mobile,
                        self.is_tablet,
                        self.is_desktop
                    )
            
            # Update scroll area properties
            if hasattr(self, 'scroll_area') and self.scroll_area:
                # Ensure scroll area adapts to content size
                self.scroll_area.setWidgetResizable(True)
                # Update scroll area size policy
                self.scroll_area.setSizePolicy(QSizePolicy.Expanding, QSizePolicy.Expanding)
            
            # Adjust control bar height based on screen size
            if hasattr(self, 'control_bar_height'):
                if self.is_mobile:
                    self.control_bar_height = 40
                elif self.is_tablet:
                    self.control_bar_height = 45
                else:
                    self.control_bar_height = 50
                    
        except Exception as e:
            print(f"Error applying responsive properties: {e}")
    
    def resizeEvent(self, event):
        """Handle window resize events for responsive behavior."""
        try:
            super().resizeEvent(event)
            
            # Update screen dimensions
            self.screen_width = event.size().width()
            self.screen_height = event.size().height()
            
            # For fullscreen apps, maintain desktop layout to prevent view changes
            # Only allow responsive changes if the app is not in fullscreen mode
            if not self.isFullScreen():
                # Recalculate responsive properties only for windowed mode
                self.is_mobile = self.screen_width < 768
                self.is_tablet = 768 <= self.screen_width < 1024
                self.is_desktop = self.screen_width >= 1024
                
                # Apply responsive properties
                self.apply_responsive_properties()
            else:
                # In fullscreen mode, always use desktop layout
                self.is_mobile = False
                self.is_tablet = False
                self.is_desktop = True
                
                # Only apply properties if they haven't been set yet
                if not hasattr(self, '_fullscreen_layout_applied'):
                    self.apply_responsive_properties()
                    self._fullscreen_layout_applied = True
            
        except Exception as e:
            print(f"Error handling resize event: {e}")
            super().resizeEvent(event)
    
    def setup_connections(self):
        """Setup signal connections."""
        try:
            # Connect sync manager
            self.sync_manager.add_sync_callback(self.on_sync_triggered)
            self.sync_manager.start_sync()
            
            # Connect dashboard refresh
            self.dashboard.refresh_display = self.refresh_data
        except Exception as e:
            print(f"Error setting up connections: {e}")
    
    def setup_timer(self):
        """Setup timer for periodic data refresh."""
        try:
            # Get refresh interval from config (default to 30 seconds)
            refresh_interval = self._get_refresh_interval()
            
            # Main refresh timer (configurable interval)
            self.refresh_timer = QTimer()
            self.refresh_timer.timeout.connect(self.refresh_data)
            self.refresh_timer.start(refresh_interval * 1000)  # Convert to milliseconds
            
            # Countdown timer (updates every second)
            self.countdown_timer = QTimer()
            self.countdown_timer.timeout.connect(self.update_countdown)
            self.countdown_timer.start(1000)  # 1 second
            
            # Memory cleanup timer (every 5 minutes)
            self.memory_cleanup_timer = QTimer()
            self.memory_cleanup_timer.timeout.connect(self._perform_memory_cleanup)
            self.memory_cleanup_timer.start(300000)  # 5 minutes
            
            # Initialize countdown with configurable interval
            self.countdown_seconds = refresh_interval
            self.last_update_time = None
            
            # Add safety timer to prevent excessive updates
            self.safety_timer = QTimer()
            self.safety_timer.setSingleShot(True)
            self.safety_timer.timeout.connect(self._enable_refresh)
            self._refresh_enabled = True
            
            # Initialize sync timer for thread-safe operations
            self.sync_timer = QTimer()
            self.sync_timer.setSingleShot(True)
            
            print(f"DEBUG: All timers set up successfully with refresh interval: {refresh_interval} seconds")
            
        except Exception as e:
            print(f"Error setting up timer: {e}")
            import traceback
            traceback.print_exc()
    
    def _get_refresh_interval(self):
        """Get refresh interval from configuration with validation."""
        try:
            if hasattr(self, 'config_utils') and self.config_utils:
                interval_str = self.config_utils.get_config_value('display', 'refresh_interval', '30')
                interval = int(interval_str)
                
                # Validate interval (minimum 5 seconds, maximum 300 seconds)
                if interval < 5:
                    print(f"WARNING: Refresh interval {interval} is too low, using minimum of 5 seconds")
                    interval = 5
                elif interval > 300:
                    print(f"WARNING: Refresh interval {interval} is too high, using maximum of 300 seconds")
                    interval = 300
                
                return interval
            else:
                print("WARNING: Config utils not available, using default 30 seconds")
                return 30
        except (ValueError, TypeError) as e:
            print(f"WARNING: Invalid refresh interval in config: {e}, using default 30 seconds")
            return 30
        except Exception as e:
            print(f"WARNING: Error reading refresh interval: {e}, using default 30 seconds")
            return 30
    
    def update_refresh_interval(self, new_interval: int):
        """Dynamically update the refresh interval without restarting the app."""
        try:
            # Validate the new interval
            if new_interval < 5:
                print(f"WARNING: Refresh interval {new_interval} is too low, using minimum of 5 seconds")
                new_interval = 5
            elif new_interval > 300:
                print(f"WARNING: Refresh interval {new_interval} is too high, using maximum of 300 seconds")
                new_interval = 300
            
            # Update the configuration
            if hasattr(self, 'config_utils') and self.config_utils:
                self.config_utils.set_config_value('display', 'refresh_interval', str(new_interval))
            
            # Stop the current timer
            if hasattr(self, 'refresh_timer') and self.refresh_timer:
                self.refresh_timer.stop()
            
            # Restart with new interval
            if hasattr(self, 'refresh_timer') and self.refresh_timer:
                self.refresh_timer.start(new_interval * 1000)  # Convert to milliseconds
            
            # Update countdown to match new interval
            if hasattr(self, 'countdown_seconds'):
                self.countdown_seconds = new_interval
            
            print(f"DEBUG: Refresh interval updated to {new_interval} seconds")
            return True
            
        except Exception as e:
            print(f"Error updating refresh interval: {e}")
            import traceback
            traceback.print_exc()
            return False
    
    def _enable_refresh(self):
        """Re-enable refresh after safety timeout."""
        self._refresh_enabled = True
    
    def _perform_memory_cleanup(self):
        """Perform memory cleanup operations."""
        try:
            print("DEBUG: Performing memory cleanup")
            # Clean up matplotlib charts
            if hasattr(self, 'chart_service') and self.chart_service:
                self.chart_service.cleanup_charts()
            
            # Force garbage collection
            import gc
            gc.collect()
            
            print("DEBUG: Memory cleanup completed")
        except Exception as e:
            print(f"Error during memory cleanup: {e}")
            import traceback
            traceback.print_exc()
    
    def update_countdown(self):
        """Update the countdown display every second."""
        try:
            # Safe access to countdown variables
            if not hasattr(self, 'countdown_seconds'):
                self.countdown_seconds = self._get_refresh_interval()
                return
            
            if self.countdown_seconds > 0:
                self.countdown_seconds -= 1
                # Safe access to countdown label
                if hasattr(self, 'countdown_label') and self.countdown_label:
                    self.countdown_label.setText(f"بعدی در: {self.countdown_seconds}s")
            else:
                # Reset countdown when it reaches 0 using current config
                self.countdown_seconds = self._get_refresh_interval()
                if hasattr(self, 'countdown_label') and self.countdown_label:
                    self.countdown_label.setText(f"بعدی در: {self.countdown_seconds}s")
        except Exception as e:
            print(f"Error updating countdown: {e}")
            import traceback
            traceback.print_exc()
    
    def update_timer_display(self):
        """Update the timer display with current time."""
        try:
            current_time = datetime.now()
            
            # Safe initialization of last_update_time
            if not hasattr(self, 'last_update_time') or self.last_update_time is None:
                self.last_update_time = current_time
            
            # Format last update time
            last_update_str = self.last_update_time.strftime("%H:%M:%S")
            
            # Safe access to UI elements
            if hasattr(self, 'last_update_label') and self.last_update_label:
                self.last_update_label.setText(f"آخرین بروزرسانی: {last_update_str}")
            
            # Reset countdown safely
            if not hasattr(self, 'countdown_seconds'):
                self.countdown_seconds = 30
            else:
                self.countdown_seconds = 30
                
            if hasattr(self, 'countdown_label') and self.countdown_label:
                self.countdown_label.setText(f"بعدی در: {self.countdown_seconds}s")
            
        except Exception as e:
            print(f"Error updating timer display: {e}")
            import traceback
            traceback.print_exc()
    
    def load_initial_data(self):
        """Load initial data from JSON files."""
        try:
            # Safe access to services
            if not hasattr(self, 'data_service') or not self.data_service:
                print("DEBUG: data_service not available")
                return
                
            # Try to load today's report using data service
            report_data = self.data_service.get_today_report()
            
            # Safe data validation
            if report_data and isinstance(report_data, dict):
                if hasattr(self, 'dashboard') and self.dashboard:
                    self.dashboard.update_dashboard(report_data)
                else:
                    print("DEBUG: Dashboard not available")
            else:
                # Create default report if none exists
                if hasattr(self, 'json_handler') and self.json_handler:
                    default_data = self.json_handler.get_default_report_structure()
                    if hasattr(self, 'dashboard') and self.dashboard:
                        self.dashboard.update_dashboard(default_data)
                    else:
                        print("DEBUG: Dashboard not available")
                else:
                    print("DEBUG: JSON handler not available")
            
            # Update timer display after loading data
            self.update_timer_display()
                
        except Exception as e:
            print(f"Error loading initial data: {e}")
            import traceback
            traceback.print_exc()
            
            # Show error on dashboard safely
            error_data = {
                "date": "خطا در بارگذاری",
                "managers": [],
                "shifts": {"morning": [], "evening": []},
                "absences": {"مرخصی": [], "بیمار": [], "غایب": []},
                "settings": {"shift_capacity": 0, "shared_folder_path": ""}
            }
            try:
                if hasattr(self, 'dashboard') and self.dashboard:
                    self.dashboard.update_dashboard(error_data)
                else:
                    print("DEBUG: Dashboard not available for error display")
            except Exception as dashboard_error:
                print(f"Error updating dashboard with error data: {dashboard_error}")
                import traceback
                traceback.print_exc()
    
    def refresh_data(self):
        """Refresh data from JSON files."""
        try:
            # Safety check to prevent excessive updates (but allow sync operations)
            if not hasattr(self, '_refresh_enabled') or not self._refresh_enabled:
                print("DEBUG: Refresh disabled due to safety timeout")
                return
            
            # Disable refresh temporarily to prevent rapid successive calls
            self._refresh_enabled = False
            if hasattr(self, 'safety_timer'):
                self.safety_timer.start(5000)  # 5 second safety timeout
            
            # Show refreshing status
            self.show_refresh_status("در حال بروزرسانی...", "#f59e0b")
            print(f"DEBUG: refresh_data called at {datetime.now()}")
            
            # Load latest data using data service
            if not hasattr(self, 'data_service'):
                print("DEBUG: data_service not available")
                return
                
            print(f"DEBUG: About to call data_service.get_latest_report()")
            report_data = self.data_service.get_latest_report()
            print(f"DEBUG: report_data received: {type(report_data)}")
            
            if report_data:
                print(f"DEBUG: report_data keys: {list(report_data.keys()) if report_data else 'None'}")
                print(f"DEBUG: managers count: {len(report_data.get('managers', []))}")
                print(f"DEBUG: employees count: {len(report_data.get('employees', []))}")
                print(f"DEBUG: shifts data: {report_data.get('shifts', {})}")
                
                # Try to update dashboard step by step
                try:
                    if hasattr(self, 'dashboard'):
                        print(f"DEBUG: About to update dashboard")
                        self.dashboard.update_dashboard(report_data)
                        print(f"DEBUG: Dashboard updated successfully")
                        self.show_refresh_status("بروزرسانی شد", "#10b981")
                    else:
                        print("DEBUG: Dashboard not available")
                except Exception as dashboard_error:
                    print(f"DEBUG: Error updating dashboard: {dashboard_error}")
                    import traceback
                    traceback.print_exc()
                    
                    # Try to show a simplified update if the full dashboard fails
                    try:
                        print(f"DEBUG: Attempting simplified update")
                        self._show_simplified_update(report_data)
                        self.show_refresh_status("بروزرسانی ساده", "#f59e0b")
                    except Exception as simple_error:
                        print(f"DEBUG: Simplified update also failed: {simple_error}")
                        self.show_refresh_status("خطا در بروزرسانی", "#ef4444")
            else:
                print("DEBUG: No report data received")
                self.show_refresh_status("داده‌ای یافت نشد", "#f59e0b")
                
        except Exception as e:
            print(f"DEBUG: Error in refresh_data: {e}")
            import traceback
            traceback.print_exc()
            self.show_refresh_status("خطا در بروزرسانی", "#ef4444")
        finally:
            # Update last update time
            if hasattr(self, 'last_update_time'):
                self.last_update_time = datetime.now()
            
            # Re-enable refresh after a short delay for sync operations
            QTimer.singleShot(1000, self._enable_refresh)
    
    def _show_simplified_update(self, report_data: dict):
        """Show a simplified update when the full dashboard update fails."""
        try:
            print(f"DEBUG: _show_simplified_update called")
            
            # Just update the status to show we have data
            if 'managers' in report_data:
                manager_count = len(report_data['managers'])
                print(f"DEBUG: Simplified update - {manager_count} managers available")
            
            if 'employees' in report_data:
                employee_count = len(report_data['employees'])
                print(f"DEBUG: Simplified update - {employee_count} employees available")
                
            print(f"DEBUG: Simplified update completed")
            
        except Exception as e:
            print(f"DEBUG: Error in simplified update: {e}")
            import traceback
            traceback.print_exc()
    
    def force_sync_complete(self):
        """Force complete the sync process if it's stuck."""
        try:
            print("DEBUG: Force completing sync process")
            
            # Force enable refresh
            if hasattr(self, '_refresh_enabled'):
                self._refresh_enabled = True
            
            # Stop safety timer
            if hasattr(self, 'safety_timer'):
                self.safety_timer.stop()
            
            # Update status
            self.show_refresh_status("همگام‌سازی کامل", "#10b981")
            
            # Reset to ready state after 2 seconds
            QTimer.singleShot(2000, lambda: self.show_refresh_status("آماده", "#10b981"))
            
        except Exception as e:
            print(f"Error force completing sync: {e}")
    
    def on_sync_triggered(self):
        """Handle sync trigger from file system."""
        try:
            print("DEBUG: Sync triggered from file system")
            print(f"DEBUG: Current _refresh_enabled: {getattr(self, '_refresh_enabled', 'Not set')}")
            
            # Force immediate refresh for better responsiveness
            self._refresh_enabled = True
            
            # Ensure we're on the main thread for Qt operations
            if hasattr(self, 'sync_timer'):
                self.sync_timer.stop()
            
            # Use QTimer.singleShot to ensure execution on main thread
            self.sync_timer = QTimer()
            self.sync_timer.setSingleShot(True)
            self.sync_timer.timeout.connect(self._execute_sync_on_main_thread)
            self.sync_timer.start(50)  # Reduced delay for faster response
            
        except Exception as e:
            print(f"Error during sync setup: {e}")
            import traceback
            traceback.print_exc()
    
    def _execute_sync_on_main_thread(self):
        """Execute sync operations on the main thread."""
        try:
            print("DEBUG: Executing sync on main thread")
            
            # Show sync status
            self.show_refresh_status("همگام‌سازی...", "#8b5cf6")
            
            # Force enable refresh for sync operations
            if hasattr(self, '_refresh_enabled'):
                self._refresh_enabled = True
                print("DEBUG: _refresh_enabled set to True")
            
            # Stop safety timer if running
            if hasattr(self, 'safety_timer'):
                self.safety_timer.stop()
                print("DEBUG: Safety timer stopped")
            
            # Refresh data immediately
            print("DEBUG: About to call refresh_data()")
            self.refresh_data()
            print("DEBUG: refresh_data() completed")
            
            # Set a timeout to force complete sync if it takes too long
            QTimer.singleShot(10000, self.force_sync_complete)  # 10 second timeout
            
        except Exception as e:
            print(f"Error during sync execution: {e}")
            import traceback
            traceback.print_exc()
            self.show_refresh_status("خطا در همگام‌سازی", "#ef4444")
            # Force complete on error
            QTimer.singleShot(2000, self.force_sync_complete)
    
    def keyPressEvent(self, event):
        """Handle key press events."""
        # ESC key to exit full screen
        if event.key() == Qt.Key_Escape:
            self.toggle_fullscreen()
        # F11 to toggle full screen
        elif event.key() == Qt.Key_F11:
            self.toggle_fullscreen()
        # Ctrl+Q to quit
        elif event.key() == Qt.Key_Q and event.modifiers() == Qt.ControlModifier:
            self.close()
        # Arrow keys for scrolling
        elif event.key() == Qt.Key_Up:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().value() - 50
                )
        elif event.key() == Qt.Key_Down:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().value() + 50
                )
        elif event.key() == Qt.Key_Left:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.horizontalScrollBar().setValue(
                    self.scroll_area.horizontalScrollBar().value() - 50
                )
        elif event.key() == Qt.Key_Right:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.horizontalScrollBar().setValue(
                    self.scroll_area.horizontalScrollBar().value() + 50
                )
        # Page Up/Down for faster scrolling
        elif event.key() == Qt.Key_PageUp:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().value() - 200
                )
        elif event.key() == Qt.Key_PageDown:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().value() + 200
                )
        # Home/End for quick navigation
        elif event.key() == Qt.Key_Home:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(0)
        elif event.key() == Qt.Key_End:
            if hasattr(self, 'scroll_area'):
                self.scroll_area.verticalScrollBar().setValue(
                    self.scroll_area.verticalScrollBar().maximum()
                )
        else:
            super().keyPressEvent(event)
    
    def closeEvent(self, event):
        """Handle window close event."""
        try:
            self.cleanup()
            event.accept()
        except Exception as e:
            print(f"Error during cleanup: {e}")
            event.accept()
    
    def cleanup(self):
        """Clean up resources to prevent memory leaks."""
        try:
            # Stop all timers
            if hasattr(self, 'refresh_timer'):
                self.refresh_timer.stop()
                self.refresh_timer.deleteLater()
            
            if hasattr(self, 'countdown_timer'):
                self.countdown_timer.stop()
                self.countdown_timer.deleteLater()
            
            if hasattr(self, 'memory_cleanup_timer'):
                self.memory_cleanup_timer.stop()
                self.memory_cleanup_timer.deleteLater()
            
            if hasattr(self, 'safety_timer'):
                self.safety_timer.stop()
                self.safety_timer.deleteLater()
            
            if hasattr(self, 'sync_timer'):
                self.sync_timer.stop()
                self.sync_timer.deleteLater()
            
            # Clean up services
            if hasattr(self, 'chart_service'):
                self.chart_service.cleanup_charts()
            
            if hasattr(self, 'sync_manager'):
                self.sync_manager.stop_sync()
            
            # Clear references
            if hasattr(self, 'dashboard'):
                self.dashboard.deleteLater()
            
            print("Cleanup completed successfully")
            
        except Exception as e:
            print(f"Error during cleanup: {e}")
    
    def __del__(self):
        """Destructor to ensure cleanup."""
        try:
            self.cleanup()
        except:
            pass  # Ignore errors during destruction

def main():
    """Main entry point for the display application."""
    try:
        # Create application
        app = QApplication(sys.argv)
        app.setApplicationName("Employee Shift Display System")
        app.setApplicationVersion("1.0.0")
        
        # Create and show main window
        main_window = DisplayMainWindow()
        main_window.show()
        
        # Start event loop
        sys.exit(app.exec_())
        
    except Exception as e:
        print(f"Failed to start Display Application: {e}")
        sys.exit(1)

if __name__ == "__main__":
    main()
