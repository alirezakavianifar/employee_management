"""
AI Service for Display Application.

Provides Persian insights and recommendations based on business rules.
"""

import logging
from typing import Dict, Any, List
from datetime import datetime, timedelta
from shared.ai_rules import AIRulesEngine

class AIService:
    """Service for AI-powered insights and recommendations."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self.ai_engine = AIRulesEngine()
        
    def get_shift_insights(self, report_data: Dict[str, Any]) -> List[str]:
        """Get insights about current shift assignments."""
        try:
            insights = []
            shifts = report_data.get('shifts', {})
            settings = report_data.get('settings', {})
            
            morning_count = len(shifts.get('morning', []))
            evening_count = len(shifts.get('evening', []))
            morning_capacity = settings.get('morning_capacity', 10)
            evening_capacity = settings.get('evening_capacity', 10)
            
            # Morning shift insights
            if morning_count < morning_capacity * 0.7:
                insights.append("شیفت صبح کم‌کار است - نیاز به نیروی بیشتر")
            elif morning_count > morning_capacity * 1.1:
                insights.append("شیفت صبح پرکار است - امکان کاهش نیرو")
            
            # Evening shift insights
            if evening_count < evening_capacity * 0.7:
                insights.append("شیفت عصر کم‌کار است - نیاز به نیروی بیشتر")
            elif evening_count > evening_capacity * 1.1:
                insights.append("شیفت عصر پرکار است - امکان کاهش نیرو")
            
            # Balance insights
            if abs(morning_count - evening_count) > 3:
                insights.append("عدم تعادل بین شیفت‌ها - نیاز به تنظیم مجدد")
            
            return insights
            
        except Exception as e:
            self.logger.error(f"Error getting shift insights: {e}")
            return ["خطا در تحلیل شیفت‌ها"]
    
    def get_absence_insights(self, report_data: Dict[str, Any]) -> List[str]:
        """Get insights about absence patterns."""
        try:
            insights = []
            absences = report_data.get('absences', {})
            
            leave_count = len(absences.get('مرخصی', []))
            sick_count = len(absences.get('بیمار', []))
            absent_count = len(absences.get('غایب', []))
            total_absences = leave_count + sick_count + absent_count
            
            shifts = report_data.get('shifts', {})
            total_assigned = len(shifts.get('morning', [])) + len(shifts.get('evening', []))
            
            if total_assigned > 0:
                absence_rate = total_absences / total_assigned
                
                if absence_rate > 0.3:
                    insights.append("نرخ غیبت بالا - بررسی علل ضروری است")
                elif absence_rate > 0.2:
                    insights.append("نرخ غیبت متوسط - نیاز به توجه")
                elif absence_rate < 0.1:
                    insights.append("نرخ غیبت پایین - وضعیت مطلوب")
            
            # Specific absence type insights
            if sick_count > leave_count:
                insights.append("بیماری بیشتر از مرخصی - بررسی سلامت تیم")
            
            if absent_count > 0:
                insights.append(f"{absent_count} نفر غایب - نیاز به پیگیری")
            
            return insights
            
        except Exception as e:
            self.logger.error(f"Error getting absence insights: {e}")
            return ["خطا در تحلیل غیبت‌ها"]
    
    def get_capacity_recommendations(self, report_data: Dict[str, Any]) -> List[str]:
        """Get capacity-based recommendations using AI rules."""
        try:
            insights = []
            settings = report_data.get('settings', {})
            performance = report_data.get('performance', {})
            
            current_capacity = settings.get('morning_capacity', 10) + settings.get('evening_capacity', 10)
            
            # Get real task data from report instead of mock data
            tasks_data = report_data.get('tasks', {})
            print(f"DEBUG: Tasks data received: {tasks_data}")
            
            if tasks_data and 'tasks' in tasks_data and tasks_data['tasks']:
                print(f"DEBUG: Found {len(tasks_data['tasks'])} tasks for AI analysis")
                # Convert tasks to orders format for AI analysis
                from shared.ai_rules import AIRulesEngine
                ai_engine = AIRulesEngine()
                
                # Get current week
                current_week = ai_engine.get_week_number()
                next_week = current_week + 1
                two_weeks = current_week + 2
                
                # Calculate total hours for next weeks
                next_week_hours = 0
                two_weeks_hours = 0
                
                for task_id, task in tasks_data['tasks'].items():
                    print(f"DEBUG: Analyzing task {task_id}: status={task.get('status')}, target_date={task.get('target_date')}, hours={task.get('estimated_hours')}")
                    if task.get('status') == 'در انتظار':  # Only pending tasks count as future orders
                        try:
                            task_week = ai_engine.get_week_number(task.get('target_date', ''))
                            print(f"DEBUG: Task {task_id} week: {task_week}")
                            if task_week == next_week:
                                next_week_hours += task.get('estimated_hours', 0)
                                print(f"DEBUG: Added {task.get('estimated_hours', 0)} hours to next week")
                            elif task_week == two_weeks:
                                two_weeks_hours += task.get('estimated_hours', 0)
                                print(f"DEBUG: Added {task.get('estimated_hours', 0)} hours to two weeks")
                        except Exception as e:
                            print(f"DEBUG: Error processing task {task_id}: {e}")
                            continue
                
                print(f"DEBUG: Total hours - Next week: {next_week_hours}, Two weeks: {two_weeks_hours}")
                
                # Create orders data for AI analysis
                orders_data = [
                    {'week': next_week, 'quantity': next_week_hours},
                    {'week': two_weeks, 'quantity': two_weeks_hours}
                ]
                
                # Use the AI rules engine
                capacity_insight = ai_engine.analyze_capacity_vs_orders(current_capacity, orders_data)
                insights.append(f"📊 تحلیل بر اساس وظایف واقعی: {capacity_insight}")
                print(f"DEBUG: AI insight based on real tasks: {capacity_insight}")
            else:
                print(f"DEBUG: No tasks available, using fallback data")
                # Fallback to mock data if no tasks available
                orders_data = [
                    {'week': self._get_current_week() + 1, 'quantity': current_capacity - 2},
                    {'week': self._get_current_week() + 2, 'quantity': current_capacity + 3}
                ]
                
                # Use the AI rules engine
                capacity_insight = self.ai_engine.analyze_capacity_vs_orders(current_capacity, orders_data)
                insights.append(f"⚠️ تحلیل با داده‌های نمونه: {capacity_insight}")
                print(f"DEBUG: AI insight based on fallback data: {capacity_insight}")
            
            # Task progress analysis
            if tasks_data and 'tasks' in tasks_data and tasks_data['tasks']:
                total_tasks = len(tasks_data['tasks'])
                completed_tasks = sum(1 for task in tasks_data['tasks'].values() if task.get('status') == 'تکمیل شده')
                in_progress_tasks = sum(1 for task in tasks_data['tasks'].values() if task.get('status') == 'در حال انجام')
                pending_tasks = sum(1 for task in tasks_data['tasks'].values() if task.get('status') == 'در انتظار')
                
                if total_tasks > 0:
                    completion_rate = (completed_tasks / total_tasks) * 100
                    insights.append(f"📈 پیشرفت وظایف: {completion_rate:.0f}% تکمیل شده ({completed_tasks}/{total_tasks})")
                    
                    if in_progress_tasks > 0:
                        insights.append(f"🔄 در حال انجام: {in_progress_tasks} وظیفه")
                    
                    if pending_tasks > 0:
                        insights.append(f"⏳ در انتظار: {pending_tasks} وظیفه")
                    
                    # Performance recommendations based on task progress
                    if completion_rate < 30:
                        insights.append("⚠️ نرخ تکمیل پایین - نیاز به بررسی و بهینه‌سازی")
                    elif completion_rate > 80:
                        insights.append("✅ نرخ تکمیل عالی - عملکرد مطلوب")
            
            # Performance-based insights
            current_week = performance.get('current_week', 0)
            previous_week = performance.get('previous_week', 0)
            
            if current_week > 0 and previous_week > 0:
                change_percentage = ((current_week - previous_week) / previous_week) * 100
                
                if change_percentage > 20:
                    insights.append(f"افزایش {change_percentage:.0f}% عملکرد - نیاز به اضافه‌کاری")
                elif change_percentage < -20:
                    insights.append(f"کاهش {abs(change_percentage):.0f}% عملکرد - بررسی علل")
                else:
                    insights.append("عملکرد پایدار - وضعیت عادی")
            
            return insights
            
        except Exception as e:
            self.logger.error(f"Error getting capacity recommendations: {e}")
            return ["خطا در تحلیل ظرفیت"]
    
    def get_general_recommendations(self, report_data: Dict[str, Any]) -> List[str]:
        """Get general business recommendations."""
        try:
            recommendations = []
            
            # Time-based recommendations
            current_hour = datetime.now().hour
            if 8 <= current_hour <= 10:
                recommendations.append("ساعات اوج کاری - نظارت بیشتر بر شیفت صبح")
            elif 16 <= current_hour <= 18:
                recommendations.append("ساعات اوج کاری - نظارت بیشتر بر شیفت عصر")
            
            # Day-based recommendations
            current_weekday = datetime.now().weekday()
            if current_weekday == 4:  # Friday
                recommendations.append("آخر هفته - برنامه‌ریزی برای هفته آینده")
            elif current_weekday == 0:  # Monday
                recommendations.append("شروع هفته - بررسی برنامه‌های هفته")
            
            # Data quality recommendations
            if not report_data.get('managers'):
                recommendations.append("اطلاعات مدیران تکمیل نشده - نیاز به ورود داده")
            
            if not report_data.get('shifts', {}).get('morning') and not report_data.get('shifts', {}).get('evening'):
                recommendations.append("شیفت‌ها تنظیم نشده - نیاز به برنامه‌ریزی")
            
            return recommendations
            
        except Exception as e:
            self.logger.error(f"Error getting general recommendations: {e}")
            return ["خطا در تحلیل عمومی"]
    
    def get_all_insights(self, report_data: Dict[str, Any]) -> Dict[str, List[str]]:
        """Get all types of insights and recommendations."""
        try:
            return {
                'shifts': self.get_shift_insights(report_data),
                'absences': self.get_absence_insights(report_data),
                'capacity': self.get_capacity_recommendations(report_data),
                'general': self.get_general_recommendations(report_data)
            }
        except Exception as e:
            self.logger.error(f"Error getting all insights: {e}")
            return {
                'shifts': ["خطا در تحلیل"],
                'absences': ["خطا در تحلیل"],
                'capacity': ["خطا در تحلیل"],
                'general': ["خطا در تحلیل"]
            }
    
    def generate_advice(self, shift_data: Dict[str, Any], absence_data: Dict[str, Any], capacity: int, full_data: Dict[str, Any] = None) -> str:
        """Generate comprehensive AI advice based on shift and absence data."""
        try:
            advice_parts = []
            
            # Get shift insights
            shift_insights = self.get_shift_insights({
                'shifts': shift_data,
                'settings': {'morning_capacity': capacity, 'evening_capacity': capacity}
            })
            
            # Get absence insights
            absence_insights = self.get_absence_insights({
                'shifts': shift_data,
                'absences': absence_data
            })
            
            # Get capacity recommendations using AI rules with full data if available
            if full_data:
                capacity_recommendations = self.get_capacity_recommendations(full_data)
            else:
                capacity_recommendations = self.get_capacity_recommendations({
                    'settings': {'morning_capacity': capacity, 'evening_capacity': capacity}
                })
            
            # Combine all insights
            all_insights = shift_insights + absence_insights + capacity_recommendations
            
            # Take the most important insights (limit to 3 for display)
            important_insights = all_insights[:3]
            
            if important_insights:
                advice_parts.extend(important_insights)
            else:
                advice_parts.append("وضعیت عادی - ظرفیت کافی موجود است")
            
            # Join insights with line breaks
            return "\n".join(advice_parts)
            
        except Exception as e:
            self.logger.error(f"Error generating AI advice: {e}")
            return "خطا در تحلیل داده‌ها"
    
    def _get_current_week(self) -> int:
        """Get current ISO week number."""
        return datetime.now().isocalendar()[1]
