#!/usr/bin/env python3
"""
Fullscreen Transition Test

This script tests the fullscreen transition behavior to ensure
that the layout doesn't change unexpectedly when toggling fullscreen mode.

Usage:
    python fullscreen_test.py
"""

import sys
import os
from PyQt5.QtWidgets import QApplication, QMainWindow, QVBoxLayout, QWidget, QLabel, QPushButton, QHBoxLayout
from PyQt5.QtCore import Qt, QTimer
from PyQt5.QtGui import QFont

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))))

from display_app.views.main_window import DisplayMainWindow

class FullscreenTestWindow(QMainWindow):
    """Test window to verify fullscreen behavior."""
    
    def __init__(self):
        super().__init__()
        self.setup_ui()
        self.display_app = None
    
    def setup_ui(self):
        """Setup the test UI."""
        self.setWindowTitle("Fullscreen Transition Test")
        self.setGeometry(100, 100, 800, 600)
        
        # Central widget
        central_widget = QWidget()
        self.setCentralWidget(central_widget)
        
        # Main layout
        layout = QVBoxLayout()
        layout.setSpacing(20)
        layout.setContentsMargins(20, 20, 20, 20)
        
        # Title
        title = QLabel("Fullscreen Transition Test")
        title.setFont(QFont("Tahoma", 20, QFont.Bold))
        title.setAlignment(Qt.AlignCenter)
        title.setStyleSheet("color: #1e3a8a; margin-bottom: 20px;")
        layout.addWidget(title)
        
        # Description
        description = QLabel("""
        This test verifies that the Display App layout remains stable when toggling fullscreen mode.
        
        Expected behavior:
        • Layout should NOT change when entering/exiting fullscreen
        • All panels should maintain their positions and sizes
        • No unexpected view changes should occur
        
        Test steps:
        1. Launch the Display App
        2. Toggle fullscreen mode (F11 or ESC)
        3. Verify layout remains stable
        4. Exit fullscreen and verify layout is still stable
        """)
        description.setFont(QFont("Tahoma", 12))
        description.setAlignment(Qt.AlignLeft)
        description.setWordWrap(True)
        description.setStyleSheet("color: #374151; background: #f3f4f6; padding: 20px; border-radius: 10px;")
        layout.addWidget(description)
        
        # Control buttons
        button_layout = QHBoxLayout()
        button_layout.setSpacing(15)
        
        # Launch Display App button
        launch_btn = QPushButton("Launch Display App")
        launch_btn.setFont(QFont("Tahoma", 12, QFont.Bold))
        launch_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #10b981, stop:1 #059669);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #34d399, stop:1 #10b981);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #059669, stop:1 #047857);
            }
        """)
        launch_btn.clicked.connect(self.launch_display_app)
        button_layout.addWidget(launch_btn)
        
        # Test fullscreen button
        test_btn = QPushButton("Test Fullscreen Toggle")
        test_btn.setFont(QFont("Tahoma", 12, QFont.Bold))
        test_btn.setStyleSheet("""
            QPushButton {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #3b82f6, stop:1 #2563eb);
                color: white;
                border: none;
                border-radius: 8px;
                padding: 12px 24px;
                font-weight: bold;
            }
            QPushButton:hover {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #60a5fa, stop:1 #3b82f6);
            }
            QPushButton:pressed {
                background: qlineargradient(x1:0, y1:0, x2:0, y2:1,
                    stop:0 #2563eb, stop:1 #1d4ed8);
            }
        """)
        test_btn.clicked.connect(self.test_fullscreen_toggle)
        button_layout.addWidget(test_btn)
        
        layout.addLayout(button_layout)
        
        # Status display
        self.status_label = QLabel("Ready to test fullscreen behavior")
        self.status_label.setFont(QFont("Tahoma", 11))
        self.status_label.setAlignment(Qt.AlignCenter)
        self.status_label.setStyleSheet("color: #6b7280; background: #f9fafb; padding: 15px; border-radius: 8px; border: 1px solid #e5e7eb;")
        layout.addWidget(self.status_label)
        
        # Add stretch
        layout.addStretch()
        
        central_widget.setLayout(layout)
    
    def launch_display_app(self):
        """Launch the actual display app."""
        try:
            print("Launching Display App for fullscreen test...")
            self.status_label.setText("Display App launched - Test fullscreen toggle now")
            
            # Create and show display app window
            self.display_app = DisplayMainWindow()
            self.display_app.show()
            
            print("Display App launched successfully!")
            print("Test instructions:")
            print("1. Press F11 or ESC to toggle fullscreen")
            print("2. Verify that the layout doesn't change")
            print("3. Toggle back to windowed mode")
            print("4. Verify layout remains stable")
            
        except Exception as e:
            print(f"Error launching display app: {e}")
            import traceback
            traceback.print_exc()
            self.status_label.setText("Error launching Display App")
    
    def test_fullscreen_toggle(self):
        """Test fullscreen toggle functionality."""
        try:
            if self.display_app:
                print("Testing fullscreen toggle...")
                self.status_label.setText("Testing fullscreen toggle...")
                
                # Toggle fullscreen
                self.display_app.toggle_fullscreen()
                
                # Update status after a short delay
                QTimer.singleShot(1000, self.update_test_status)
                
            else:
                self.status_label.setText("Please launch Display App first")
                
        except Exception as e:
            print(f"Error testing fullscreen toggle: {e}")
            self.status_label.setText("Error during fullscreen test")
    
    def update_test_status(self):
        """Update test status after fullscreen toggle."""
        try:
            if self.display_app:
                if self.display_app.isFullScreen():
                    self.status_label.setText("Fullscreen mode active - Layout should be stable")
                else:
                    self.status_label.setText("Windowed mode active - Layout should be stable")
            else:
                self.status_label.setText("Display App not available")
                
        except Exception as e:
            print(f"Error updating test status: {e}")

def main():
    """Main entry point for the fullscreen test."""
    try:
        # Create application
        app = QApplication(sys.argv)
        app.setApplicationName("Fullscreen Transition Test")
        app.setApplicationVersion("1.0.0")
        
        # Create and show test window
        test_window = FullscreenTestWindow()
        test_window.show()
        
        print("Fullscreen Transition Test started!")
        print("This test verifies that the Display App layout remains stable during fullscreen transitions.")
        
        # Start event loop
        sys.exit(app.exec_())
        
    except Exception as e:
        print(f"Failed to start Fullscreen Test: {e}")
        import traceback
        traceback.print_exc()
        sys.exit(1)

if __name__ == "__main__":
    main()
