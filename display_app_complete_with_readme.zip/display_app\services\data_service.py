"""
Data Service for Display Application.

Handles data reading, processing, and caching for the dashboard display.
"""

import os
import json
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
from pathlib import Path

class DataService:
    """Service for managing data operations in the display application."""
    
    def __init__(self, data_dir: str = "data"):
        self.data_dir = Path(data_dir)
        self.reports_dir = self.data_dir / "reports"
        self.images_dir = self.data_dir / "images" / "staff"
        self.logs_dir = self.data_dir / "logs"
        
        # Ensure directories exist
        self.reports_dir.mkdir(parents=True, exist_ok=True)
        self.images_dir.mkdir(parents=True, exist_ok=True)
        self.logs_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Cache for performance
        self._cache = {}
        self._cache_timeout = 30  # seconds
        
    def get_today_report(self) -> Optional[Dict[str, Any]]:
        """Get today's report data, fallback to latest available report."""
        try:
            today = datetime.now().strftime("%Y-%m-%d")
            filename = f"report_{today}.json"
            filepath = self.reports_dir / filename
            
            if filepath.exists():
                with open(filepath, 'r', encoding='utf-8') as f:
                    data = json.load(f)
                    self.logger.info(f"Loaded today's report: {filename}")
                    return data
            else:
                self.logger.warning(f"Today's report not found: {filename}, trying latest report")
                # Fallback to latest available report
                return self.get_latest_report()
                
        except Exception as e:
            self.logger.error(f"Error loading today's report: {e}")
            return self._get_default_report()
    
    def get_latest_report(self) -> Optional[Dict[str, Any]]:
        """Get the most recent report available."""
        try:
            print(f"DEBUG: get_latest_report called, data_dir: {self.data_dir}")
            print(f"DEBUG: reports_dir: {self.reports_dir}")
            print(f"DEBUG: reports_dir exists: {self.reports_dir.exists()}")
            
            # Find all report files
            report_files = list(self.reports_dir.glob("report_*.json"))
            print(f"DEBUG: Found report files: {[f.name for f in report_files]}")
            
            if not report_files:
                print(f"DEBUG: No report files found, returning default")
                return self._get_default_report()
            
            # Sort by modification time (newest first)
            latest_file = max(report_files, key=lambda x: x.stat().st_mtime)
            print(f"DEBUG: Latest file: {latest_file.name}")
            print(f"DEBUG: Latest file exists: {latest_file.exists()}")
            
            with open(latest_file, 'r', encoding='utf-8') as f:
                data = json.load(f)
                print(f"DEBUG: Successfully loaded data from {latest_file.name}")
                print(f"DEBUG: Data keys: {list(data.keys()) if data else 'None'}")
                self.logger.info(f"Loaded latest report: {latest_file.name}")
                return data
                
        except Exception as e:
            print(f"DEBUG: Error in get_latest_report: {e}")
            import traceback
            traceback.print_exc()
            self.logger.error(f"Error loading latest report: {e}")
            return self._get_default_report()
    
    def get_employee_photo_path(self, employee_id: str) -> Optional[str]:
        """Get the photo path for an employee."""
        try:
            # Check for common image extensions
            for ext in ['.jpg', '.jpeg', '.png']:
                photo_path = self.images_dir / f"{employee_id}{ext}"
                if photo_path.exists():
                    return str(photo_path)
            
            # If no photo found, return None
            return None
            
        except Exception as e:
            self.logger.error(f"Error getting photo path for employee {employee_id}: {e}")
            return None
    
    def get_absence_summary(self, report_data: Dict[str, Any]) -> Dict[str, int]:
        """Get summary of absences from report data."""
        try:
            absence_data = report_data.get('absences', {})
            
            summary = {
                'مرخصی': len(absence_data.get('مرخصی', [])),
                'بیمار': len(absence_data.get('بیمار', [])),
                'غایب': len(absence_data.get('غایب', []))
            }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting absence summary: {e}")
            return {'مرخصی': 0, 'بیمار': 0, 'غایب': 0}
    
    def get_shift_summary(self, report_data: Dict[str, Any]) -> Dict[str, Any]:
        """Get summary of shift assignments."""
        try:
            shifts = report_data.get('shifts', {})
            
            summary = {
                'morning': {
                    'count': len(shifts.get('morning', [])),
                    'capacity': report_data.get('settings', {}).get('morning_capacity', 10)
                },
                'evening': {
                    'count': len(shifts.get('evening', [])),
                    'capacity': report_data.get('settings', {}).get('evening_capacity', 10)
                }
            }
            
            return summary
            
        except Exception as e:
            self.logger.error(f"Error getting shift summary: {e}")
            return {
                'morning': {'count': 0, 'capacity': 10},
                'evening': {'count': 0, 'capacity': 10}
            }
    
    def get_managers_data(self, report_data: Dict[str, Any]) -> List[Dict[str, Any]]:
        """Get managers data for display."""
        try:
            managers = report_data.get('managers', [])
            
            # Ensure we only show 3 managers as per specs
            managers = managers[:3]
            
            # Add photo paths
            for manager in managers:
                if 'id' in manager:
                    photo_path = self.get_employee_photo_path(manager['id'])
                    if photo_path:
                        manager['photo_path'] = photo_path
                    else:
                        manager['photo_path'] = None
            
            return managers
            
        except Exception as e:
            self.logger.error(f"Error getting managers data: {e}")
            return []
    
    def _get_default_report(self) -> Dict[str, Any]:
        """Get default report structure when no data is available."""
        return {
            "date": datetime.now().strftime("%Y-%m-%d"),
            "managers": [],
            "shifts": {
                "morning": [],
                "evening": []
            },
            "absences": {
                "مرخصی": [],
                "بیمار": [],
                "غایب": []
            },
            "tasks": {
                "tasks": {},
                "next_task_id": 1
            },
            "settings": {
                "shift_capacity": 10,
                "morning_capacity": 10,
                "evening_capacity": 10
            },
            "performance": {
                "current_week": 0,
                "previous_week": 0
            }
        }
    
    def get_weekly_productivity_data(self, week_number: int = None) -> Dict[str, Any]:
        """Get weekly productivity data for a specific week."""
        try:
            if week_number is None:
                from datetime import datetime
                week_number = datetime.now().isocalendar()[1]
            
            # For now, return simulated data
            # In a real system, this would aggregate data from the entire week
            return {
                'week': week_number,
                'morning': {
                    'boxes_w': 120,
                    'wh_w': 56,
                    'productivity_w': 2.14
                },
                'evening': {
                    'boxes_w': 98,
                    'wh_w': 48,
                    'productivity_w': 2.04
                },
                'target': 2.0
            }
            
        except Exception as e:
            self.logger.error(f"Error getting weekly productivity data: {e}")
            return {
                'week': week_number or 1,
                'morning': {'boxes_w': 0, 'wh_w': 0, 'productivity_w': 0},
                'evening': {'boxes_w': 0, 'wh_w': 0, 'productivity_w': 0},
                'target': 2.0
            }
    
    def clear_cache(self):
        """Clear the data cache."""
        self._cache.clear()
        self.logger.info("Data cache cleared")
