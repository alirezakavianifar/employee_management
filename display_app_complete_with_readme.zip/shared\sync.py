import os
import time
import threading
from typing import Callable, Optional
from watchdog.observers import Observer
from watchdog.events import FileSystemEventHandler
import logging

class SharedFolderMonitor(FileSystemEventHandler):
    """Monitors shared folder for changes and triggers sync."""
    
    def __init__(self, data_dir: str, callback: Callable[[], None]):
        self.data_dir = data_dir
        self.callback = callback
        self.observer = None
        self.is_running = False
        self.last_modified = {}
        
        # Setup logging
        logging.basicConfig(
            filename=os.path.join(data_dir, "logs", "sync.log"),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
    
    def on_modified(self, event):
        """Handle file modification events."""
        if event.is_directory:
            return
        
        if not event.src_path.endswith('.json'):
            return
        
        # Check if this is a real modification (not just a backup)
        if 'backup' in event.src_path:
            return
        
        # Debounce rapid modifications (reduced from 1.0 to 0.5 seconds for better responsiveness)
        current_time = time.time()
        if event.src_path in self.last_modified:
            if current_time - self.last_modified[event.src_path] < 0.5:  # 0.5 second debounce
                return
        
        self.last_modified[event.src_path] = current_time
        
        logging.info(f"File modified: {event.src_path}")
        print(f"DEBUG: File modification detected: {event.src_path}")
        
        # Trigger callback in main thread
        if self.callback:
            print(f"DEBUG: Triggering sync callback for: {event.src_path}")
            self.callback()
    
    def on_created(self, event):
        """Handle file creation events."""
        if event.is_directory:
            return
        
        if not event.src_path.endswith('.json'):
            return
        
        logging.info(f"File created: {event.src_path}")
        
        if self.callback:
            self.callback()
    
    def on_deleted(self, event):
        """Handle file deletion events."""
        if event.is_directory:
            return
        
        if not event.src_path.endswith('.json'):
            return
        
        logging.info(f"File deleted: {event.src_path}")
        
        if self.callback:
            self.callback()
    
    def start_monitoring(self):
        """Start monitoring the shared folder."""
        if self.is_running:
            return
        
        try:
            self.observer = Observer()
            self.observer.schedule(self, self.data_dir, recursive=True)
            self.observer.start()
            self.is_running = True
            logging.info(f"Started monitoring: {self.data_dir}")
        except Exception as e:
            logging.error(f"Failed to start monitoring: {e}")
    
    def stop_monitoring(self):
        """Stop monitoring the shared folder."""
        if not self.is_running:
            return
        
        try:
            if self.observer:
                self.observer.stop()
                self.observer.join()
            self.is_running = False
            logging.info("Stopped monitoring")
        except Exception as e:
            logging.error(f"Failed to stop monitoring: {e}")

class SyncManager:
    """Manages synchronization between applications."""
    
    def __init__(self, data_dir: str, sync_interval: int = 30):
        self.data_dir = data_dir
        self.sync_interval = sync_interval
        self.monitor = None
        self.sync_thread = None
        self.is_running = False
        self.callbacks = []
        
        # Setup logging
        logging.basicConfig(
            filename=os.path.join(data_dir, "logs", "sync_manager.log"),
            level=logging.INFO,
            format='%(asctime)s - %(levelname)s - %(message)s'
        )
    
    def add_sync_callback(self, callback: Callable[[], None]):
        """Add a callback to be executed when sync is needed."""
        self.callbacks.append(callback)
    
    def remove_sync_callback(self, callback: Callable[[], None]):
        """Remove a sync callback."""
        if callback in self.callbacks:
            self.callbacks.remove(callback)
    
    def _sync_callback(self):
        """Internal callback that triggers all registered callbacks."""
        try:
            logging.info("Sync callback triggered")
            print(f"DEBUG: Sync callback triggered, {len(self.callbacks)} callbacks registered")
            for i, callback in enumerate(self.callbacks):
                try:
                    print(f"DEBUG: Executing callback {i+1}")
                    # Execute callback directly - the DisplayApp will handle thread safety
                    callback()
                    print(f"DEBUG: Callback {i+1} executed successfully")
                except Exception as e:
                    logging.error(f"Error in sync callback {i+1}: {e}")
                    print(f"DEBUG: Error in sync callback {i+1}: {e}")
        except Exception as e:
            logging.error(f"Error in sync callback execution: {e}")
            print(f"DEBUG: Error in sync callback execution: {e}")
    
    def _sync_worker(self):
        """Background worker for periodic sync."""
        while self.is_running:
            try:
                time.sleep(self.sync_interval)
                if self.is_running:
                    logging.info("Periodic sync triggered")
                    self._sync_callback()
            except Exception as e:
                logging.error(f"Error in sync worker: {e}")
                # Add delay to prevent rapid error loops
                time.sleep(5)
    
    def start_sync(self):
        """Start synchronization."""
        if self.is_running:
            return
        
        try:
            # Start file monitoring
            self.monitor = SharedFolderMonitor(self.data_dir, self._sync_callback)
            self.monitor.start_monitoring()
            
            # Start periodic sync
            self.is_running = True
            self.sync_thread = threading.Thread(target=self._sync_worker, daemon=True)
            self.sync_thread.start()
            
            logging.info("Started synchronization")
        except Exception as e:
            logging.error(f"Failed to start sync: {e}")
    
    def stop_sync(self):
        """Stop synchronization."""
        if not self.is_running:
            return
        
        try:
            self.is_running = False
            
            if self.monitor:
                self.monitor.stop_monitoring()
            
            if self.sync_thread:
                self.sync_thread.join(timeout=5.0)
            
            logging.info("Stopped synchronization")
        except Exception as e:
            logging.error(f"Failed to stop sync: {e}")
    
    def force_sync(self):
        """Force an immediate sync."""
        logging.info("Forcing sync")
        self._sync_callback()
