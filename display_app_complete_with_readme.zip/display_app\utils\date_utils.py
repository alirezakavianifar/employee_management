"""
Date utilities for Display Application.

Handles Persian date operations, week calculations, and date formatting.
"""

import logging
from datetime import datetime, timedelta
from typing import Tuple, Optional
import locale

class DateUtils:
    """Utility class for date operations with Persian support."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._setup_persian_locale()
    
    def _setup_persian_locale(self):
        """Setup Persian locale for date formatting."""
        try:
            # Try to set Persian locale
            locale.setlocale(locale.LC_TIME, 'fa_IR.UTF-8')
            self.logger.info("Persian locale set successfully")
        except locale.Error:
            try:
                # Fallback to Persian locale
                locale.setlocale(locale.LC_TIME, 'fa_IR')
                self.logger.info("Persian locale set with fallback")
            except locale.Error:
                self.logger.warning("Could not set Persian locale, using default")
    
    def get_current_date(self) -> str:
        """Get current date in YYYY-MM-DD format."""
        return datetime.now().strftime("%Y-%m-%d")
    
    def get_current_week(self) -> int:
        """Get current ISO week number."""
        return datetime.now().isocalendar()[1]
    
    def get_current_year(self) -> int:
        """Get current year."""
        return datetime.now().year
    
    def get_week_range(self, week_number: int, year: int = None) -> Tuple[datetime, datetime]:
        """Get start and end dates for a specific week."""
        if year is None:
            year = datetime.now().year
        
        # Get January 1st of the year
        jan_1 = datetime(year, 1, 1)
        
        # Find the first Monday of the year
        days_since_monday = (jan_1.weekday() - 0) % 7
        first_monday = jan_1 - timedelta(days=days_since_monday)
        
        # Calculate the start of the target week
        week_start = first_monday + timedelta(weeks=week_number - 1)
        week_end = week_start + timedelta(days=6)
        
        return week_start, week_end
    
    def get_week_display_name(self, week_number: int) -> str:
        """Get Persian display name for week number."""
        return f"هفته {week_number}"
    
    def get_month_name(self, month: int) -> str:
        """Get Persian month name."""
        persian_months = {
            1: "فروردین", 2: "اردیبهشت", 3: "خرداد",
            4: "تیر", 5: "مرداد", 6: "شهریور",
            7: "مهر", 8: "آبان", 9: "آذر",
            10: "دی", 11: "بهمن", 12: "اسفند"
        }
        return persian_months.get(month, f"ماه {month}")
    
    def get_day_name(self, weekday: int) -> str:
        """Get Persian day name."""
        persian_days = {
            0: "دوشنبه", 1: "سه‌شنبه", 2: "چهارشنبه",
            3: "پنج‌شنبه", 4: "جمعه", 5: "شنبه", 6: "یکشنبه"
        }
        return persian_days.get(weekday, f"روز {weekday}")
    
    def get_time_period(self) -> str:
        """Get current time period (صبح، عصر، شب)."""
        current_hour = datetime.now().hour
        
        if 5 <= current_hour < 12:
            return "صبح"
        elif 12 <= current_hour < 17:
            return "عصر"
        else:
            return "شب"
    
    def is_workday(self, date: datetime = None) -> bool:
        """Check if a date is a workday (Saturday to Wednesday in Iran)."""
        if date is None:
            date = datetime.now()
        
        # In Iran, workdays are Saturday to Wednesday (weekday 5, 6, 0, 1, 2)
        return date.weekday() in [5, 6, 0, 1, 2]
    
    def get_workdays_in_week(self, week_number: int, year: int = None) -> int:
        """Get number of workdays in a specific week."""
        week_start, week_end = self.get_week_range(week_number, year)
        
        workdays = 0
        current_date = week_start
        
        while current_date <= week_end:
            if self.is_workday(current_date):
                workdays += 1
            current_date += timedelta(days=1)
        
        return workdays
    
    def format_date_for_display(self, date: datetime) -> str:
        """Format date for display with Persian text."""
        try:
            month_name = self.get_month_name(date.month)
            day_name = self.get_day_name(date.weekday())
            
            return f"{day_name} {date.day} {month_name} {date.year}"
        except Exception as e:
            self.logger.error(f"Error formatting date: {e}")
            return date.strftime("%Y-%m-%d")
    
    def get_relative_date_text(self, date: datetime) -> str:
        """Get relative date text (امروز، دیروز، etc.)."""
        today = datetime.now().date()
        target_date = date.date()
        
        if target_date == today:
            return "امروز"
        elif target_date == today - timedelta(days=1):
            return "دیروز"
        elif target_date == today + timedelta(days=1):
            return "فردا"
        else:
            days_diff = (target_date - today).days
            if days_diff > 0:
                return f"{days_diff} روز دیگر"
            else:
                return f"{abs(days_diff)} روز پیش"
    
    def parse_date_string(self, date_string: str) -> Optional[datetime]:
        """Parse date string in various formats."""
        formats = [
            "%Y-%m-%d",
            "%d/%m/%Y",
            "%d-%m-%Y",
            "%Y/%m/%d"
        ]
        
        for fmt in formats:
            try:
                return datetime.strptime(date_string, fmt)
            except ValueError:
                continue
        
        self.logger.warning(f"Could not parse date string: {date_string}")
        return None
    
    def get_date_range(self, start_date: str, end_date: str) -> list:
        """Get list of dates between start and end dates."""
        try:
            start = self.parse_date_string(start_date)
            end = self.parse_date_string(end_date)
            
            if not start or not end:
                return []
            
            date_list = []
            current = start
            
            while current <= end:
                date_list.append(current.strftime("%Y-%m-%d"))
                current += timedelta(days=1)
            
            return date_list
            
        except Exception as e:
            self.logger.error(f"Error getting date range: {e}")
            return []
