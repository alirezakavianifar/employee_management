import sys
import os
import logging
from PyQt5.QtWidgets import QApplication, QMessageBox
from PyQt5.QtCore import QTranslator, QLocale, Qt
from PyQt5.QtGui import QFont

# Add parent directory to path for imports
sys.path.insert(0, os.path.dirname(os.path.dirname(os.path.abspath(__file__))))

def get_data_directory():
    """Get the correct data directory path."""
    # If running as exe, look for data directory relative to exe location
    if getattr(sys, 'frozen', False):
        # Running as compiled exe
        exe_dir = os.path.dirname(sys.executable)
        data_dir = os.path.join(exe_dir, "data")
        
        # If data directory doesn't exist in exe location, try current working directory
        if not os.path.exists(data_dir):
            data_dir = os.path.join(os.getcwd(), "data")
        
        # If still doesn't exist, create it
        if not os.path.exists(data_dir):
            os.makedirs(data_dir, exist_ok=True)
            os.makedirs(os.path.join(data_dir, "logs"), exist_ok=True)
            os.makedirs(os.path.join(data_dir, "reports"), exist_ok=True)
            os.makedirs(os.path.join(data_dir, "images", "staff"), exist_ok=True)
    else:
        # Running as script - use shared data directory
        data_dir = "data"
    
    return data_dir

def setup_logging():
    """Setup logging configuration."""
    try:
        data_dir = get_data_directory()
        log_dir = os.path.join(data_dir, "logs")
        os.makedirs(log_dir, exist_ok=True)
        
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s',
            handlers=[
                logging.FileHandler(os.path.join(log_dir, "display_app.log"), encoding='utf-8'),
                logging.StreamHandler(sys.stdout)
            ]
        )
    except Exception as e:
        # Fallback to basic logging if file logging fails
        logging.basicConfig(
            level=logging.INFO,
            format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
        )
        logging.error(f"Failed to setup file logging: {e}")

def setup_fonts():
    """Setup Persian-compatible fonts."""
    app = QApplication.instance()
    if app:
        # Set Tahoma as the default font for better Persian text support
        font = QFont("Tahoma", 9)
        app.setFont(font)

def setup_rtl():
    """Setup Right-to-Left layout for Persian/Arabic interface."""
    app = QApplication.instance()
    if app:
        # Set RTL layout direction for Persian/Arabic interface
        app.setLayoutDirection(Qt.RightToLeft)
        # Set RTL locale
        locale = QLocale(QLocale.Persian, QLocale.Iran)
        QLocale.setDefault(locale)

def show_error_dialog(error_msg):
    """Show error dialog to user."""
    try:
        app = QApplication.instance()
        if app:
            msg_box = QMessageBox()
            msg_box.setIcon(QMessageBox.Critical)
            msg_box.setWindowTitle("Display App Error")
            msg_box.setText("Failed to start Display Application")
            msg_box.setDetailedText(error_msg)
            msg_box.setStandardButtons(QMessageBox.Ok)
            msg_box.exec_()
    except Exception as e:
        print(f"Failed to show error dialog: {e}")

def main():
    """Main entry point for the display application."""
    try:
        # Setup logging first
        setup_logging()
        logging.info("Starting Display Application")
        
        # Create application
        app = QApplication(sys.argv)
        app.setApplicationName("سیستم نمایش شیفت کارمندان")
        app.setApplicationVersion("1.0.0")
        
        # Setup fonts
        setup_fonts()
        
        # Setup RTL layout
        setup_rtl()
        
        # Import after QApplication is created to avoid Qt issues
        try:
            from display_app.views.main_window import DisplayMainWindow
        except ImportError as e:
            error_msg = f"Failed to import main window: {e}"
            logging.error(error_msg)
            show_error_dialog(error_msg)
            return 1
        
        # Create and show main window
        try:
            main_window = DisplayMainWindow()
            main_window.show()
            logging.info("Display Application started successfully")
        except Exception as e:
            error_msg = f"Failed to create main window: {e}"
            logging.error(error_msg)
            show_error_dialog(error_msg)
            return 1
        
        # Start event loop
        return app.exec_()
        
    except Exception as e:
        error_msg = f"Failed to start Display Application: {e}"
        logging.error(error_msg)
        show_error_dialog(error_msg)
        return 1

if __name__ == "__main__":
    sys.exit(main())
