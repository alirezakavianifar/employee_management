"""
Text utilities for Display Application.

Handles Persian text processing, formatting, and text operations.
"""

import logging
import re
from typing import List, Optional, Dict, Any

class TextUtils:
    """Utility class for text operations with Persian support."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def format_persian_number(self, number: int) -> str:
        """Format number with Persian digits."""
        persian_digits = {
            '0': '۰', '1': '۱', '2': '۲', '3': '۳', '4': '۴',
            '5': '۵', '6': '۶', '7': '۷', '8': '۸', '9': '۹'
        }
        
        number_str = str(number)
        for eng, per in persian_digits.items():
            number_str = number_str.replace(eng, per)
        
        return number_str
    
    def format_persian_percentage(self, percentage: float) -> str:
        """Format percentage with Persian text."""
        if percentage >= 0:
            return f"+{self.format_persian_number(int(percentage))}%"
        else:
            return f"-{self.format_persian_number(int(abs(percentage)))}%"
    
    def truncate_text(self, text: str, max_length: int, suffix: str = "...") -> str:
        """Truncate text to specified length with suffix."""
        if len(text) <= max_length:
            return text
        
        # For Persian text, try to break at word boundaries
        truncated = text[:max_length - len(suffix)]
        
        # Find last space to break at word boundary
        last_space = truncated.rfind(' ')
        if last_space > max_length * 0.7:  # Only break at space if it's not too early
            truncated = truncated[:last_space]
        
        return truncated + suffix
    
    def format_employee_name(self, first_name: str, last_name: str = "") -> str:
        """Format employee name for display."""
        if last_name:
            return f"{first_name} {last_name}"
        return first_name
    
    def format_shift_time(self, shift_type: str) -> str:
        """Format shift time with Persian text."""
        shift_names = {
            'morning': 'شیفت صبح',
            'evening': 'شیفت عصر',
            'night': 'شیفت شب'
        }
        return shift_names.get(shift_type, shift_type)
    
    def format_absence_type(self, absence_type: str) -> str:
        """Format absence type with Persian text."""
        absence_names = {
            'مرخصی': 'مرخصی',
            'بیمار': 'بیمار',
            'غایب': 'غایب',
            'leave': 'مرخصی',
            'sick': 'بیمار',
            'absent': 'غایب'
        }
        return absence_names.get(absence_type, absence_type)
    
    def format_capacity_text(self, current: int, capacity: int) -> str:
        """Format capacity information."""
        if capacity == 0:
            return "ظرفیت تعریف نشده"
        
        utilization = (current / capacity) * 100
        
        if utilization >= 100:
            return f"{self.format_persian_number(current)}/{self.format_persian_number(capacity)} (پر)"
        elif utilization >= 80:
            return f"{self.format_persian_number(current)}/{self.format_persian_number(capacity)} (تقریباً پر)"
        elif utilization >= 50:
            return f"{self.format_persian_number(current)}/{self.format_persian_number(capacity)} (متوسط)"
        else:
            return f"{self.format_persian_number(current)}/{self.format_persian_number(capacity)} (کم)"
    
    def format_performance_text(self, current: float, previous: float) -> str:
        """Format performance comparison text."""
        if previous == 0:
            return "داده‌ای برای مقایسه وجود ندارد"
        
        change = ((current - previous) / previous) * 100
        
        if change > 0:
            return f"افزایش {self.format_persian_number(int(change))}% نسبت به هفته قبل"
        elif change < 0:
            return f"کاهش {self.format_persian_number(int(abs(change)))}% نسبت به هفته قبل"
        else:
            return "بدون تغییر نسبت به هفته قبل"
    
    def format_week_text(self, week_number: int) -> str:
        """Format week number with Persian text."""
        return f"هفته {self.format_persian_number(week_number)}"
    
    def format_date_text(self, date_str: str) -> str:
        """Format date string for display."""
        try:
            # Extract year, month, day
            parts = date_str.split('-')
            if len(parts) == 3:
                year, month, day = parts
                return f"{self.format_persian_number(int(day))} {self.format_persian_number(int(month))} {self.format_persian_number(int(year))}"
            return date_str
        except Exception as e:
            self.logger.error(f"Error formatting date text: {e}")
            return date_str
    
    def format_time_text(self, hour: int, minute: int = 0) -> str:
        """Format time with Persian text."""
        hour_text = self.format_persian_number(hour)
        minute_text = self.format_persian_number(minute) if minute > 0 else ""
        
        if minute > 0:
            return f"{hour_text}:{minute_text}"
        else:
            return f"{hour_text}:۰۰"
    
    def format_duration_text(self, minutes: int) -> str:
        """Format duration in minutes to Persian text."""
        if minutes < 60:
            return f"{self.format_persian_number(minutes)} دقیقه"
        else:
            hours = minutes // 60
            remaining_minutes = minutes % 60
            
            if remaining_minutes == 0:
                return f"{self.format_persian_number(hours)} ساعت"
            else:
                return f"{self.format_persian_number(hours)} ساعت و {self.format_persian_number(remaining_minutes)} دقیقه"
    
    def format_currency_text(self, amount: float) -> str:
        """Format currency amount with Persian text."""
        if amount == 0:
            return "۰ تومان"
        
        # Convert to integer if it's a whole number
        if amount.is_integer():
            amount = int(amount)
        
        amount_text = self.format_persian_number(amount)
        return f"{amount_text} تومان"
    
    def clean_text(self, text: str) -> str:
        """Clean and normalize text."""
        if not text:
            return ""
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        # Normalize Persian characters
        persian_normalizations = {
            'ي': 'ی',
            'ك': 'ک',
            'ة': 'ه',
            'ؤ': 'و',
            'ئ': 'ی',
            'إ': 'ا',
            'أ': 'ا',
            'آ': 'آ'
        }
        
        for old, new in persian_normalizations.items():
            text = text.replace(old, new)
        
        return text
    
    def extract_numbers(self, text: str) -> List[int]:
        """Extract numbers from text."""
        numbers = re.findall(r'\d+', text)
        return [int(num) for num in numbers]
    
    def extract_persian_numbers(self, text: str) -> List[int]:
        """Extract Persian numbers from text."""
        persian_to_english = {
            '۰': '0', '۱': '1', '۲': '2', '۳': '3', '۴': '4',
            '۵': '5', '۶': '6', '۷': '7', '۸': '8', '۹': '9'
        }
        
        # Convert Persian digits to English
        for per, eng in persian_to_english.items():
            text = text.replace(per, eng)
        
        return self.extract_numbers(text)
    
    def is_persian_text(self, text: str) -> bool:
        """Check if text contains Persian characters."""
        persian_chars = re.compile(r'[\u0600-\u06FF\u0750-\u077F\u08A0-\u08FF\uFB50-\uFDFF\uFE70-\uFEFF]')
        return bool(persian_chars.search(text))
    
    def get_text_direction(self, text: str) -> str:
        """Get text direction (RTL for Persian, LTR for English)."""
        if self.is_persian_text(text):
            return "RTL"
        return "LTR"
    
    def format_list_text(self, items: List[str], separator: str = "، ") -> str:
        """Format list of items with Persian separator."""
        if not items:
            return ""
        elif len(items) == 1:
            return items[0]
        elif len(items) == 2:
            return f"{items[0]} و {items[1]}"
        else:
            return separator.join(items[:-1]) + " و " + items[-1]
