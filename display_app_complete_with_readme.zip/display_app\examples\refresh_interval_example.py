#!/usr/bin/env python3
"""
Example script demonstrating how to customize the refresh interval
in the display application.

This script shows different ways to modify the refresh interval:
1. By editing the config file directly
2. By using the ConfigUtils class programmatically
3. By using the dynamic update method (if the app is running)
"""

import sys
import os
from pathlib import Path

# Add the parent directory to the path so we can import the modules
sys.path.append(str(Path(__file__).parent.parent))

from utils.config_utils import ConfigUtils

def example_1_edit_config_file():
    """Example 1: Edit the config file directly"""
    print("=== Example 1: Editing config file directly ===")
    
    config_path = Path("config/display_config.ini")
    if config_path.exists():
        print(f"Current config file: {config_path}")
        print("To change the refresh interval:")
        print("1. Open config/display_config.ini")
        print("2. Find the [display] section")
        print("3. Change refresh_interval = 30 to your desired value (5-300)")
        print("4. Save the file")
        print("5. Restart the display app")
        print()
    else:
        print("Config file not found. Run the display app first to create it.")

def example_2_programmatic_config():
    """Example 2: Use ConfigUtils to change the interval programmatically"""
    print("=== Example 2: Using ConfigUtils programmatically ===")
    
    try:
        # Initialize config utils
        config_utils = ConfigUtils("config")
        
        # Get current interval
        current_interval = config_utils.get_config_value('display', 'refresh_interval', '30')
        print(f"Current refresh interval: {current_interval} seconds")
        
        # Set new interval (example: 60 seconds)
        new_interval = "60"
        success = config_utils.set_config_value('display', 'refresh_interval', new_interval)
        
        if success:
            print(f"Successfully updated refresh interval to {new_interval} seconds")
            print("Restart the display app to apply the changes")
        else:
            print("Failed to update refresh interval")
            
        # Verify the change
        updated_interval = config_utils.get_config_value('display', 'refresh_interval', '30')
        print(f"Verified new interval: {updated_interval} seconds")
        
    except Exception as e:
        print(f"Error: {e}")

def example_3_dynamic_update():
    """Example 3: Dynamic update (if the app is running)"""
    print("=== Example 3: Dynamic update (requires running app) ===")
    print("If the display app is currently running, you can update the interval")
    print("dynamically without restarting. This would require:")
    print("1. Accessing the main window instance")
    print("2. Calling update_refresh_interval(new_interval)")
    print()
    print("Example code (if you have access to the main window):")
    print("  main_window.update_refresh_interval(45)  # Set to 45 seconds")
    print()

def example_4_validation():
    """Example 4: Show validation behavior"""
    print("=== Example 4: Validation behavior ===")
    
    try:
        config_utils = ConfigUtils("config")
        
        # Test invalid values
        test_values = [1, 4, 5, 30, 300, 301, 500]
        
        for value in test_values:
            print(f"Testing value: {value}")
            
            # Simulate validation (same logic as in the app)
            if value < 5:
                print(f"  -> Would be adjusted to minimum: 5 seconds")
            elif value > 300:
                print(f"  -> Would be adjusted to maximum: 300 seconds")
            else:
                print(f"  -> Valid value: {value} seconds")
        
    except Exception as e:
        print(f"Error: {e}")

def main():
    """Main function to run all examples"""
    print("Display App Refresh Interval Customization Examples")
    print("=" * 50)
    print()
    
    example_1_edit_config_file()
    print()
    
    example_2_programmatic_config()
    print()
    
    example_3_dynamic_update()
    print()
    
    example_4_validation()
    print()
    
    print("=== Summary ===")
    print("The display app now supports customizable refresh intervals:")
    print("- Minimum: 5 seconds")
    print("- Maximum: 300 seconds (5 minutes)")
    print("- Default: 30 seconds")
    print("- Configurable via config/display_config.ini")
    print("- Can be updated programmatically using ConfigUtils")
    print("- Supports dynamic updates without restart (if app is running)")

if __name__ == "__main__":
    main()
