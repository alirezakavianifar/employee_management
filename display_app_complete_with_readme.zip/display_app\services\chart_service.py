"""
Chart Service for Display Application.

Handles performance charts and visualizations with Persian labels.
"""

import logging
import sys
import os

# Check if running as compiled executable
is_frozen = getattr(sys, 'frozen', False)

try:
    import matplotlib
    # Set backend before importing pyplot - use Agg for executables to prevent crashes
    if is_frozen:
        matplotlib.use('Agg')  # Use non-interactive backend for executables
    else:
        matplotlib.use('Qt5Agg')
    
    import matplotlib.pyplot as plt
    import matplotlib.font_manager as fm
    from matplotlib.backends.backend_qt5agg import FigureCanvasQTAgg as FigureCanvas
    from matplotlib.figure import Figure
    import numpy as np
    MATPLOTLIB_AVAILABLE = True
    
except ImportError as e:
    logging.warning(f"Matplotlib not available: {e}")
    MATPLOTLIB_AVAILABLE = False
    # Create dummy classes for fallback
    class FigureCanvas:
        def __init__(self, *args, **kwargs):
            pass
    class Figure:
        def __init__(self, *args, **kwargs):
            pass

from typing import Dict, Any, List, Optional

class ChartService:
    """Service for creating and managing charts with Persian labels."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
        self._chart_cache = {}  # Cache for charts to prevent recreation
        if MATPLOTLIB_AVAILABLE:
            self._setup_persian_fonts()
        else:
            self.logger.warning("Matplotlib not available - charts will be disabled")
    
    def _setup_persian_fonts(self):
        """Setup Persian-compatible fonts for matplotlib."""
        try:
            # Try to find and use Persian fonts - prioritize Tahoma
            persian_fonts = ['Tahoma', 'Arial Unicode MS', 'B Nazanin', 'B Mitra', 'Arial']
            
            for font_name in persian_fonts:
                try:
                    font_path = fm.findfont(fm.FontProperties(family=font_name))
                    if font_path and 'ttf' in font_path.lower():
                        plt.rcParams['font.family'] = font_name
                        self.logger.info(f"Using Persian font: {font_name}")
                        break
                except:
                    continue
            else:
                # Fallback to default font
                plt.rcParams['font.family'] = 'DejaVu Sans'
                self.logger.warning("No Persian font found, using fallback")
                
        except Exception as e:
            self.logger.error(f"Error setting up Persian fonts: {e}")
    
    def _safe_create_figure(self, figsize=(8, 6), dpi=100):
        """Safely create a matplotlib figure with error handling."""
        try:
            if not MATPLOTLIB_AVAILABLE:
                return None, None
                
            fig = Figure(figsize=figsize, dpi=dpi)
            canvas = FigureCanvas(fig)
            return fig, canvas
        except Exception as e:
            self.logger.error(f"Error creating figure: {e}")
            return None, None
    
    def create_performance_chart(self, performance_data: Dict[str, Any], 
                                chart_title: str = None) -> Optional[FigureCanvas]:
        """Create a performance chart with Persian labels and exact title format as per specs."""
        if not MATPLOTLIB_AVAILABLE:
            self.logger.warning("Matplotlib not available - cannot create chart")
            return None
            
        try:
            # Create figure and canvas safely
            fig, canvas = self._safe_create_figure()
            if fig is None or canvas is None:
                return None
                
            ax = fig.add_subplot(111)
            
            # Use exact title format as per specs: "Performance Increase — Week N"
            if chart_title is None:
                from datetime import datetime
                current_week = datetime.now().isocalendar()[1]
                chart_title = f"افزایش عملکرد — هفته {current_week}"
            
            # Extract data safely
            weeks = performance_data.get('weeks', [])
            values = performance_data.get('values', [])
            
            if not weeks or not values:
                # Create sample data if none provided
                weeks = [f"هفته {i}" for i in range(1, 6)]
                values = [85, 92, 78, 95, 88]
            
            # Validate data
            if len(weeks) != len(values):
                self.logger.warning("Weeks and values arrays have different lengths")
                return None
            
            # Create bar chart
            bars = ax.bar(weeks, values, color='#3b82f6', alpha=0.8, edgecolor='#1e40af')
            
            # Customize chart with English labels due to Persian rendering issues
            ax.set_title(chart_title, fontsize=16, fontweight='bold', pad=20)
            ax.set_xlabel('Weeks', fontsize=12, labelpad=10)
            ax.set_ylabel('Performance (%)', fontsize=12, labelpad=10)
            
            # Set y-axis limits safely
            max_value = max(values) if values else 100
            ax.set_ylim(0, max_value * 1.1)
            
            # Add value labels on bars
            for bar, value in zip(bars, values):
                height = bar.get_height()
                ax.text(bar.get_x() + bar.get_width()/2., height + 1,
                       f'{value}%', ha='center', va='bottom', fontweight='bold')
            
            # Customize grid and appearance
            ax.grid(True, alpha=0.3, axis='y')
            ax.set_axisbelow(True)
            
            # Remove top and right spines
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            
            # Rotate x-axis labels for better readability
            plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
            
            # Adjust layout
            fig.tight_layout()
            
            return canvas
            
        except Exception as e:
            self.logger.error(f"Error creating performance chart: {e}")
            return None
    
    def create_shift_distribution_chart(self, shift_data: Dict[str, Any]) -> Optional[FigureCanvas]:
        """Create a shift distribution pie chart."""
        if not MATPLOTLIB_AVAILABLE:
            self.logger.warning("Matplotlib not available - cannot create chart")
            return None
        try:
            fig, canvas = self._safe_create_figure(figsize=(6, 6))
            if fig is None or canvas is None:
                return None
                
            ax = fig.add_subplot(111)
            
            # Extract shift data safely - handle the actual data structure
            morning_shift = shift_data.get('morning', {})
            evening_shift = shift_data.get('evening', {})
            
            # Count actual assigned employees (excluding null values)
            morning_employees = morning_shift.get('assigned_employees', [])
            evening_employees = evening_shift.get('assigned_employees', [])
            
            morning_count = len([emp for emp in morning_employees if emp is not None])
            evening_count = len([emp for emp in evening_employees if emp is not None])
            
            if morning_count == 0 and evening_count == 0:
                return self._create_error_canvas("داده‌ای برای نمایش وجود ندارد")
            
            # Create pie chart
            sizes = [morning_count, evening_count]
            labels = ['شیفت صبح', 'شیفت عصر']
            colors = ['#10b981', '#f59e0b']
            
            wedges, texts, autotexts = ax.pie(sizes, labels=labels, colors=colors, 
                                             autopct='%1.1f%%', startangle=90)
            
            # Customize text
            for text in texts:
                text.set_fontsize(12)
                text.set_fontweight('bold')
            
            for autotext in autotexts:
                autotext.set_color('white')
                autotext.set_fontweight('bold')
                autotext.set_fontsize(10)
            
            ax.set_title('توزیع شیفت‌ها', fontsize=16, fontweight='bold', pad=20)
            
            # Add legend
            ax.legend(wedges, labels, title="شیفت‌ها", loc="center left", bbox_to_anchor=(1, 0, 0.5, 1))
            
            fig.tight_layout()
            
            self.logger.info("Shift distribution chart created successfully")
            return canvas
            
        except Exception as e:
            self.logger.error(f"Error creating shift distribution chart: {e}")
            return None
    
    def create_absence_trend_chart(self, absence_data: Dict[str, Any], 
                                  days: int = 7) -> Optional[FigureCanvas]:
        """Create an absence trend line chart."""
        if not MATPLOTLIB_AVAILABLE:
            self.logger.warning("Matplotlib not available - cannot create chart")
            return None
        try:
            fig, canvas = self._safe_create_figure()
            if fig is None or canvas is None:
                return None
                
            ax = fig.add_subplot(111)
            
            # Generate sample data for demonstration
            # In real app, this would come from historical data
            dates = [f"روز {i}" for i in range(1, days + 1)]
            leave_data = np.random.randint(0, 5, days)
            sick_data = np.random.randint(0, 3, days)
            absent_data = np.random.randint(0, 2, days)
            
            # Create line chart
            ax.plot(dates, leave_data, marker='o', linewidth=2, label='مرخصی', color='#3b82f6')
            ax.plot(dates, sick_data, marker='s', linewidth=2, label='بیمار', color='#ef4444')
            ax.plot(dates, absent_data, marker='^', linewidth=2, label='غایب', color='#f59e0b')
            
            # Customize chart
            ax.set_title('روند غیبت‌ها', fontsize=16, fontweight='bold', pad=20)
            ax.set_xlabel('روز', fontsize=12, labelpad=10)
            ax.set_ylabel('تعداد', fontsize=12, labelpad=10)
            
            # Add grid
            ax.grid(True, alpha=0.3)
            ax.set_axisbelow(True)
            
            # Add legend
            ax.legend(loc='upper right')
            
            # Remove top and right spines
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            
            # Rotate x-axis labels
            plt.setp(ax.get_xticklabels(), rotation=45, ha='right')
            
            fig.tight_layout()
            
            self.logger.info("Absence trend chart created successfully")
            return canvas
            
        except Exception as e:
            self.logger.error(f"Error creating absence trend chart: {e}")
            return None
    
    def create_capacity_utilization_chart(self, shift_data: Dict[str, Any], 
                                        settings: Dict[str, Any]) -> Optional[FigureCanvas]:
        """Create a capacity utilization chart."""
        if not MATPLOTLIB_AVAILABLE:
            self.logger.warning("Matplotlib not available - cannot create chart")
            return None
        try:
            fig, canvas = self._safe_create_figure()
            if fig is None or canvas is None:
                return None
                
            ax = fig.add_subplot(111)
            
            # Extract data safely - handle the actual data structure
            morning_shift = shift_data.get('morning', {})
            evening_shift = shift_data.get('evening', {})
            
            # Count actual assigned employees (excluding null values)
            morning_employees = morning_shift.get('assigned_employees', [])
            evening_employees = evening_shift.get('assigned_employees', [])
            
            morning_count = len([emp for emp in morning_employees if emp is not None])
            evening_count = len([emp for emp in evening_employees if emp is not None])
            
            # Get capacity from shift data or settings
            morning_capacity = morning_shift.get('capacity', settings.get('morning_capacity', 10))
            evening_capacity = evening_shift.get('capacity', settings.get('evening_capacity', 10))
            
            # Calculate utilization percentages safely
            morning_util = (morning_count / morning_capacity * 100) if morning_capacity > 0 else 0
            evening_util = (evening_count / evening_capacity * 100) if evening_capacity > 0 else 0
            
            # Create horizontal bar chart
            shifts = ['شیفت صبح', 'شیفت عصر']
            utilizations = [morning_util, evening_util]
            colors = ['#10b981' if u <= 100 else '#ef4444' for u in utilizations]
            
            bars = ax.barh(shifts, utilizations, color=colors, alpha=0.8)
            
            # Add capacity lines
            ax.axvline(x=100, color='#6b7280', linestyle='--', alpha=0.7, label='ظرفیت کامل')
            
            # Customize chart
            ax.set_title('استفاده از ظرفیت شیفت‌ها', fontsize=16, fontweight='bold', pad=20)
            ax.set_xlabel('درصد استفاده', fontsize=12, labelpad=10)
            
            # Set x-axis limits safely
            max_util = max(utilizations) if utilizations else 100
            ax.set_xlim(0, max(max_util * 1.1, 100))
            
            # Add value labels
            for bar, util in zip(bars, utilizations):
                width = bar.get_width()
                ax.text(width + 1, bar.get_y() + bar.get_height()/2,
                       f'{util:.1f}%', ha='left', va='center', fontweight='bold')
            
            # Add grid
            ax.grid(True, alpha=0.3, axis='x')
            ax.set_axisbelow(True)
            
            # Remove top and right spines
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            
            # Add legend
            ax.legend(loc='upper right')
            
            fig.tight_layout()
            
            self.logger.info("Capacity utilization chart created successfully")
            return canvas
            
        except Exception as e:
            self.logger.error(f"Error creating capacity utilization chart: {e}")
            return None
    
    def _create_error_canvas(self, error_message: str) -> Optional[FigureCanvas]:
        """Create an error canvas when chart creation fails."""
        if not MATPLOTLIB_AVAILABLE:
            self.logger.warning("Matplotlib not available - cannot create error canvas")
            return None
        try:
            fig, canvas = self._safe_create_figure(figsize=(6, 4))
            if fig is None or canvas is None:
                return None
                
            ax = fig.add_subplot(111)
            
            ax.text(0.5, 0.5, error_message, ha='center', va='center', 
                   transform=ax.transAxes, fontsize=14, color='red')
            ax.set_title('خطا', fontsize=16, fontweight='bold')
            
            # Remove axes
            ax.set_xticks([])
            ax.set_yticks([])
            ax.spines['top'].set_visible(False)
            ax.spines['right'].set_visible(False)
            ax.spines['bottom'].set_visible(False)
            ax.spines['left'].set_visible(False)
            
            return canvas
        except Exception as e:
            self.logger.error(f"Error creating error canvas: {e}")
            return None
    
    def cleanup_charts(self):
        """Clean up chart resources to prevent memory leaks."""
        try:
            if MATPLOTLIB_AVAILABLE:
                plt.close('all')  # Close all matplotlib figures
            self._chart_cache.clear()
        except Exception as e:
            self.logger.error(f"Error cleaning up charts: {e}")
    
    def __del__(self):
        """Destructor to ensure cleanup."""
        self.cleanup_charts()
