"""
Configuration utilities for Display Application.

Handles application settings, configuration files, and environment variables.
"""

import logging
import json
import os
from pathlib import Path
from typing import Dict, Any, Optional, List
import configparser

class ConfigUtils:
    """Utility class for managing application configuration."""
    
    def __init__(self, config_dir: str = "config"):
        self.config_dir = Path(config_dir)
        self.config_file = self.config_dir / "display_config.ini"
        self.settings_file = self.config_dir / "settings.json"
        
        # Ensure config directory exists
        self.config_dir.mkdir(parents=True, exist_ok=True)
        
        # Setup logging
        self.logger = logging.getLogger(__name__)
        
        # Default configuration
        self.default_config = {
            'display': {
                'fullscreen': 'true',
                'refresh_interval': '30',
                'theme': 'dark',
                'font_size': '12',
                'language': 'fa'
            },
            'data': {
                'sync_interval': '30',
                'auto_backup': 'true',
                'backup_retention_days': '30',
                'data_path': 'data'
            },
            'charts': {
                'chart_theme': 'default',
                'persian_fonts': 'true',
                'chart_quality': 'high',
                'auto_refresh': 'true'
            },
            'ui': {
                'rtl_layout': 'true',
                'persian_numbers': 'true',
                'show_tooltips': 'true',
                'animation_speed': 'normal'
            }
        }
        
        # Default settings
        self.default_settings = {
            'morning_capacity': 10,
            'evening_capacity': 10,
            'sync_path': 'data',
            'export_formats': ['PNG', 'PDF', 'CSV'],
            'managers': [],
            'theme_colors': {
                'primary': '#3b82f6',
                'secondary': '#6b7280',
                'success': '#10b981',
                'warning': '#f59e0b',
                'danger': '#ef4444'
            }
        }
        
        # Initialize configuration
        self._initialize_config()
    
    def _initialize_config(self):
        """Initialize configuration files if they don't exist."""
        try:
            # Create INI config file
            if not self.config_file.exists():
                self._create_ini_config()
            
            # Create JSON settings file
            if not self.settings_file.exists():
                self._create_json_settings()
                
        except Exception as e:
            self.logger.error(f"Error initializing configuration: {e}")
    
    def _create_ini_config(self):
        """Create INI configuration file with default values."""
        try:
            config = configparser.ConfigParser()
            
            for section, options in self.default_config.items():
                config.add_section(section)
                for key, value in options.items():
                    config.set(section, key, value)
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                config.write(f)
            
            self.logger.info(f"Created INI config file: {self.config_file}")
            
        except Exception as e:
            self.logger.error(f"Error creating INI config: {e}")
    
    def _create_json_settings(self):
        """Create JSON settings file with default values."""
        try:
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(self.default_settings, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"Created JSON settings file: {self.settings_file}")
            
        except Exception as e:
            self.logger.error(f"Error creating JSON settings: {e}")
    
    def get_config_value(self, section: str, key: str, default: str = None) -> str:
        """Get configuration value from INI file."""
        try:
            config = configparser.ConfigParser()
            config.read(self.config_file, encoding='utf-8')
            
            if config.has_section(section) and config.has_option(section, key):
                return config.get(section, key)
            
            return default
            
        except Exception as e:
            self.logger.error(f"Error reading config value {section}.{key}: {e}")
            return default
    
    def set_config_value(self, section: str, key: str, value: str) -> bool:
        """Set configuration value in INI file."""
        try:
            config = configparser.ConfigParser()
            config.read(self.config_file, encoding='utf-8')
            
            if not config.has_section(section):
                config.add_section(section)
            
            config.set(section, key, value)
            
            with open(self.config_file, 'w', encoding='utf-8') as f:
                config.write(f)
            
            self.logger.info(f"Updated config value {section}.{key} = {value}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error setting config value {section}.{key}: {e}")
            return False
    
    def get_setting(self, key: str, default: Any = None) -> Any:
        """Get setting value from JSON file."""
        try:
            if not self.settings_file.exists():
                return default
            
            with open(self.settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            return settings.get(key, default)
            
        except Exception as e:
            self.logger.error(f"Error reading setting {key}: {e}")
            return default
    
    def set_setting(self, key: str, value: Any) -> bool:
        """Set setting value in JSON file."""
        try:
            # Read existing settings
            settings = {}
            if self.settings_file.exists():
                with open(self.settings_file, 'r', encoding='utf-8') as f:
                    settings = json.load(f)
            
            # Update setting
            settings[key] = value
            
            # Write back to file
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"Updated setting {key} = {value}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error setting setting {key}: {e}")
            return False
    
    def get_all_settings(self) -> Dict[str, Any]:
        """Get all settings from JSON file."""
        try:
            if not self.settings_file.exists():
                return self.default_settings.copy()
            
            with open(self.settings_file, 'r', encoding='utf-8') as f:
                settings = json.load(f)
            
            # Merge with defaults for missing keys
            result = self.default_settings.copy()
            result.update(settings)
            
            return result
            
        except Exception as e:
            self.logger.error(f"Error reading all settings: {e}")
            return self.default_settings.copy()
    
    def update_settings(self, new_settings: Dict[str, Any]) -> bool:
        """Update multiple settings at once."""
        try:
            # Read existing settings
            settings = self.get_all_settings()
            
            # Update with new values
            settings.update(new_settings)
            
            # Write back to file
            with open(self.settings_file, 'w', encoding='utf-8') as f:
                json.dump(settings, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"Updated {len(new_settings)} settings")
            return True
            
        except Exception as e:
            self.logger.error(f"Error updating settings: {e}")
            return False
    
    def reset_to_defaults(self) -> bool:
        """Reset all settings to default values."""
        try:
            # Remove existing files
            if self.config_file.exists():
                self.config_file.unlink()
            
            if self.settings_file.exists():
                self.settings_file.unlink()
            
            # Recreate with defaults
            self._initialize_config()
            
            self.logger.info("Reset configuration to defaults")
            return True
            
        except Exception as e:
            self.logger.error(f"Error resetting to defaults: {e}")
            return False
    
    def get_environment_config(self) -> Dict[str, str]:
        """Get configuration from environment variables."""
        env_config = {}
        
        # Map environment variables to config keys
        env_mapping = {
            'DISPLAY_FULLSCREEN': ('display', 'fullscreen'),
            'DISPLAY_REFRESH_INTERVAL': ('display', 'refresh_interval'),
            'DISPLAY_THEME': ('display', 'theme'),
            'DATA_SYNC_INTERVAL': ('data', 'sync_interval'),
            'DATA_PATH': ('data', 'data_path'),
            'UI_LANGUAGE': ('ui', 'language'),
            'UI_RTL_LAYOUT': ('ui', 'rtl_layout')
        }
        
        for env_var, (section, key) in env_mapping.items():
            value = os.environ.get(env_var)
            if value:
                env_config[f"{section}.{key}"] = value
        
        return env_config
    
    def apply_environment_config(self) -> bool:
        """Apply environment variable configuration."""
        try:
            env_config = self.get_environment_config()
            
            for config_key, value in env_config.items():
                section, key = config_key.split('.', 1)
                self.set_config_value(section, key, value)
            
            if env_config:
                self.logger.info(f"Applied {len(env_config)} environment configurations")
            
            return True
            
        except Exception as e:
            self.logger.error(f"Error applying environment config: {e}")
            return False
    
    def validate_config(self) -> List[str]:
        """Validate current configuration and return any errors."""
        errors = []
        
        try:
            # Validate INI config
            if self.config_file.exists():
                config = configparser.ConfigParser()
                config.read(self.config_file, encoding='utf-8')
                
                for section, options in self.default_config.items():
                    if not config.has_section(section):
                        errors.append(f"Missing section: {section}")
                    else:
                        for key, default_value in options.items():
                            if not config.has_option(section, key):
                                errors.append(f"Missing option: {section}.{key}")
            
            # Validate JSON settings
            if self.settings_file.exists():
                settings = self.get_all_settings()
                
                # Check required settings
                required_settings = ['morning_capacity', 'evening_capacity', 'sync_path']
                for setting in required_settings:
                    if setting not in settings:
                        errors.append(f"Missing required setting: {setting}")
                
                # Validate capacity values
                for capacity_setting in ['morning_capacity', 'evening_capacity']:
                    if capacity_setting in settings:
                        capacity = settings[capacity_setting]
                        if not isinstance(capacity, int) or capacity < 1 or capacity > 100:
                            errors.append(f"Invalid capacity value for {capacity_setting}: {capacity}")
            
        except Exception as e:
            errors.append(f"Configuration validation error: {e}")
        
        return errors
    
    def export_config(self, export_path: str) -> bool:
        """Export current configuration to a file."""
        try:
            export_file = Path(export_path)
            
            # Create export data
            export_data = {
                'ini_config': {},
                'json_settings': self.get_all_settings(),
                'export_timestamp': self._get_timestamp()
            }
            
            # Read INI config
            if self.config_file.exists():
                config = configparser.ConfigParser()
                config.read(self.config_file, encoding='utf-8')
                
                for section in config.sections():
                    export_data['ini_config'][section] = dict(config.items(section))
            
            # Write export file
            with open(export_file, 'w', encoding='utf-8') as f:
                json.dump(export_data, f, ensure_ascii=False, indent=2)
            
            self.logger.info(f"Exported configuration to: {export_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error exporting configuration: {e}")
            return False
    
    def import_config(self, import_path: str) -> bool:
        """Import configuration from a file."""
        try:
            import_file = Path(import_path)
            
            if not import_file.exists():
                self.logger.error(f"Import file not found: {import_path}")
                return False
            
            with open(import_file, 'r', encoding='utf-8') as f:
                import_data = json.load(f)
            
            # Import INI config
            if 'ini_config' in import_data:
                config = configparser.ConfigParser()
                
                for section, options in import_data['ini_config'].items():
                    if not config.has_section(section):
                        config.add_section(section)
                    
                    for key, value in options.items():
                        config.set(section, key, value)
                
                with open(self.config_file, 'w', encoding='utf-8') as f:
                    config.write(f)
            
            # Import JSON settings
            if 'json_settings' in import_data:
                self.update_settings(import_data['json_settings'])
            
            self.logger.info(f"Imported configuration from: {import_path}")
            return True
            
        except Exception as e:
            self.logger.error(f"Error importing configuration: {e}")
            return False
    
    def _get_timestamp(self) -> str:
        """Get current timestamp string."""
        from datetime import datetime
        return datetime.now().isoformat()
