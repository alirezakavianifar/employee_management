from typing import Dict, Any, List
from datetime import datetime, timedelta
import logging

class AIRulesEngine:
    """Rule-based AI engine for generating Persian recommendations."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def get_week_number(self, date_str: str = None) -> int:
        """Get week number from date string or current date."""
        if date_str:
            try:
                date_obj = datetime.strptime(date_str, "%Y-%m-%d")
            except ValueError:
                date_obj = datetime.now()
        else:
            date_obj = datetime.now()
        
        # Get ISO week number
        return date_obj.isocalendar()[1]
    
    def analyze_capacity_vs_orders(self, current_capacity: int, orders_data: List[Dict[str, Any]]) -> str:
        """
        Analyze capacity vs orders and return Persian recommendation.
        
        Args:
            current_capacity: Current shift capacity
            orders_data: List of order data with week numbers and quantities
        
        Returns:
            Persian recommendation string
        """
        try:
            if not orders_data or len(orders_data) < 2:
                return "اطلاعات کافی برای تحلیل موجود نیست"
            
            # Sort orders by week
            sorted_orders = sorted(orders_data, key=lambda x: x.get('week', 0))
            
            # Get next week and two weeks ahead orders
            current_week = self.get_week_number()
            next_week_orders = 0
            two_weeks_orders = 0
            
            for order in sorted_orders:
                week = order.get('week', 0)
                quantity = order.get('quantity', 0)
                
                if week == current_week + 1:
                    next_week_orders = quantity
                elif week == current_week + 2:
                    two_weeks_orders = quantity
            
            # Rule 1: If next week's orders are less than or equal to capacity
            if next_week_orders <= current_capacity:
                return "تا ۳ نفر می‌توانند به مرخصی بروند"
            
            # Rule 2: If two weeks of orders are 15% or more over capacity
            total_two_weeks = next_week_orders + two_weeks_orders
            capacity_threshold = current_capacity * 2 * 1.15  # 15% over capacity
            
            if total_two_weeks >= capacity_threshold:
                return "اضافه کاری باید برنامه ریزی شود"
            
            # Default recommendation
            return "وضعیت عادی - ظرفیت کافی موجود است"
            
        except Exception as e:
            self.logger.error(f"Error in capacity analysis: {e}")
            return "خطا در تحلیل داده‌ها"
    
    def get_performance_recommendation(self, shift_data: Dict[str, Any], absence_data: Dict[str, Any]) -> str:
        """
        Generate performance recommendation based on shift and absence data.
        
        Args:
            shift_data: Current shift assignments
            absence_data: Current absence data
        
        Returns:
            Persian recommendation string
        """
        try:
            morning_count = len(shift_data.get('morning', []))
            evening_count = len(shift_data.get('evening', []))
            total_assigned = morning_count + evening_count
            
            # Count absences
            leave_count = len(absence_data.get('مرخصی', []))
            sick_count = len(absence_data.get('بیمار', []))
            absent_count = len(absence_data.get('غایب', []))
            total_absences = leave_count + sick_count + absent_count
            
            # Generate recommendations based on patterns
            if total_absences > total_assigned * 0.3:  # More than 30% absent
                return "نرخ غیبت بالا - بررسی علل ضروری است"
            
            if morning_count < evening_count * 0.7:  # Morning shift understaffed
                return "شیفت صبح نیاز به نیروی بیشتر دارد"
            
            if evening_count < morning_count * 0.7:  # Evening shift understaffed
                return "شیفت عصر نیاز به نیروی بیشتر دارد"
            
            return "توزیع نیرو متعادل است"
            
        except Exception as e:
            self.logger.error(f"Error in performance analysis: {e}")
            return "خطا در تحلیل عملکرد"
    
    def get_shift_optimization_tip(self, shift_data: Dict[str, Any], capacity: int) -> str:
        """
        Generate shift optimization tips.
        
        Args:
            shift_data: Current shift assignments
            capacity: Shift capacity limit
        
        Returns:
            Persian optimization tip
        """
        try:
            morning_count = len(shift_data.get('morning', []))
            evening_count = len(shift_data.get('evening', []))
            
            if morning_count == capacity and evening_count < capacity:
                return "شیفت عصر ظرفیت خالی دارد - انتقال نیرو از صبح"
            
            if evening_count == capacity and morning_count < capacity:
                return "شیفت صبح ظرفیت خالی دارد - انتقال نیرو از عصر"
            
            if morning_count < capacity * 0.5 and evening_count < capacity * 0.5:
                return "هر دو شیفت کم‌نیرو هستند - استخدام موقت توصیه می‌شود"
            
            return "توزیع نیرو بهینه است"
            
        except Exception as e:
            self.logger.error(f"Error in shift optimization: {e}")
            return "خطا در تحلیل بهینه‌سازی"
    
    def generate_daily_insight(self, report_data: Dict[str, Any]) -> str:
        """
        Generate comprehensive daily insight combining all analyses.
        
        Args:
            report_data: Complete daily report data
        
        Returns:
            Main Persian insight for the day
        """
        try:
            shifts = report_data.get('shifts', {})
            absences = report_data.get('absences', {})
            settings = report_data.get('settings', {})
            
            capacity = settings.get('shift_capacity', 5)
            
            # Get main recommendation
            main_rec = self.analyze_capacity_vs_orders(capacity, [])
            
            # Get performance insight
            perf_rec = self.get_performance_recommendation(shifts, absences)
            
            # Get optimization tip
            opt_tip = self.get_shift_optimization_tip(shifts, capacity)
            
            # Combine insights (return the most important one)
            if "اضافه کاری" in main_rec:
                return main_rec
            elif "مرخصی" in main_rec:
                return main_rec
            elif "کم‌نیرو" in opt_tip:
                return opt_tip
            else:
                return perf_rec
                
        except Exception as e:
            self.logger.error(f"Error generating daily insight: {e}")
            return "تحلیل روزانه در دسترس نیست"
