"""
Validation utilities for Display Application.

Handles data validation, input checking, and error handling.
"""

import logging
import re
from typing import Dict, Any, List, Optional, Tuple
from pathlib import Path
import os

class ValidationUtils:
    """Utility class for data validation and input checking."""
    
    def __init__(self):
        self.logger = logging.getLogger(__name__)
    
    def validate_employee_data(self, employee_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate employee data structure."""
        errors = []
        
        # Required fields
        required_fields = ['id', 'first_name']
        for field in required_fields:
            if field not in employee_data or not employee_data[field]:
                errors.append(f"فیلد {field} الزامی است")
        
        # Validate ID format
        if 'id' in employee_data and employee_data['id']:
            if not self._is_valid_employee_id(employee_data['id']):
                errors.append("فرمت شناسه کارمند نامعتبر است")
        
        # Validate name length
        if 'first_name' in employee_data and employee_data['first_name']:
            if len(employee_data['first_name']) < 2:
                errors.append("نام باید حداقل ۲ کاراکتر باشد")
            if len(employee_data['first_name']) > 50:
                errors.append("نام نمی‌تواند بیش از ۵۰ کاراکتر باشد")
        
        # Validate last name if provided
        if 'last_name' in employee_data and employee_data['last_name']:
            if len(employee_data['last_name']) > 50:
                errors.append("نام خانوادگی نمی‌تواند بیش از ۵۰ کاراکتر باشد")
        
        # Validate phone number if provided
        if 'phone' in employee_data and employee_data['phone']:
            if not self._is_valid_phone_number(employee_data['phone']):
                errors.append("شماره تلفن نامعتبر است")
        
        # Validate email if provided
        if 'email' in employee_data and employee_data['email']:
            if not self._is_valid_email(employee_data['email']):
                errors.append("ایمیل نامعتبر است")
        
        return len(errors) == 0, errors
    
    def validate_shift_data(self, shift_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate shift data structure."""
        errors = []
        
        # Check if shifts key exists
        if 'shifts' not in shift_data:
            errors.append("اطلاعات شیفت‌ها موجود نیست")
            return False, errors
        
        shifts = shift_data['shifts']
        
        # Validate morning shift
        if 'morning' in shifts:
            if not isinstance(shifts['morning'], list):
                errors.append("شیفت صبح باید لیست باشد")
            else:
                for i, employee in enumerate(shifts['morning']):
                    if not self._is_valid_employee_reference(employee):
                        errors.append(f"اطلاعات کارمند {i+1} در شیفت صبح نامعتبر است")
        
        # Validate evening shift
        if 'evening' in shifts:
            if not isinstance(shifts['evening'], list):
                errors.append("شیفت عصر باید لیست باشد")
            else:
                for i, employee in enumerate(shifts['evening']):
                    if not self._is_valid_employee_reference(employee):
                        errors.append(f"اطلاعات کارمند {i+1} در شیفت عصر نامعتبر است")
        
        return len(errors) == 0, errors
    
    def validate_absence_data(self, absence_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate absence data structure."""
        errors = []
        
        # Check if absences key exists
        if 'absences' not in absence_data:
            errors.append("اطلاعات غیبت‌ها موجود نیست")
            return False, errors
        
        absences = absence_data['absences']
        
        # Validate absence categories
        valid_categories = ['مرخصی', 'بیمار', 'غایب']
        for category in absences:
            if category not in valid_categories:
                errors.append(f"دسته‌بندی غیبت '{category}' نامعتبر است")
        
        # Validate each absence entry
        for category, employees in absences.items():
            if not isinstance(employees, list):
                errors.append(f"لیست غیبت‌های {category} نامعتبر است")
            else:
                for i, employee in enumerate(employees):
                    if not self._is_valid_employee_reference(employee):
                        errors.append(f"اطلاعات کارمند {i+1} در غیبت {category} نامعتبر است")
        
        return len(errors) == 0, errors
    
    def validate_settings_data(self, settings_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate settings data structure."""
        errors = []
        
        # Validate capacity settings
        if 'morning_capacity' in settings_data:
            capacity = settings_data['morning_capacity']
            if not isinstance(capacity, int) or capacity < 1 or capacity > 100:
                errors.append("ظرفیت شیفت صبح باید عددی بین ۱ تا ۱۰۰ باشد")
        
        if 'evening_capacity' in settings_data:
            capacity = settings_data['evening_capacity']
            if not isinstance(capacity, int) or capacity < 1 or capacity > 100:
                errors.append("ظرفیت شیفت عصر باید عددی بین ۱ تا ۱۰۰ باشد")
        
        # Validate sync settings
        if 'sync_interval' in settings_data:
            interval = settings_data['sync_interval']
            if not isinstance(interval, int) or interval < 10 or interval > 300:
                errors.append("فاصله همگام‌سازی باید بین ۱۰ تا ۳۰۰ ثانیه باشد")
        
        return len(errors) == 0, errors
    
    def validate_report_structure(self, report_data: Dict[str, Any]) -> Tuple[bool, List[str]]:
        """Validate complete report structure."""
        errors = []
        
        # Check required top-level keys
        required_keys = ['date', 'shifts', 'absences']
        for key in required_keys:
            if key not in report_data:
                errors.append(f"کلید '{key}' در گزارش موجود نیست")
        
        # Validate date format
        if 'date' in report_data:
            if not self._is_valid_date_format(report_data['date']):
                errors.append("فرمت تاریخ نامعتبر است")
        
        # Validate shifts
        if 'shifts' in report_data:
            is_valid, shift_errors = self.validate_shift_data(report_data)
            if not is_valid:
                errors.extend(shift_errors)
        
        # Validate absences
        if 'absences' in report_data:
            is_valid, absence_errors = self.validate_absence_data(report_data)
            if not is_valid:
                errors.extend(absence_errors)
        
        # Validate settings if present
        if 'settings' in report_data:
            is_valid, setting_errors = self.validate_settings_data(report_data['settings'])
            if not is_valid:
                errors.extend(setting_errors)
        
        return len(errors) == 0, errors
    
    def validate_file_path(self, file_path: str) -> Tuple[bool, List[str]]:
        """Validate file path and accessibility."""
        errors = []
        
        try:
            path = Path(file_path)
            
            # Check if path exists
            if not path.exists():
                errors.append("مسیر فایل موجود نیست")
                return False, errors
            
            # Check if it's a file
            if not path.is_file():
                errors.append("مسیر مشخص شده یک فایل نیست")
            
            # Check if readable
            if not path.is_file() or not os.access(path, os.R_OK):
                errors.append("فایل قابل خواندن نیست")
            
            # Check file extension
            if path.suffix.lower() not in ['.json', '.jpg', '.jpeg', '.png']:
                errors.append("نوع فایل پشتیبانی نمی‌شود")
            
        except Exception as e:
            errors.append(f"خطا در بررسی مسیر فایل: {e}")
        
        return len(errors) == 0, errors
    
    def validate_image_file(self, image_path: str) -> Tuple[bool, List[str]]:
        """Validate image file requirements."""
        errors = []
        
        try:
            path = Path(image_path)
            
            # Basic file validation
            is_valid, file_errors = self.validate_file_path(image_path)
            if not is_valid:
                errors.extend(file_errors)
                return False, errors
            
            # Check file size (max 10MB)
            file_size = path.stat().st_size
            if file_size > 10 * 1024 * 1024:  # 10MB
                errors.append("حجم فایل تصویر نباید بیش از ۱۰ مگابایت باشد")
            
            # Check file extension
            if path.suffix.lower() not in ['.jpg', '.jpeg', '.png']:
                errors.append("فقط فرمت‌های JPG، JPEG و PNG پشتیبانی می‌شوند")
            
        except Exception as e:
            errors.append(f"خطا در بررسی فایل تصویر: {e}")
        
        return len(errors) == 0, errors
    
    def _is_valid_employee_id(self, employee_id: str) -> bool:
        """Check if employee ID is valid."""
        if not employee_id or not isinstance(employee_id, str):
            return False
        
        # Employee ID should be alphanumeric and 3-20 characters
        pattern = r'^[a-zA-Z0-9_-]{3,20}$'
        return bool(re.match(pattern, employee_id))
    
    def _is_valid_phone_number(self, phone: str) -> bool:
        """Check if phone number is valid."""
        if not phone or not isinstance(phone, str):
            return False
        
        # Remove spaces and dashes
        phone = re.sub(r'[\s\-]', '', phone)
        
        # Check Iranian phone number format
        pattern = r'^(\+98|98|0)?9\d{9}$'
        return bool(re.match(pattern, phone))
    
    def _is_valid_email(self, email: str) -> bool:
        """Check if email is valid."""
        if not email or not isinstance(email, str):
            return False
        
        pattern = r'^[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}$'
        return bool(re.match(pattern, email))
    
    def _is_valid_employee_reference(self, employee: Any) -> bool:
        """Check if employee reference is valid."""
        if not employee:
            return False
        
        # Employee reference should be a dict with id
        if not isinstance(employee, dict):
            return False
        
        if 'id' not in employee:
            return False
        
        return self._is_valid_employee_id(employee['id'])
    
    def _is_valid_date_format(self, date_str: str) -> bool:
        """Check if date string is in valid format."""
        if not date_str or not isinstance(date_str, str):
            return False
        
        # Check YYYY-MM-DD format
        pattern = r'^\d{4}-\d{2}-\d{2}$'
        if not re.match(pattern, date_str):
            return False
        
        try:
            # Try to parse the date
            from datetime import datetime
            datetime.strptime(date_str, "%Y-%m-%d")
            return True
        except ValueError:
            return False
    
    def sanitize_input(self, text: str) -> str:
        """Sanitize user input to prevent injection attacks."""
        if not text:
            return ""
        
        # Remove potentially dangerous characters
        dangerous_chars = ['<', '>', '"', "'", '&', ';', '(', ')', '{', '}', '[', ']']
        for char in dangerous_chars:
            text = text.replace(char, '')
        
        # Remove extra whitespace
        text = re.sub(r'\s+', ' ', text.strip())
        
        return text
    
    def validate_json_structure(self, json_data: Any) -> Tuple[bool, List[str]]:
        """Validate JSON data structure."""
        errors = []
        
        if not isinstance(json_data, dict):
            errors.append("داده JSON باید یک دیکشنری باشد")
            return False, errors
        
        # Check for required top-level keys
        required_keys = ['date', 'shifts', 'absences']
        for key in required_keys:
            if key not in json_data:
                errors.append(f"کلید '{key}' در JSON موجود نیست")
        
        return len(errors) == 0, errors
